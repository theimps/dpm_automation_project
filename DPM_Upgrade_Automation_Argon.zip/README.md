# DPM / SQL 2022 Upgrade Automation Pipeline

State-aware, reboot-survivable, deadlock-immune PowerShell automation to upgrade **SQL Server 2017 -> 2022**, **SSMS**, **SSRS**, and **SCDPM 2019 -> SCDPM 2022 + UR4** across a fleet of 35-40 DPM servers.

## Architecture Overview (Plan 4: Agent-Driven Smart Copy + Non-Blocking Controller)

```
Controller (Launcher or Regional Jump Box)     Agent (Each Target DPM Server)
------------------------------------------     ------------------------------------------
Invoke-FleetUpgrade.ps1                        Invoke-ServerUpgrade.ps1
  1. Uses UpgradeAccount from Config (no popup)  - Single-instance & state mutex guards
  2. Pre-checks SQL/DPM versions remotely        - Smart component detection (full/partial)
  3. Skips already-upgraded servers (0 copy)     - STEP 0: SMART_COPY (copies only missing
  4. Pushes 40KB orchestrator + starts SYSTEM      component folders from regional share)
     Scheduled Task (~3s non-blocking kickoff)   - 3 controlled reboots via AtStartup task
  5. Enforces MaxParallelCopies (1/region) &     - Verifies SQL + SSRS before DPM upgrades
     MaxParallelUpgrades (2) with Auto-Eviction  - Verifies all SQL/SSRS/DPM services at end
```

## Files in This Package

| File | Purpose |
|---|---|
| `UpgradeConfig.psd1` | **Single source of truth configuration.** Regional shares, credentials, customizable `TargetVersions`, concurrency limits (`MaxParallelCopies`, `MaxParallelUpgrades`), product keys, paths, and timeouts. |
| `Invoke-ServerUpgrade.ps1` | Per-server state machine agent (12 steps, survives all 3 reboots, never disables any service). |
| `Invoke-FleetUpgrade.ps1` | Non-blocking fleet controller with pre-copy skip check, auto-slot eviction, restartability, and optional `-Region` filtering. |
| `CancelDpmJobs.sql` | Proven SQL script that cancels running DPM jobs and clears alerts before upgrades begin. |
| `DpmUpgrade.ini.template` | Proven DPM unattended answer-file template (`{{...}}` tokens populated per server). |
| `Inventory.sample.csv` | Example fleet inventory (`Hostname,Location,UpgradeEnabled`). |

## 12-Step Server Pipeline (3 Reboots)

1. `SMART_COPY` - Authenticates to the regional staging share using `UpgradeAccount`, delta-copies **only** the component folders required for this server, and unblocks all staged files.
2. `CANCEL_DPM_JOBS` - **Always runs first** (even on partial DPM-only or UR4-only upgrades) after verifying SQL services are running, using `CancelDpmJobs.sql` (5-minute monitored cap).
3. `DRIVERS` - Uninstalls existing OLEDB/ODBC drivers and installs new ones from the `SQL2022` folder (runs if SQL upgrade is needed).
4. `BACKUP_PRE_SQL` - Backs up `DPMDB` to the lettered MBS ReFS volume with the most free space (runs if SQL upgrade is needed; skipped if today's `Pre-SQL` backup already exists).
5. `SQL2022` - In-place SQL Server 2022 upgrade using proven switches + post-install major version verification.
6. `SSMS` - Silent SSMS upgrade (`/install /quiet /norestart`).
7. `SSRS` - In-place SSRS upgrade (`/quiet /IAcceptLicenseTerms /norestart`).
8. `SSRS_TRUSTFIX` - Applies FullTrust `CodeGroup` in `rssrvpolicy.config`, grants `ReadAndExecute` on `ReportSRV10.dll`, and restarts SSRS -> **REBOOT 1**.
9. `DPM2022` - Verifies SQL (`MSSQLSERVER`/`MSSQL$<Instance>`, `SQLSERVERAGENT`) and `SQLServerReportingServices` are `Running`, then runs DPM 2022 base upgrade via `DpmUpgrade.ini` + verifies DPM base build -> **REBOOT 2**.
10. `BACKUP_PRE_UR4` - Verifies SQL services are `Running`, then backs up `DPMDB` to the lettered ReFS volume (`Pre-UR4`).
11. `DPM_UR4` - Installs DPM 2022 UR4 (`/q /norestart`) + verifies DPM UR build (`10.22.506.0`) -> **REBOOT 3**.
12. `VERIFY_SERVICES` - After the 3rd reboot, verifies (and starts if needed) `MSSQLSERVER` (or `MSSQL$<Instance>`), `SQLSERVERAGENT` (or `SQLAgent$<Instance>`), `SQLServerReportingServices`, `MSDPM`, `DPMRA`, `DPMLA`, `DPMMAC`, and `DPMWriter` before marking the server `DONE`.

## How to Run

1. Update `UpgradeConfig.psd1` with your `UpgradeAccount` (`UserName` and `Password`), `Sql.ProductKey`, `Dpm.ProductKey`, `RegionSources`, and desired `MaxParallelUpgrades` / `TargetVersions`.
2. Prepare `Inventory.csv` from `Inventory.sample.csv`.
3. Run from a single launcher box or per-region on regional jump servers:

```powershell
# Rehearse first (DryRun mode):
.\Invoke-FleetUpgrade.ps1 -ConfigPath .\UpgradeConfig.psd1 -InventoryPath .\Inventory.csv -DryRun

# Run across all regions from one controller:
.\Invoke-FleetUpgrade.ps1 -ConfigPath .\UpgradeConfig.psd1 -InventoryPath .\Inventory.csv

# Or run per-region on separate regional jump servers (each managing its own MaxParallelUpgrades):
.\Invoke-FleetUpgrade.ps1 -ConfigPath .\UpgradeConfig.psd1 -InventoryPath .\Inventory.csv -Region APAC
.\Invoke-FleetUpgrade.ps1 -ConfigPath .\UpgradeConfig.psd1 -InventoryPath .\Inventory.csv -Region EMEA
.\Invoke-FleetUpgrade.ps1 -ConfigPath .\UpgradeConfig.psd1 -InventoryPath .\Inventory.csv -Region SCNA
```
