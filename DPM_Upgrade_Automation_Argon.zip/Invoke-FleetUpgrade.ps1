#Requires -Version 5.1
<#
=======================================================================
 Invoke-FleetUpgrade.ps1
 Runs on your ADMIN / LAUNCHER box (or regional jump servers).
   1. Builds PSCredential automatically from UpgradeConfig.psd1
      (UpgradeAccount.UserName + UpgradeAccount.Password — no popup).
   2. Reads Inventory.csv (Hostname, Location, UpgradeEnabled) with an
      optional -Region filter (e.g. APAC, EMEA, SCNA).
   3. Performs Pre-Copy Remote Version Assessment on each enabled server:
      - Immediately marks SKIPPED if SQL >= SqlMajorVersion AND
        DPM >= DpmUrMinBuild (0 bytes copied).
      - Re-attaches seamlessly to already RUNNING/REBOOTING servers if
        the controller is restarted (100% restartable).
      - Archives/resets remote state.json when -Force is used or when
        retrying a FAILED/STUCK server.
   4. Runs a Unified Non-Blocking Scheduler & Monitor Loop:
      - Enforces MaxParallelCopies (per region) and MaxParallelUpgrades
        (customizable in UpgradeConfig.psd1).
      - Starts the remote agent via the DPM_Upgrade_Resume Scheduled Task
        running as SYSTEM so closing WinRM never kills the agent.
      - Auto-evicts STUCK servers (stale heartbeat or reboot timeout) so
        a hung server can NEVER deadlock the remaining queue.
=======================================================================
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [string] $ConfigPath,

    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [string] $InventoryPath,

    [Parameter(Mandatory = $false)]
    [string] $Region = '',

    [Parameter(Mandatory = $false)]
    [switch] $DryRun,

    [Parameter(Mandatory = $false)]
    [switch] $Force
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

if (-not (Test-Path -LiteralPath $ConfigPath)) {
    throw "Config file not found: $ConfigPath"
}
if (-not (Test-Path -LiteralPath $InventoryPath)) {
    throw "Inventory file not found: $InventoryPath"
}

$cfg = Import-PowerShellDataFile -LiteralPath $ConfigPath
$controllerRoot = if ($PSScriptRoot) { $PSScriptRoot } else { Split-Path -Path (Resolve-Path -LiteralPath $MyInvocation.MyCommand.Path).ProviderPath -Parent }

# ---- Build PSCredential automatically from UpgradeConfig.psd1 -------
if (-not $cfg.UpgradeAccount -or
    [string]::IsNullOrWhiteSpace($cfg.UpgradeAccount.UserName) -or
    [string]::IsNullOrWhiteSpace($cfg.UpgradeAccount.Password)) {
    throw 'UpgradeConfig.psd1 must define UpgradeAccount.UserName and UpgradeAccount.Password.'
}
$secPass = ConvertTo-SecureString -String $cfg.UpgradeAccount.Password -AsPlainText -Force
$cred    = New-Object System.Management.Automation.PSCredential($cfg.UpgradeAccount.UserName, $secPass)

# ---- Controller Logger ----------------------------------------------
function Write-CLog {
    param(
        [Parameter(Mandatory = $true)] [string] $Message,
        [ValidateSet('INFO', 'WARN', 'ERROR', 'SUCCESS')] [string] $Level = 'INFO'
    )
    $line = '{0} [{1}] {2}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Level, $Message
    $logDir = Split-Path -Path $cfg.ControllerLog -Parent
    if ($logDir -and -not (Test-Path -LiteralPath $logDir)) {
        New-Item -ItemType Directory -Path $logDir -Force | Out-Null
    }
    Add-Content -LiteralPath $cfg.ControllerLog -Value $line -Encoding UTF8 -ErrorAction SilentlyContinue
    Write-Host $line
}

# ---- Read + Validate Inventory --------------------------------------
function Get-Targets {
    $rows = Import-Csv -LiteralPath $InventoryPath
    $targets = @()
    foreach ($r in $rows) {
        $hostVal = if ($r.PSObject.Properties.Name -contains 'Hostname') { $r.Hostname }
                   elseif ($r.PSObject.Properties.Name -contains 'ServerName') { $r.ServerName }
                   else { '' }
        $locVal  = if ($r.PSObject.Properties.Name -contains 'Location') { $r.Location }
                   elseif ($r.PSObject.Properties.Name -contains 'Region') { $r.Region }
                   else { '' }
        $enVal   = if ($r.PSObject.Properties.Name -contains 'UpgradeEnabled') { $r.UpgradeEnabled }
                   elseif ($r.PSObject.Properties.Name -contains 'Enabled') { $r.Enabled }
                   else { 'true' }

        if ([string]::IsNullOrWhiteSpace($hostVal)) { continue }
        $h = $hostVal.Trim()
        $l = $locVal.Trim()

        if (-not [string]::IsNullOrWhiteSpace($Region) -and ($l -notlike $Region.Trim())) {
            continue
        }

        $enabled = "$enVal".Trim().ToLower() -in @('true', 'yes', '1')
        if (-not $enabled) {
            Write-CLog "SKIP (disabled in inventory): $h"
            continue
        }
        if (-not $cfg.RegionSources.ContainsKey($l)) {
            Write-CLog "SKIP (unknown Location '$l'): $h" 'WARN'
            continue
        }
        $targets += [pscustomobject]@{
            Hostname = $h
            Location = $l
            Source   = $cfg.RegionSources[$l]
        }
    }
    return @($targets | Sort-Object Hostname -Unique)
}

# ---- Pre-Copy Remote Version & State Assessment ---------------------
function Get-RemoteAssessment {
    param(
        [Parameter(Mandatory = $true)] [string] $Hostname,
        [switch] $ForceRun
    )
    $sb = {
        param($orchRoot, $sqlInstanceName, $ssrsServiceName, $targetVersions, $isForce)

        function ConvertTo-SafeVer {
            param([string]$vStr)
            if ([string]::IsNullOrWhiteSpace($vStr)) { return [version]'0.0.0.0' }
            $c = ($vStr -replace '[^0-9\.]', '').Trim('.')
            $p = @($c -split '\.' | Where-Object { $_ -match '^\d+$' })
            if ($p.Count -lt 2) { return [version]'0.0.0.0' }
            if ($p.Count -gt 4) { $p = $p[0..3] }
            try { return [version]($p -join '.') } catch { return [version]'0.0.0.0' }
        }

        # 1) Read existing state.json if present
        $sf = Join-Path -Path $orchRoot -ChildPath 'state.json'
        $state = $null
        if (Test-Path -LiteralPath $sf) {
            try {
                $state = Get-Content -LiteralPath $sf -Raw -Encoding UTF8 | ConvertFrom-Json
            } catch { $state = $null }
        }

        # 2) Detect SQL Major Version
        $sqlMajor = 0
        try {
            $instKey = 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL'
            if (Test-Path -LiteralPath $instKey) {
                $instProp = Get-ItemProperty -LiteralPath $instKey -ErrorAction SilentlyContinue
                if ($instProp.PSObject.Properties.Name -contains $sqlInstanceName) {
                    $instId = $instProp.$sqlInstanceName
                    if ($instId) {
                        $verKey = "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$instId\Setup"
                        $sp = Get-ItemProperty -LiteralPath $verKey -ErrorAction Stop
                        $ver = if ($sp.PSObject.Properties.Name -contains 'PatchLevel' -and $sp.PatchLevel) { $sp.PatchLevel } else { $sp.Version }
                        $sqlMajor = [int]($ver.Split('.')[0])
                    }
                }
            }
        } catch { $sqlMajor = 0 }

        # 3) Detect DPM Build
        $dpmBuild = [version]'0.0.0.0'
        try {
            $dpmKey = 'HKLM:\SOFTWARE\Microsoft\Microsoft Data Protection Manager\Setup'
            if (Test-Path -LiteralPath $dpmKey) {
                $dp = Get-ItemProperty -LiteralPath $dpmKey -ErrorAction Stop
                foreach ($field in @('DPMVersion', 'Version', 'ProductVersion', 'UIBuildNumber', 'BuildNumber')) {
                    if ($dp.PSObject.Properties.Name -contains $field -and $dp.$field) {
                        $v = ConvertTo-SafeVer ([string]$dp.$field)
                        if ($v -gt [version]'0.0.0.0') { $dpmBuild = $v; break }
                    }
                }
            }
        } catch { $dpmBuild = [version]'0.0.0.0' }

        $sqlOk     = ($sqlMajor -ge [int]$targetVersions.SqlMajorVersion)
        $dpmBaseOk = ($dpmBuild -ge [version]$targetVersions.DpmBaseMinBuild)
        $dpmUrOk   = ($dpmBuild -ge [version]$targetVersions.DpmUrMinBuild)

        # Build human-readable scope of what needs upgrading
        $missing = @()
        if (-not $sqlOk)     { $missing += 'SQL2022' }
        if (-not $dpmBaseOk) { $missing += 'DPM2022' }
        if (-not $dpmUrOk)   { $missing += 'DPM_UR4' }
        $scopeText = if ($missing.Count -gt 0) { "Needs: $($missing -join ' + ')" } else { 'SQL2022 + DPM_UR4 Present' }

        # If currently RUNNING or REBOOTING, re-attach without disturbing the running upgrade!
        if ($null -ne $state -and $state.Status -in @('STARTING', 'RUNNING', 'REBOOTING')) {
            return [pscustomobject]@{
                Action     = 'ATTACH'
                Status     = [string]$state.Status
                Step       = [string]$state.Step
                Detail     = "Re-attached at step $($state.Step)"
                SqlVersion = [string]$sqlMajor
                DpmBuild   = $dpmBuild.ToString()
                State      = $state
            }
        }

        # Pre-check skip BEFORE copying any files if SQL >= Target and DPM >= UR4 Target
        if (-not $isForce -and $sqlOk -and $dpmUrOk) {
            return [pscustomobject]@{
                Action     = 'SKIP'
                Status     = 'SKIPPED'
                Step       = 'DONE'
                Detail     = "Already upgraded (SQL=$sqlMajor, DPM=$dpmBuild)"
                SqlVersion = [string]$sqlMajor
                DpmBuild   = $dpmBuild.ToString()
                State      = $state
            }
        }

        # Preserve prior DONE/SKIPPED state unless -Force
        if (-not $isForce -and $null -ne $state -and $state.Status -in @('DONE', 'SKIPPED')) {
            return [pscustomobject]@{
                Action     = 'KEEP'
                Status     = [string]$state.Status
                Step       = [string]$state.Step
                Detail     = if ($state.PSObject.Properties.Name -contains 'Detail' -and $state.Detail) { [string]$state.Detail } else { "Already $($state.Status)" }
                SqlVersion = [string]$sqlMajor
                DpmBuild   = $dpmBuild.ToString()
                State      = $state
            }
        }

        # If -Force or prior FAILED/STUCK state exists, archive old state.json so retry starts cleanly
        if ($null -ne $state -and ($isForce -or $state.Status -in @('FAILED', 'DONE', 'SKIPPED'))) {
            $bak = Join-Path -Path $orchRoot -ChildPath ('state_{0:yyyyMMdd_HHmmss}.bak.json' -f (Get-Date))
            Copy-Item -LiteralPath $sf -Destination $bak -Force -ErrorAction SilentlyContinue
            Remove-Item -LiteralPath $sf -Force -ErrorAction SilentlyContinue
        }

        return [pscustomobject]@{
            Action     = 'QUEUE'
            Status     = 'QUEUED'
            Step       = 'WAITING_SLOT'
            Detail     = "$scopeText (SQL=$sqlMajor, DPM=$dpmBuild)"
            SqlVersion = [string]$sqlMajor
            DpmBuild   = $dpmBuild.ToString()
            State      = $null
        }
    }

    return Invoke-Command -ComputerName $Hostname -Credential $cred -ScriptBlock $sb `
        -ArgumentList $cfg.OrchRoot, $cfg.Sql.InstanceName, $cfg.Ssrs.ServiceName, $cfg.TargetVersions, $ForceRun.IsPresent `
        -ErrorAction Stop
}

# ---- Read a server's remote state.json ------------------------------
function Get-RemoteState {
    param([Parameter(Mandatory = $true)] [string] $Hostname)
    try {
        return Invoke-Command -ComputerName $Hostname -Credential $cred -ScriptBlock {
            param($sf)
            if (Test-Path -LiteralPath $sf) {
                Get-Content -LiteralPath $sf -Raw -Encoding UTF8 | ConvertFrom-Json
            } else {
                $null
            }
        } -ArgumentList (Join-Path -Path $cfg.OrchRoot -ChildPath 'state.json') -ErrorAction Stop
    } catch {
        return 'UNREACHABLE'
    }
}

# ---- Push small orchestrator files & start Scheduled Task -----------
function Start-ServerUpgrade {
    param([Parameter(Mandatory = $true)] [pscustomobject] $Target)
    $h = $Target.Hostname
    Write-CLog "[$h] Staging orchestrator files and starting agent task (Source = $($Target.Source))..."

    $session = New-PSSession -ComputerName $h -Credential $cred -ErrorAction Stop
    try {
        Invoke-Command -Session $session -ScriptBlock {
            param($orch, $isForce)
            if (-not (Test-Path -LiteralPath $orch)) {
                New-Item -ItemType Directory -Path $orch -Force | Out-Null
            }
            $sf = Join-Path -Path $orch -ChildPath 'state.json'
            if ($isForce -and (Test-Path -LiteralPath $sf)) {
                Remove-Item -LiteralPath $sf -Force -ErrorAction SilentlyContinue
            }
        } -ArgumentList $cfg.OrchRoot, $Force.IsPresent -ErrorAction Stop

        Copy-Item -LiteralPath (Join-Path -Path $controllerRoot -ChildPath 'Invoke-ServerUpgrade.ps1') `
            -Destination $cfg.OrchRoot -ToSession $session -Force -ErrorAction Stop
        Copy-Item -LiteralPath (Resolve-Path -LiteralPath $ConfigPath).ProviderPath `
            -Destination (Join-Path -Path $cfg.OrchRoot -ChildPath 'UpgradeConfig.psd1') -ToSession $session -Force -ErrorAction Stop
        Copy-Item -LiteralPath (Join-Path -Path $controllerRoot -ChildPath $cfg.DpmDb.PrepSqlFile) `
            -Destination $cfg.OrchRoot -ToSession $session -Force -ErrorAction Stop
        Copy-Item -LiteralPath (Join-Path -Path $controllerRoot -ChildPath $cfg.Dpm.IniTemplate) `
            -Destination $cfg.OrchRoot -ToSession $session -Force -ErrorAction Stop

        # Seed initial state.json and launch via Scheduled Task as SYSTEM (survives WinRM disconnect)
        Invoke-Command -Session $session -ScriptBlock {
            param($orch, $sourceShare, $dry)
            $now = (Get-Date).ToString('o')
            $sf  = Join-Path -Path $orch -ChildPath 'state.json'
            if (-not (Test-Path -LiteralPath $sf)) {
                $seed = [pscustomobject]@{
                    ServerName  = $env:COMPUTERNAME
                    Step        = 'SMART_COPY'
                    Status      = 'STARTING'
                    Detail      = 'Starting Step 0 (SMART_COPY)'
                    SourceShare = $sourceShare
                    SqlVersion  = ''
                    DpmBuild    = ''
                    Completed   = @()
                    Attempts    = [pscustomobject]@{}
                    Heartbeat   = $now
                    LastError   = ''
                    StartedAt   = $now
                    UpdatedAt   = $now
                }
                $seed | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $sf -Encoding UTF8 -Force
            }

            $taskName = 'DPM_Upgrade_Resume'
            $ps       = (Get-Command powershell.exe).Source
            $agent    = Join-Path -Path $orch -ChildPath 'Invoke-ServerUpgrade.ps1'
            $config   = Join-Path -Path $orch -ChildPath 'UpgradeConfig.psd1'
            $arg      = "-NoProfile -NonInteractive -ExecutionPolicy Bypass -File `"$agent`" -ConfigPath `"$config`" -SourceShare `"$sourceShare`""
            if ($dry) { $arg += ' -DryRun' }

            $action    = New-ScheduledTaskAction -Execute $ps -Argument $arg -WorkingDirectory $orch
            $trigger   = New-ScheduledTaskTrigger -AtStartup
            $trigger.Delay = 'PT30S'
            $principal = New-ScheduledTaskPrincipal -UserId 'NT AUTHORITY\SYSTEM' -LogonType ServiceAccount -RunLevel Highest
            $settings  = New-ScheduledTaskSettingsSet `
                            -AllowStartIfOnBatteries `
                            -DontStopIfGoingOnBatteries `
                            -StartWhenAvailable `
                            -MultipleInstances IgnoreNew `
                            -ExecutionTimeLimit ([TimeSpan]::FromHours(12))

            Register-ScheduledTask -TaskName $taskName -Action $action -Trigger $trigger `
                -Principal $principal -Settings $settings -Force | Out-Null
            Start-ScheduledTask -TaskName $taskName -ErrorAction Stop
        } -ArgumentList $cfg.OrchRoot, $Target.Source, $DryRun.IsPresent -ErrorAction Stop
    } finally {
        if ($null -ne $session) {
            Remove-PSSession -Session $session -ErrorAction SilentlyContinue
        }
    }
    Write-CLog "[$h] Scheduled task started (Step 0: SMART_COPY)." 'SUCCESS'
}

# =====================================================================
#  MAIN CONTROLLER FLOW (NON-BLOCKING UNIFIED DISPATCH + MONITOR LOOP)
# =====================================================================
$targets = Get-Targets
$regionBanner = if ([string]::IsNullOrWhiteSpace($Region)) { 'ALL REGIONS' } else { $Region.ToUpperInvariant() }
Write-CLog "Fleet ($regionBanner): $($targets.Count) server(s) enabled. MaxParallelCopies=$($cfg.MaxParallelCopies)/region, MaxParallelUpgrades=$($cfg.MaxParallelUpgrades), DryRun=$($DryRun.IsPresent)"

if ($targets.Count -eq 0) {
    Write-CLog 'No enabled targets matched. Exiting.' 'WARN'
    return
}

# Phase 1: Fast Pre-Copy Remote Assessment across all targets
$fleet = @()
foreach ($t in $targets) {
    $item = [pscustomobject]@{
        Hostname      = $t.Hostname
        Location      = $t.Location
        Source        = $t.Source
        Status        = 'QUEUED'
        Step          = 'WAITING_SLOT'
        SqlVersion    = '-'
        DpmBuild      = '-'
        Detail        = 'Pending assessment'
        LastHeartbeat = (Get-Date)
        RebootStart   = $null
        Updated       = (Get-Date -Format 'HH:mm:ss')
    }
    try {
        $assess = Get-RemoteAssessment -Hostname $t.Hostname -ForceRun:$Force
        $item.Status     = $assess.Status
        $item.Step       = $assess.Step
        $item.Detail     = $assess.Detail
        $item.SqlVersion = $assess.SqlVersion
        $item.DpmBuild   = $assess.DpmBuild
        if ($assess.Action -eq 'SKIP') {
            Write-CLog "[$($t.Hostname)] SKIPPED (pre-check): $($assess.Detail)" 'SUCCESS'
        } elseif ($assess.Action -eq 'ATTACH') {
            Write-CLog "[$($t.Hostname)] Re-attached to running upgrade at step $($assess.Step)." 'WARN'
            if ($item.Status -eq 'REBOOTING') { $item.RebootStart = Get-Date }
        } else {
            Write-CLog "[$($t.Hostname)] $($assess.Status): $($assess.Detail)"
        }
    } catch {
        $item.Status = 'FAILED'
        $item.Step   = 'PRECHECK'
        $item.Detail = "WinRM pre-check failed: $($_.Exception.Message)"
        Write-CLog "[$($t.Hostname)] PRECHECK FAILED: $($_.Exception.Message)" 'ERROR'
    }
    $fleet += $item
}

# Phase 2: Unified Non-Blocking Dispatch & Monitor Loop with Auto-Slot Eviction
$activeStates = @('STARTING', 'RUNNING', 'REBOOTING')
$maxCopies    = [int]$cfg.MaxParallelCopies
$maxUpgrades  = [int]$cfg.MaxParallelUpgrades

Write-CLog 'Entering unified dispatch & monitor loop. Ctrl-C is safe (controller is 100% restartable).'

do {
    $now = Get-Date

    # 1) Poll all currently active servers & auto-evict any STUCK servers
    foreach ($srv in @($fleet | Where-Object { $_.Status -in $activeStates })) {
        $state = Get-RemoteState -Hostname $srv.Hostname

        if ($state -eq 'UNREACHABLE') {
            if ($null -eq $srv.RebootStart) {
                $srv.RebootStart = $now
            }
            $downMin = ($now - $srv.RebootStart).TotalMinutes
            if ($downMin -gt [double]$cfg.MaxRebootWaitMinutes) {
                # Auto-evict from slot so remaining servers never deadlock!
                $srv.Status = 'STUCK'
                $srv.Detail = "Auto-evicted: Offline > $($cfg.MaxRebootWaitMinutes)m during $($srv.Step)"
                Write-CLog "[$($srv.Hostname)] $($srv.Detail). Freeing upgrade slot." 'ERROR'
            } else {
                $srv.Status = 'REBOOTING'
                $srv.Detail = ('Offline {0}m during {1} (max {2}m)' -f [int]$downMin, $srv.Step, $cfg.MaxRebootWaitMinutes)
            }
            $srv.Updated = (Get-Date -Format 'HH:mm:ss')
            continue
        }

        $srv.RebootStart = $null
        if ($null -eq $state) {
            $ageMin = ($now - $srv.LastHeartbeat).TotalMinutes
            if ($ageMin -gt 15) {
                $srv.Status = 'STUCK'
                $srv.Detail = 'Auto-evicted: No state.json after 15m'
                Write-CLog "[$($srv.Hostname)] $($srv.Detail). Freeing upgrade slot." 'ERROR'
            }
            $srv.Updated = (Get-Date -Format 'HH:mm:ss')
            continue
        }

        $srv.Status = [string]$state.Status
        $srv.Step   = [string]$state.Step
        if ($state.PSObject.Properties.Name -contains 'Detail' -and $state.Detail) {
            $srv.Detail = [string]$state.Detail
        } else {
            $srv.Detail = "Step $($state.Step)"
        }
        if ($state.PSObject.Properties.Name -contains 'SqlVersion' -and $state.SqlVersion) {
            $srv.SqlVersion = [string]$state.SqlVersion
        }
        if ($state.PSObject.Properties.Name -contains 'DpmBuild' -and $state.DpmBuild) {
            $srv.DpmBuild = [string]$state.DpmBuild
        }
        if ($state.PSObject.Properties.Name -contains 'Heartbeat' -and $state.Heartbeat) {
            try { $srv.LastHeartbeat = [datetime]$state.Heartbeat } catch {}
        }

        if ($srv.Status -in @('DONE', 'FAILED', 'SKIPPED')) {
            Write-CLog "[$($srv.Hostname)] Reached terminal state $($srv.Status): $($srv.Detail)"
            $srv.Updated = (Get-Date -Format 'HH:mm:ss')
            continue
        }

        # Check step watchdog budget; if stale past budget, mark STUCK and free the slot!
        $budget = if ($cfg.StepTimeoutMinutes.ContainsKey($srv.Step)) {
            [double]$cfg.StepTimeoutMinutes[$srv.Step]
        } else {
            60.0
        }
        $hbAgeMin = ($now - $srv.LastHeartbeat).TotalMinutes
        if ($srv.Status -in @('STARTING', 'RUNNING') -and $hbAgeMin -gt $budget) {
            $srv.Status = 'STUCK'
            $srv.Detail = ('Auto-evicted: Heartbeat stale {0}m on step {1} (budget {2}m)' -f [int]$hbAgeMin, $srv.Step, [int]$budget)
            Write-CLog "[$($srv.Hostname)] $($srv.Detail). Freeing upgrade slot." 'ERROR'
        }
        $srv.Updated = (Get-Date -Format 'HH:mm:ss')
    }

    # 2) Dispatch queued servers when both upgrade slots and regional copy slots are available
    foreach ($candidate in @($fleet | Where-Object { $_.Status -eq 'QUEUED' })) {
        $activeUpgradesCount = @($fleet | Where-Object { $_.Status -in $activeStates }).Count
        if ($activeUpgradesCount -ge $maxUpgrades) {
            break
        }

        $activeRegionCopies = @(
            $fleet | Where-Object {
                $_.Location -ieq $candidate.Location -and
                $_.Status -in $activeStates -and
                $_.Step -eq 'SMART_COPY'
            }
        ).Count

        if ($activeRegionCopies -lt $maxCopies -and $activeUpgradesCount -lt $maxUpgrades) {
            try {
                Start-ServerUpgrade -Target $candidate
                $candidate.Status        = 'STARTING'
                $candidate.Step          = 'SMART_COPY'
                $candidate.Detail        = 'Step SMART_COPY (copying required media)'
                $candidate.LastHeartbeat = Get-Date
                $candidate.Updated       = (Get-Date -Format 'HH:mm:ss')
            } catch {
                $candidate.Status  = 'FAILED'
                $candidate.Step    = 'START_AGENT'
                $candidate.Detail  = "Start failed: $($_.Exception.Message)"
                $candidate.Updated = (Get-Date -Format 'HH:mm:ss')
                Write-CLog "[$($candidate.Hostname)] START FAILED: $($_.Exception.Message)" 'ERROR'
            }
        }
    }

    # 3) Render live console dashboard and export DashboardCsv
    $activeNow = @($fleet | Where-Object { $_.Status -in $activeStates }).Count
    $queuedNow = @($fleet | Where-Object { $_.Status -eq 'QUEUED' }).Count
    $doneNow   = @($fleet | Where-Object { $_.Status -eq 'DONE' }).Count
    $skipNow   = @($fleet | Where-Object { $_.Status -eq 'SKIPPED' }).Count
    $failNow   = @($fleet | Where-Object { $_.Status -in @('FAILED', 'STUCK') }).Count

    Clear-Host
    Write-Host "=== DPM/SQL Fleet Upgrade [$regionBanner] ($(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')) ==="
    Write-Host "Slots Active: $activeNow/$maxUpgrades | Queued: $queuedNow | Done: $doneNow | Skipped: $skipNow | Failed/Stuck: $failNow"
    $fleet | Select-Object Hostname, Location, Status, Step, SqlVersion, DpmBuild, Detail, Updated | Format-Table -AutoSize | Out-Host

    $csvDir = Split-Path -Path $cfg.DashboardCsv -Parent
    if ($csvDir -and -not (Test-Path -LiteralPath $csvDir)) {
        New-Item -ItemType Directory -Path $csvDir -Force | Out-Null
    }
    $fleet | Select-Object Hostname, Location, Status, Step, SqlVersion, DpmBuild, Detail, Updated |
        Export-Csv -LiteralPath $cfg.DashboardCsv -NoTypeInformation -Encoding UTF8 -Force

    $pending = (@($fleet | Where-Object { $_.Status -in ($activeStates + @('QUEUED')) }).Count -gt 0)
    if ($pending) {
        Start-Sleep -Seconds ([int]$cfg.HeartbeatSeconds)
    }
} while ($pending)

Write-CLog 'All servers reached a terminal state (DONE/SKIPPED/FAILED/STUCK).' 'SUCCESS'
Write-CLog "See $($cfg.DashboardCsv) for the final summary."
