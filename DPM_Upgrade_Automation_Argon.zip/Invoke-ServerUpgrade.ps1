#Requires -Version 5.1
<#
=======================================================================
 Invoke-ServerUpgrade.ps1
 Runs LOCALLY on each target server as a reboot-survivable STATE MACHINE.
   - Guarded by a system-wide single-instance mutex (Global\DPM_Upgrade_Agent_Mutex).
   - Protects state.json reads/writes with Global\DPM_Upgrade_State_Mutex so
     the background heartbeat runspace can never overwrite step transitions.
   - Evaluates installed component versions (SQL, SSMS, SSRS, DPM Base, DPM UR)
     against UpgradeConfig.psd1 TargetVersions:
       * Skips the entire server if SQL >= SqlMajorVersion AND DPM >= DpmUrMinBuild.
       * Copies ONLY the required component folders during SMART_COPY using
         explicit SMB authentication (UpgradeAccount) to avoid WinRM double-hop.
       * ALWAYS runs CANCEL_DPM_JOBS before any full or partial upgrade.
       * Verifies SQL + SSRS services are Running prior to DPM 2022 and prior
         to BACKUP_PRE_UR4 / DPM_UR4.
       * Performs 3 controlled reboots (after SSRS_TRUSTFIX, after DPM2022,
         and after DPM_UR4), then runs VERIFY_SERVICES to confirm all SQL,
         SSRS, and Core DPM services are Running before marking DONE.
       * Strictly NEVER disables any Windows service at any point.
=======================================================================
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [string] $ConfigPath,

    [Parameter(Mandatory = $false)]
    [string] $SourceShare = '',

    [Parameter(Mandatory = $false)]
    [switch] $Resume,

    [Parameter(Mandatory = $false)]
    [switch] $DryRun
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$script:DryRun = $DryRun.IsPresent

# ---- Load Configuration ---------------------------------------------
if (-not (Test-Path -LiteralPath $ConfigPath)) {
    throw "Configuration file not found: $ConfigPath"
}
$cfg = Import-PowerShellDataFile -LiteralPath $ConfigPath

# ---- Key Locations & Mutex Identifiers ------------------------------
$OrchRoot               = $cfg.OrchRoot
$StateFile              = Join-Path -Path $OrchRoot -ChildPath 'state.json'
$HeartbeatFile          = Join-Path -Path $OrchRoot -ChildPath 'heartbeat.txt'
$LogDir                 = Join-Path -Path $OrchRoot -ChildPath 'logs'
$TaskName               = 'DPM_Upgrade_Resume'
$script:AgentMutexName  = 'Global\DPM_Upgrade_Agent_Mutex'
$script:StateMutexName  = 'Global\DPM_Upgrade_State_Mutex'
$script:AgentMutex      = $null
$script:HasAgentMutex   = $false
$script:HeartbeatJob    = $null

New-Item -ItemType Directory -Path $OrchRoot -Force | Out-Null
New-Item -ItemType Directory -Path $LogDir   -Force | Out-Null

# ---- Logger ---------------------------------------------------------
$LogFile = Join-Path -Path $LogDir -ChildPath ('upgrade_{0:yyyyMMdd}.log' -f (Get-Date))
function Write-Log {
    param(
        [Parameter(Mandatory = $true)]
        [AllowEmptyString()]
        [string] $Message,

        [ValidateSet('INFO', 'WARN', 'ERROR')]
        [string] $Level = 'INFO'
    )
    $line = '{0} [{1}] [{2}] {3}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Level, $env:COMPUTERNAME, $Message
    try {
        Add-Content -LiteralPath $LogFile -Value $line -Encoding UTF8 -ErrorAction SilentlyContinue
    } catch {}
    Write-Host $line
}

# ---- Mutex-Protected State Load / Save ------------------------------
function Invoke-WithStateMutex {
    param(
        [Parameter(Mandatory = $true)]
        [scriptblock] $Action,

        [int] $TimeoutSeconds = 30
    )
    $mtx = New-Object System.Threading.Mutex($false, $script:StateMutexName)
    $locked = $false
    try {
        try {
            $locked = $mtx.WaitOne([TimeSpan]::FromSeconds($TimeoutSeconds))
        } catch [System.Threading.AbandonedMutexException] {
            $locked = $true
        }
        if (-not $locked) {
            throw "Timed out acquiring state mutex '$($script:StateMutexName)'."
        }
        return (& $Action)
    } finally {
        if ($locked) {
            try { $mtx.ReleaseMutex() } catch {}
        }
        $mtx.Dispose()
    }
}

function Get-State {
    return Invoke-WithStateMutex -Action {
        if (Test-Path -LiteralPath $StateFile) {
            $raw = Get-Content -LiteralPath $StateFile -Raw -Encoding UTF8
            if (-not [string]::IsNullOrWhiteSpace($raw)) {
                $obj = $raw | ConvertFrom-Json
                $completedArr = @()
                if ($null -ne $obj.PSObject.Properties['Completed'] -and $null -ne $obj.Completed) {
                    $completedArr = [string[]]@($obj.Completed | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })
                }
                $attemptsObj = [pscustomobject]@{}
                if ($null -ne $obj.PSObject.Properties['Attempts'] -and $null -ne $obj.Attempts) {
                    foreach ($p in $obj.Attempts.PSObject.Properties) {
                        $attemptsObj | Add-Member -NotePropertyName $p.Name -NotePropertyValue ([int]$p.Value) -Force
                    }
                }
                return [pscustomobject]@{
                    ServerName  = if ($obj.PSObject.Properties['ServerName'])  { [string]$obj.ServerName }  else { $env:COMPUTERNAME }
                    Step        = if ($obj.PSObject.Properties['Step'])        { [string]$obj.Step }        else { 'INIT' }
                    Status      = if ($obj.PSObject.Properties['Status'])      { [string]$obj.Status }      else { 'RUNNING' }
                    Detail      = if ($obj.PSObject.Properties['Detail'])      { [string]$obj.Detail }      else { '' }
                    SourceShare = if ($obj.PSObject.Properties['SourceShare']) { [string]$obj.SourceShare } else { '' }
                    SqlVersion  = if ($obj.PSObject.Properties['SqlVersion'])  { [string]$obj.SqlVersion }  else { '' }
                    DpmBuild    = if ($obj.PSObject.Properties['DpmBuild'])    { [string]$obj.DpmBuild }    else { '' }
                    Completed   = [string[]]@($completedArr)
                    Attempts    = $attemptsObj
                    Heartbeat   = if ($obj.PSObject.Properties['Heartbeat'])   { [string]$obj.Heartbeat }   else { (Get-Date).ToString('o') }
                    LastError   = if ($obj.PSObject.Properties['LastError'])   { [string]$obj.LastError }   else { '' }
                    StartedAt   = if ($obj.PSObject.Properties['StartedAt'])   { [string]$obj.StartedAt }   else { (Get-Date).ToString('o') }
                    UpdatedAt   = if ($obj.PSObject.Properties['UpdatedAt'])   { [string]$obj.UpdatedAt }   else { (Get-Date).ToString('o') }
                }
            }
        }
        return [pscustomobject]@{
            ServerName  = $env:COMPUTERNAME
            Step        = 'INIT'
            Status      = 'RUNNING'
            Detail      = 'Initializing state machine'
            SourceShare = $SourceShare
            SqlVersion  = ''
            DpmBuild    = ''
            Completed   = [string[]]@()
            Attempts    = [pscustomobject]@{}
            Heartbeat   = (Get-Date).ToString('o')
            LastError   = ''
            StartedAt   = (Get-Date).ToString('o')
            UpdatedAt   = (Get-Date).ToString('o')
        }
    }
}

function Save-State {
    param([Parameter(Mandatory = $true)] $State)

    Invoke-WithStateMutex -Action {
        $now = (Get-Date).ToString('o')
        $State.UpdatedAt = $now
        $State.Heartbeat = $now
        $State.Completed = [string[]]@($State.Completed | Where-Object { -not [string]::IsNullOrWhiteSpace($_) } | Select-Object -Unique)

        $tmp = "$StateFile.tmp"
        $State | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $tmp -Encoding UTF8 -Force
        Move-Item -LiteralPath $tmp -Destination $StateFile -Force
        Set-Content -LiteralPath $HeartbeatFile -Value $now -Encoding UTF8 -Force -ErrorAction SilentlyContinue
    } | Out-Null
}

# ---- Thread-Safe Heartbeat Runspace ---------------------------------
function Start-Heartbeat {
    $sb = {
        param([string]$sf, [string]$hbFile, [string]$mutexName, [int]$intervalSec)
        while ($true) {
            Start-Sleep -Seconds $intervalSec
            $now = (Get-Date).ToString('o')
            $mtx = New-Object System.Threading.Mutex($false, $mutexName)
            $locked = $false
            try {
                try {
                    $locked = $mtx.WaitOne([TimeSpan]::FromSeconds(10))
                } catch [System.Threading.AbandonedMutexException] {
                    $locked = $true
                }
                if ($locked -and (Test-Path -LiteralPath $sf)) {
                    $raw = Get-Content -LiteralPath $sf -Raw -Encoding UTF8
                    if (-not [string]::IsNullOrWhiteSpace($raw)) {
                        $s = $raw | ConvertFrom-Json
                        $s.Heartbeat = $now
                        $tmp = "$sf.hb.tmp"
                        $s | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $tmp -Encoding UTF8 -Force
                        Move-Item -LiteralPath $tmp -Destination $sf -Force
                    }
                }
                Set-Content -LiteralPath $hbFile -Value $now -Encoding UTF8 -Force -ErrorAction SilentlyContinue
            } catch {}
            finally {
                if ($locked) {
                    try { $mtx.ReleaseMutex() } catch {}
                }
                $mtx.Dispose()
            }
        }
    }
    $rs = [runspacefactory]::CreateRunspace()
    $rs.Open()
    $ps = [powershell]::Create()
    $ps.Runspace = $rs
    $ps.AddScript($sb).
        AddArgument($StateFile).
        AddArgument($HeartbeatFile).
        AddArgument($script:StateMutexName).
        AddArgument([int]$cfg.HeartbeatSeconds) | Out-Null
    $handle = $ps.BeginInvoke()
    $script:HeartbeatJob = [pscustomobject]@{
        PowerShell = $ps
        Runspace   = $rs
        Handle     = $handle
    }
}

function Stop-Heartbeat {
    if ($null -ne $script:HeartbeatJob) {
        try { $script:HeartbeatJob.PowerShell.Stop() } catch {}
        try { $script:HeartbeatJob.PowerShell.Dispose() } catch {}
        try { $script:HeartbeatJob.Runspace.Close() } catch {}
        try { $script:HeartbeatJob.Runspace.Dispose() } catch {}
        $script:HeartbeatJob = $null
    }
}

# ---- Resume Scheduled Task ------------------------------------------
function Register-ResumeTask {
    param([string]$EffectiveSourceShare = '')
    $ps  = (Get-Command powershell.exe).Source
    $arg = "-NoProfile -NonInteractive -ExecutionPolicy Bypass -File `"$PSCommandPath`" -ConfigPath `"$ConfigPath`" -Resume"
    if (-not [string]::IsNullOrWhiteSpace($EffectiveSourceShare)) {
        $arg += " -SourceShare `"$EffectiveSourceShare`""
    }
    if ($script:DryRun) {
        $arg += ' -DryRun'
    }
    $action    = New-ScheduledTaskAction -Execute $ps -Argument $arg -WorkingDirectory $OrchRoot
    $trigger   = New-ScheduledTaskTrigger -AtStartup
    $trigger.Delay = 'PT30S'
    $principal = New-ScheduledTaskPrincipal -UserId 'NT AUTHORITY\SYSTEM' -LogonType ServiceAccount -RunLevel Highest
    $settings  = New-ScheduledTaskSettingsSet `
                    -AllowStartIfOnBatteries `
                    -DontStopIfGoingOnBatteries `
                    -StartWhenAvailable `
                    -MultipleInstances IgnoreNew `
                    -ExecutionTimeLimit ([TimeSpan]::FromHours(12))
    Register-ScheduledTask -TaskName $TaskName -Action $action -Trigger $trigger `
        -Principal $principal -Settings $settings -Force | Out-Null
    Write-Log 'Resume scheduled task registered.'
}

function Unregister-ResumeTask {
    if (Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue) {
        Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false -ErrorAction SilentlyContinue
        Write-Log 'Resume scheduled task removed.'
    }
}

# ---- SQL Execution Helper (Invoke-Sqlcmd with sqlcmd/.NET fallback) -
function Invoke-SqlExecution {
    param(
        [Parameter(Mandatory = $true)] [string] $ServerInstance,
        [string] $Database = 'master',
        [string] $Query = '',
        [string] $InputFile = '',
        [int] $QueryTimeoutSeconds = 300
    )

    if (Get-Command Invoke-Sqlcmd -ErrorAction SilentlyContinue) {
        $hasCmd = $true
    } else {
        Import-Module SqlServer -ErrorAction SilentlyContinue
        if (-not (Get-Command Invoke-Sqlcmd -ErrorAction SilentlyContinue)) {
            Import-Module SQLPS -ErrorAction SilentlyContinue
        }
        $hasCmd = [bool](Get-Command Invoke-Sqlcmd -ErrorAction SilentlyContinue)
    }

    if ($hasCmd) {
        if (-not [string]::IsNullOrWhiteSpace($InputFile)) {
            return Invoke-Sqlcmd -ServerInstance $ServerInstance -Database $Database -InputFile $InputFile -QueryTimeout $QueryTimeoutSeconds -ErrorAction Stop
        } else {
            return Invoke-Sqlcmd -ServerInstance $ServerInstance -Database $Database -Query $Query -QueryTimeout $QueryTimeoutSeconds -ErrorAction Stop
        }
    }

    # Fallback to ADO.NET SqlConnection so missing SqlServer module never breaks the upgrade
    $sqlText = if (-not [string]::IsNullOrWhiteSpace($InputFile)) {
        Get-Content -LiteralPath $InputFile -Raw -Encoding UTF8
    } else {
        $Query
    }
    $connStr = "Server=$ServerInstance;Database=$Database;Integrated Security=True;Connection Timeout=30;"
    $conn = New-Object System.Data.SqlClient.SqlConnection($connStr)
    try {
        $conn.Open()
        $batches = $sqlText -split '(?im)^\s*GO\s*$'
        $results = @()
        foreach ($b in $batches) {
            if (-not [string]::IsNullOrWhiteSpace($b)) {
                $cmd = $conn.CreateCommand()
                $cmd.CommandText = $b
                $cmd.CommandTimeout = $QueryTimeoutSeconds
                $adapter = New-Object System.Data.SqlClient.SqlDataAdapter($cmd)
                $dt = New-Object System.Data.DataTable
                [void]$adapter.Fill($dt)
                if ($dt.Rows.Count -gt 0) {
                    $results += $dt.Rows
                }
            }
        }
        return $results
    } finally {
        $conn.Dispose()
    }
}

# ---- Grant 'Log on as a batch job' to the upgrade account -----------
function Grant-BatchLogonRight {
    param([Parameter(Mandatory = $true)] [string] $AccountName)
    if ($script:DryRun) {
        Write-Log "[DRYRUN] Would grant SeBatchLogonRight to $AccountName."
        return
    }
    try {
        $sid = (New-Object System.Security.Principal.NTAccount($AccountName)).Translate(
            [System.Security.Principal.SecurityIdentifier]).Value
    } catch {
        throw "Could not resolve account '$AccountName' to a SID: $($_.Exception.Message)"
    }
    $tmp = Join-Path -Path $env:TEMP -ChildPath ('secpol_{0}.inf' -f ([guid]::NewGuid().ToString('N')))
    $db  = Join-Path -Path $env:TEMP -ChildPath ('secpol_{0}.sdb' -f ([guid]::NewGuid().ToString('N')))
    try {
        secedit /export /cfg $tmp /areas USER_RIGHTS | Out-Null
        $content = Get-Content -LiteralPath $tmp
        $line = $content | Where-Object { $_ -match '^SeBatchLogonRight' }
        if ($line) {
            if ($line -match [regex]::Escape($sid)) {
                Write-Log 'UpgradeAccount already has Log on as a batch job. No change.'
                return
            }
            $newLine = "$line,*$sid"
            $content = $content -replace [regex]::Escape($line), $newLine
        } else {
            $content = $content -replace '(\[Privilege Rights\])', "`$1`r`nSeBatchLogonRight = *$sid"
        }
        Set-Content -LiteralPath $tmp -Value $content -Encoding Unicode -Force
        secedit /configure /db $db /cfg $tmp /areas USER_RIGHTS | Out-Null
        Write-Log "Granted Log on as a batch job to $AccountName."
    } finally {
        Remove-Item -LiteralPath $tmp, $db -Force -ErrorAction SilentlyContinue
    }
}

# ---- Run an installer with a HARD timeout (anti-deadlock) -----------
function Invoke-Installer {
    param(
        [Parameter(Mandatory = $true)] [string] $FilePath,
        [Parameter(Mandatory = $true)] [string] $Arguments,
        [Parameter(Mandatory = $true)] [int] $TimeoutMinutes,
        [int[]] $SuccessCodes = @(0, 3010)
    )
    if ($script:DryRun) {
        Write-Log "[DRYRUN] Would run: $FilePath $Arguments"
        return $false
    }
    if (-not (Test-Path -LiteralPath $FilePath)) {
        throw "Installer not found: $FilePath"
    }
    $workDir = Split-Path -Path $FilePath -Parent
    if ([string]::IsNullOrWhiteSpace($workDir) -or -not (Test-Path -LiteralPath $workDir)) {
        $workDir = $env:SystemRoot
    }
    Write-Log "Running: $FilePath $Arguments (WorkingDir: $workDir, Timeout: ${TimeoutMinutes}m)"
    $proc = Start-Process -FilePath $FilePath -ArgumentList $Arguments -WorkingDirectory $workDir -PassThru -WindowStyle Hidden
    if (-not $proc.WaitForExit($TimeoutMinutes * 60 * 1000)) {
        Write-Log "TIMEOUT after ${TimeoutMinutes}m. Killing process tree for PID $($proc.Id)." 'ERROR'
        try { & taskkill.exe /PID $proc.Id /T /F 2>$null | Out-Null } catch {}
        try { Stop-Process -Id $proc.Id -Force -ErrorAction SilentlyContinue } catch {}
        throw "Installer timed out after ${TimeoutMinutes}m: $FilePath"
    }
    $code = $proc.ExitCode
    Write-Log "Exit code: $code"
    if ($SuccessCodes -notcontains $code) {
        throw "Installer failed ($FilePath) with exit code $code"
    }
    return ($code -eq 3010)
}

# ---- Run an installer AS UpgradeAccount via a one-shot task ---------
function Invoke-InstallerAsUser {
    param(
        [Parameter(Mandatory = $true)] [string] $FilePath,
        [Parameter(Mandatory = $true)] [string] $Arguments,
        [Parameter(Mandatory = $true)] [int] $TimeoutMinutes,
        [Parameter(Mandatory = $true)] [string] $UserName,
        [Parameter(Mandatory = $true)] [string] $PlainPassword,
        [int[]] $SuccessCodes = @(0, 3010)
    )
    if ($script:DryRun) {
        Write-Log "[DRYRUN] Would run AS [$UserName]: $FilePath $Arguments"
        return $false
    }
    if (-not (Test-Path -LiteralPath $FilePath)) {
        throw "Installer not found: $FilePath"
    }

    $workDir  = Split-Path -Path $FilePath -Parent
    $taskName = 'DPM_Upgrade_RunAs_' + [guid]::NewGuid().ToString('N').Substring(0, 8)
    Write-Log "Running AS [$UserName]: $FilePath $Arguments (WorkingDir: $workDir, Timeout: ${TimeoutMinutes}m, Task: $taskName)"

    $action    = New-ScheduledTaskAction -Execute $FilePath -Argument $Arguments -WorkingDirectory $workDir
    $principal = New-ScheduledTaskPrincipal -UserId $UserName -LogonType Password -RunLevel Highest
    $settings  = New-ScheduledTaskSettingsSet `
                    -AllowStartIfOnBatteries `
                    -DontStopIfGoingOnBatteries `
                    -StartWhenAvailable `
                    -ExecutionTimeLimit ([TimeSpan]::FromMinutes($TimeoutMinutes + 5))
    Register-ScheduledTask -TaskName $taskName -Action $action -Principal $principal `
        -Settings $settings -User $UserName -Password $PlainPassword -Force | Out-Null

    try {
        Start-ScheduledTask -TaskName $taskName
        Start-Sleep -Seconds 5
        $sw = [System.Diagnostics.Stopwatch]::StartNew()
        do {
            Start-Sleep -Seconds 10
            $taskObj = Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue
            $info    = Get-ScheduledTaskInfo -TaskName $taskName -ErrorAction SilentlyContinue
            $state   = if ($null -ne $taskObj) { [string]$taskObj.State } else { 'Ready' }
            if ($sw.Elapsed.TotalMinutes -ge $TimeoutMinutes) {
                Stop-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue
                throw "Installer timed out after ${TimeoutMinutes}m: $FilePath"
            }
            # 267009 (0x00041301) = SCHED_S_TASK_RUNNING
        } while ($state -eq 'Running' -or ($null -ne $info -and $info.LastTaskResult -eq 267009))

        $info = Get-ScheduledTaskInfo -TaskName $taskName -ErrorAction Stop
        $code = [int]$info.LastTaskResult
        Write-Log "Installer (as $UserName) exit code: $code"
        if ($SuccessCodes -notcontains $code) {
            throw "Installer failed ($FilePath) as $UserName with exit code $code"
        }
        return ($code -eq 3010)
    } finally {
        Unregister-ScheduledTask -TaskName $taskName -Confirm:$false -ErrorAction SilentlyContinue
    }
}

# ---- DPM DB Connection (auto-detected from the DPM registry key) ----
function Get-DpmDbConnection {
    $key = 'HKLM:\SOFTWARE\Microsoft\Microsoft Data Protection Manager\DB'
    try {
        $p = Get-ItemProperty -LiteralPath $key -ErrorAction Stop
    } catch {
        throw "Could not read DPM DB registry key ($key). Is this a DPM server?"
    }
    $sqlServer = $p.SqlServer
    $database  = $p.DatabaseName
    $instance  = $p.InstanceName
    if (-not $sqlServer -or -not $database -or -not $instance) {
        throw 'DPM DB registry key is missing SqlServer/DatabaseName/InstanceName.'
    }
    if ($instance -ieq 'MSSQLSERVER') {
        $serverInstance = $sqlServer
    } else {
        $serverInstance = "$sqlServer\$instance"
    }
    return [pscustomobject]@{
        ServerInstance = $serverInstance
        Database       = $database
    }
}

# ---- Component Version Detection Functions --------------------------
function ConvertTo-SafeVersion {
    param([string]$VersionString)
    if ([string]::IsNullOrWhiteSpace($VersionString)) { return [version]'0.0.0.0' }
    $clean = ($VersionString -replace '[^0-9\.]', '').Trim('.')
    $parts = @($clean -split '\.' | Where-Object { $_ -match '^\d+$' })
    if ($parts.Count -lt 2) { return [version]'0.0.0.0' }
    if ($parts.Count -gt 4) { $parts = $parts[0..3] }
    try { return [version]($parts -join '.') } catch { return [version]'0.0.0.0' }
}

function Get-SqlMajorVersion {
    try {
        $instKey = 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL'
        if (-not (Test-Path -LiteralPath $instKey)) { return 0 }
        $instProp = Get-ItemProperty -LiteralPath $instKey -ErrorAction SilentlyContinue
        $instName = $cfg.Sql.InstanceName
        if (-not ($instProp.PSObject.Properties.Name -contains $instName)) { return 0 }
        $instId = $instProp.$instName
        if (-not $instId) { return 0 }
        $verKey = "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$instId\Setup"
        $setupProps = Get-ItemProperty -LiteralPath $verKey -ErrorAction Stop
        $ver = if ($setupProps.PSObject.Properties.Name -contains 'PatchLevel' -and $setupProps.PatchLevel) {
            $setupProps.PatchLevel
        } else {
            $setupProps.Version
        }
        return [int]($ver.Split('.')[0])
    } catch { return 0 }
}

function Get-SsmsVersion {
    $maxVer = [version]'0.0.0.0'
    try {
        $uninstallKeys = @(
            'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*',
            'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*'
        )
        $apps = Get-ItemProperty -Path $uninstallKeys -ErrorAction SilentlyContinue |
            Where-Object {
                $_.PSObject.Properties.Name -contains 'DisplayName' -and
                $_.DisplayName -like '*SQL Server Management Studio*'
            }
        foreach ($a in $apps) {
            if ($a.PSObject.Properties.Name -contains 'DisplayVersion' -and $a.DisplayVersion) {
                $v = ConvertTo-SafeVersion $a.DisplayVersion
                if ($v -gt $maxVer) { $maxVer = $v }
            }
        }
    } catch {}
    return $maxVer
}

function Get-SsrsVersion {
    $maxVer = [version]'0.0.0.0'
    try {
        $rsKey = 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\RS'
        if (Test-Path -LiteralPath $rsKey) {
            $rsProps = Get-ItemProperty -LiteralPath $rsKey -ErrorAction SilentlyContinue
            foreach ($p in $rsProps.PSObject.Properties) {
                if ($p.Name -notlike 'PS*') {
                    $setupKey = "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$($p.Value)\Setup"
                    if (Test-Path -LiteralPath $setupKey) {
                        $sp = Get-ItemProperty -LiteralPath $setupKey -ErrorAction SilentlyContinue
                        if ($sp.PSObject.Properties.Name -contains 'Version' -and $sp.Version) {
                            $v = ConvertTo-SafeVersion $sp.Version
                            if ($v -gt $maxVer) { $maxVer = $v }
                        }
                    }
                }
            }
        }
        if ($maxVer -eq [version]'0.0.0.0') {
            $svc = Get-CimInstance -ClassName Win32_Service -Filter "Name='$($cfg.Ssrs.ServiceName)'" -ErrorAction SilentlyContinue
            if ($svc -and $svc.PathName) {
                $exe = ($svc.PathName -replace '^"([^"]+)".*$', '$1').Trim('"')
                if (Test-Path -LiteralPath $exe) {
                    $maxVer = ConvertTo-SafeVersion (Get-Item -LiteralPath $exe).VersionInfo.ProductVersion
                }
            }
        }
    } catch {}
    return $maxVer
}

function Get-DpmBuild {
    try {
        $key = 'HKLM:\SOFTWARE\Microsoft\Microsoft Data Protection Manager\Setup'
        $p = Get-ItemProperty -LiteralPath $key -ErrorAction Stop
        foreach ($name in @('DPMVersion', 'Version', 'ProductVersion', 'UIBuildNumber', 'BuildNumber')) {
            if ($p.PSObject.Properties.Name -contains $name -and $p.$name) {
                $v = ConvertTo-SafeVersion ([string]$p.$name)
                if ($v -gt [version]'0.0.0.0') { return $v }
            }
        }
        if ($p.PSObject.Properties.Name -contains 'InstallPath' -and $p.InstallPath) {
            $msdpm = Join-Path -Path $p.InstallPath -ChildPath 'bin\msdpm.exe'
            if (Test-Path -LiteralPath $msdpm) {
                return ConvertTo-SafeVersion (Get-Item -LiteralPath $msdpm).VersionInfo.ProductVersion
            }
        }
        return [version]'0.0.0.0'
    } catch { return [version]'0.0.0.0' }
}

function Get-ComponentAssessment {
    $sqlMajor   = Get-SqlMajorVersion
    $ssmsVer    = Get-SsmsVersion
    $ssrsVer    = Get-SsrsVersion
    $dpmBuild   = Get-DpmBuild

    $t = $cfg.TargetVersions
    $needsSql     = ($sqlMajor -lt [int]$t.SqlMajorVersion)
    $needsSsms    = ($ssmsVer  -lt [version]$t.SsmsMinVersion)
    $needsSsrs    = ($ssrsVer  -lt [version]$t.SsrsMinVersion)
    $needsDpmBase = ($dpmBuild -lt [version]$t.DpmBaseMinBuild)
    $needsDpmUr   = ($dpmBuild -lt [version]$t.DpmUrMinBuild)

    return [pscustomobject]@{
        SqlMajor     = $sqlMajor
        SsmsVersion  = $ssmsVer
        SsrsVersion  = $ssrsVer
        DpmBuild     = $dpmBuild
        NeedsSql     = $needsSql
        NeedsSsms    = $needsSsms
        NeedsSsrs    = $needsSsrs
        NeedsDpmBase = $needsDpmBase
        NeedsDpmUr   = $needsDpmUr
        AllDone      = (-not $needsSql -and -not $needsDpmUr)
    }
}

# ---- Service Verification & Startup Helpers -------------------------
# NOTE: By strict policy, this script NEVER disables any service.
function Get-ResolvedSqlServiceNames {
    $inst = $cfg.Sql.InstanceName
    if ([string]::IsNullOrWhiteSpace($inst) -or $inst -ieq 'MSSQLSERVER') {
        return @{
            Engine = 'MSSQLSERVER'
            Agent  = 'SQLSERVERAGENT'
        }
    }
    return @{
        Engine = "MSSQL`$$inst"
        Agent  = "SQLAgent`$$inst"
    }
}

function Start-AndVerifyService {
    param(
        [Parameter(Mandatory = $true)] [string] $ServiceName,
        [int] $TimeoutSeconds = 90
    )
    if ($script:DryRun) {
        Write-Log "[DRYRUN] Would verify service '$ServiceName' is Running (starting if needed)."
        return
    }
    $svc = Get-Service -Name $ServiceName -ErrorAction SilentlyContinue
    if ($null -eq $svc) {
        throw "Required service '$ServiceName' was not found on $env:COMPUTERNAME."
    }
    if ($svc.Status -ne 'Running') {
        Write-Log "Service '$ServiceName' is currently $($svc.Status). Starting service..."
        Start-Service -Name $ServiceName -ErrorAction Stop
        $svc.WaitForStatus('Running', [TimeSpan]::FromSeconds($TimeoutSeconds))
    }
    $svc.Refresh()
    if ($svc.Status -ne 'Running') {
        throw "Service '$ServiceName' did not reach 'Running' state (current: $($svc.Status))."
    }
    Write-Log "Verified service '$ServiceName' is Running."
}

function Ensure-SqlAndSsrsRunning {
    param([switch]$IncludeSsrs)
    $sqlSvcs = Get-ResolvedSqlServiceNames
    $timeout = [int]$cfg.Services.ServiceStartTimeoutSeconds

    Start-AndVerifyService -ServiceName $sqlSvcs.Engine -TimeoutSeconds $timeout
    Start-AndVerifyService -ServiceName $sqlSvcs.Agent  -TimeoutSeconds $timeout
    if ($IncludeSsrs) {
        Start-AndVerifyService -ServiceName $cfg.Ssrs.ServiceName -TimeoutSeconds $timeout
    }

    if (-not $script:DryRun) {
        $conn = Get-DpmDbConnection
        $null = Invoke-SqlExecution -ServerInstance $conn.ServerInstance -Database 'master' -Query 'SELECT 1 AS Ready;' -QueryTimeoutSeconds 30
        Write-Log "Verified SQL connectivity to [$($conn.ServerInstance)]."
    }
}

# ---- ReFS Backup Helpers (Strictly Lettered MBS ReFS Volume) --------
function Get-ReFsBackupRoot {
    if ($cfg.DpmBackup.ForceReFsDriveLetter) {
        $dl = $cfg.DpmBackup.ForceReFsDriveLetter.TrimEnd(':', '\')
        if (-not (Test-Path -LiteralPath "${dl}:\")) {
            throw "Forced ReFS drive '${dl}:\' is not accessible."
        }
        return "${dl}:\"
    }
    # All DPM servers use MBS and have a ReFS storage pool volume with a drive letter assigned.
    $refs = @(Get-Volume -ErrorAction SilentlyContinue | Where-Object { $_.FileSystem -eq 'ReFS' -and $_.DriveLetter })
    if ($refs.Count -eq 0) {
        throw 'No lettered ReFS volume found. Stopping pipeline so you can investigate.'
    }
    $chosen = $refs | Sort-Object -Property SizeRemaining -Descending | Select-Object -First 1
    Write-Log "ReFS volume chosen: DriveLetter='$($chosen.DriveLetter):\' Free=$([math]::Round($chosen.SizeRemaining / 1GB, 2))GB"
    return "$($chosen.DriveLetter):\"
}

function Test-TodaysBackupExists {
    param([Parameter(Mandatory = $true)] [string] $Reason) # Pre-SQL or Pre-UR4
    try {
        $root    = Get-ReFsBackupRoot
        $destDir = Join-Path -Path $root -ChildPath $cfg.DpmBackup.BackupSubFolder
        if (-not (Test-Path -LiteralPath $destDir)) { return $false }
        $conn    = Get-DpmDbConnection
        $today   = Get-Date -Format 'yyyyMMdd'
        $pattern = "$($conn.Database)_${Reason}_${today}_*.bak"
        $hit = Get-ChildItem -Path $destDir -Filter $pattern -ErrorAction SilentlyContinue | Select-Object -First 1
        if ($hit) {
            Write-Log "Backup for '$Reason' already exists today: $($hit.Name). Skipping."
            return $true
        }
        return $false
    } catch { return $false }
}

function Backup-DpmDatabase {
    param([Parameter(Mandatory = $true)] [string] $Reason) # Pre-SQL or Pre-UR4
    Ensure-SqlAndSsrsRunning
    if (Test-TodaysBackupExists -Reason $Reason) { return }
    if ($script:DryRun) {
        Write-Log "[DRYRUN] Would back up DPMDB (reason: $Reason) to lettered ReFS volume."
        return
    }

    $conn    = Get-DpmDbConnection
    $root    = Get-ReFsBackupRoot
    $destDir = Join-Path -Path $root -ChildPath $cfg.DpmBackup.BackupSubFolder
    if (-not (Test-Path -LiteralPath $destDir)) {
        New-Item -ItemType Directory -Path $destDir -Force | Out-Null
    }

    $sizeRow = Invoke-SqlExecution -ServerInstance $conn.ServerInstance -Database 'master' `
        -Query "SELECT CAST(SUM(size) * 8.0 / 1024 AS BIGINT) AS MB FROM sys.master_files WHERE database_id = DB_ID('$($conn.Database)')" `
        -QueryTimeoutSeconds 60
    $dbMb   = [double]$sizeRow.MB
    $vol    = Get-Volume -FilePath $root -ErrorAction SilentlyContinue
    $freeMb = if ($vol) { [double]$vol.SizeRemaining / 1MB } else { 0 }
    if ($freeMb -gt 0 -and $freeMb -lt ($dbMb * $cfg.DpmBackup.FreeSpaceFactor)) {
        throw "Not enough free space on ReFS ($root) for DPMDB backup. Need ~$([int]($dbMb * $cfg.DpmBackup.FreeSpaceFactor))MB, have $([int]$freeMb)MB."
    }

    $stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
    $bak   = Join-Path -Path $destDir -ChildPath ('{0}_{1}_{2}.bak' -f $conn.Database, $Reason, $stamp)
    Write-Log "Backing up DPMDB [$($conn.Database)] to '$bak' (reason: $Reason, dbSize ~$([int]$dbMb)MB)"
    $sql = "BACKUP DATABASE [$($conn.Database)] TO DISK = N'$bak' WITH COPY_ONLY, INIT, COMPRESSION, STATS = 5, NAME = N'DPMDB $Reason upgrade backup';"
    $null = Invoke-SqlExecution -ServerInstance $conn.ServerInstance -Database 'master' `
        -Query $sql -QueryTimeoutSeconds ([int]$cfg.DpmBackup.QueryTimeoutSeconds)

    if (-not (Test-Path -LiteralPath $bak)) {
        throw "Backup command returned but file not found at '$bak'. Verify SQL service account write access to '$destDir'."
    }
    Write-Log "DPMDB backup complete: $bak"
}

# ---- Attempt Counter Helpers ----------------------------------------
function Get-Attempts {
    param($State, [string]$Step)
    if ($State.Attempts.PSObject.Properties.Name -contains $Step) {
        return [int]$State.Attempts.$Step
    }
    return 0
}

function Add-Attempt {
    param($State, [string]$Step)
    $n = (Get-Attempts $State $Step) + 1
    if ($State.Attempts.PSObject.Properties.Name -contains $Step) {
        $State.Attempts.$Step = $n
    } else {
        $State.Attempts | Add-Member -NotePropertyName $Step -NotePropertyValue $n -Force
    }
    return $n
}

# =====================================================================
#  THE 12 INDIVIDUAL PIPELINE STEPS
# =====================================================================

function Step-SmartCopy {
    param($State, $Assessment)
    $share = if (-not [string]::IsNullOrWhiteSpace($SourceShare)) {
        $SourceShare
    } elseif (-not [string]::IsNullOrWhiteSpace($State.SourceShare)) {
        $State.SourceShare
    } else {
        $null
    }
    if ([string]::IsNullOrWhiteSpace($share)) {
        throw 'SourceShare is not set in state.json or parameters. Cannot perform SMART_COPY.'
    }

    $foldersToCopy = @()
    if ($Assessment.NeedsSql)     { $foldersToCopy += $cfg.Folders.SQL2022 }
    if ($Assessment.NeedsSsms)    { $foldersToCopy += $cfg.Folders.SSMS }
    if ($Assessment.NeedsSsrs)    { $foldersToCopy += $cfg.Folders.SSRS }
    if ($Assessment.NeedsDpmBase) { $foldersToCopy += $cfg.Folders.DPM2022 }
    if ($Assessment.NeedsDpmUr)   { $foldersToCopy += $cfg.Folders.DPM2022UR }
    $foldersToCopy = @($foldersToCopy | Select-Object -Unique)

    if ($foldersToCopy.Count -eq 0) {
        Write-Log 'SMART_COPY: All components are already at target versions. Nothing to copy.'
        return
    }

    Write-Log "SMART_COPY: Required component folders = $($foldersToCopy -join ', ') from '$share'"
    if ($script:DryRun) {
        Write-Log "[DRYRUN] Would map '$share' as [$($cfg.UpgradeAccount.UserName)], robocopy [$($foldersToCopy -join ', ')], and unblock files."
        return
    }

    if (-not (Test-Path -LiteralPath $cfg.LocalSetupRoot)) {
        New-Item -ItemType Directory -Path $cfg.LocalSetupRoot -Force | Out-Null
    }

    $user = $cfg.UpgradeAccount.UserName
    $pass = $cfg.UpgradeAccount.Password
    $timeoutMin = [int]$cfg.StepTimeoutMinutes.SMART_COPY

    & net.exe use "$share" /delete /y 2>$null | Out-Null
    $netOut = & net.exe use "$share" "$pass" /user:"$user" /persistent:no 2>&1
    if ($LASTEXITCODE -ne 0) {
        throw "SMART_COPY: Failed to authenticate to staging share '$share' as '$user': $($netOut -join ' ')"
    }

    try {
        foreach ($folder in $foldersToCopy) {
            $src = Join-Path -Path $share -ChildPath $folder
            $dst = Join-Path -Path $cfg.LocalSetupRoot -ChildPath $folder
            if (-not (Test-Path -LiteralPath $src)) {
                throw "SMART_COPY: Source folder not found on staging share: '$src'"
            }
            if (-not (Test-Path -LiteralPath $dst)) {
                New-Item -ItemType Directory -Path $dst -Force | Out-Null
            }
            $roboLog = Join-Path -Path $LogDir -ChildPath "robocopy_${folder}.log"
            $roboArgs = "`"$src`" `"$dst`" /E /J /XO /MT:32 /R:2 /W:5 /NFL /NDL /NP /LOG+:`"$roboLog`""
            Write-Log "SMART_COPY: Copying '$folder' from '$src' to '$dst'..."
            $proc = Start-Process -FilePath 'robocopy.exe' -ArgumentList $roboArgs -NoNewWindow -PassThru
            if (-not $proc.WaitForExit($timeoutMin * 60 * 1000)) {
                try { & taskkill.exe /PID $proc.Id /T /F 2>$null | Out-Null } catch {}
                throw "SMART_COPY: robocopy timed out after ${timeoutMin}m for folder '$folder'."
            }
            if ($proc.ExitCode -ge 8) {
                throw "SMART_COPY: robocopy failed for '$folder' with exit code $($proc.ExitCode). See '$roboLog'."
            }
            Write-Log "SMART_COPY: Folder '$folder' copy finished (robocopy exit code $($proc.ExitCode))."
        }

        Write-Log "SMART_COPY: Unblocking all files under '$($cfg.LocalSetupRoot)'..."
        Get-ChildItem -LiteralPath $cfg.LocalSetupRoot -Recurse -File -ErrorAction SilentlyContinue |
            ForEach-Object { Unblock-File -LiteralPath $_.FullName -ErrorAction SilentlyContinue }
    } finally {
        & net.exe use "$share" /delete /y 2>$null | Out-Null
    }
}

function Step-CancelDpmJobs {
    # Always runs before any upgrade (full SQL+DPM, partial DPM 2022, or partial UR4)
    # so no active backup jobs are running when upgrades begin.
    Ensure-SqlAndSsrsRunning
    if ($script:DryRun) {
        Write-Log '[DRYRUN] Would run CancelDpmJobs.sql against the DPM database.'
        return
    }
    $conn = Get-DpmDbConnection
    $prep = Join-Path -Path $cfg.OrchRoot -ChildPath $cfg.DpmDb.PrepSqlFile
    if (-not (Test-Path -LiteralPath $prep)) {
        throw "Cleanup SQL file not found: $prep"
    }
    $cap = [int]$cfg.DpmDb.MaxCancelSeconds
    Write-Log "CANCEL_DPM_JOBS: Running proven SQL on [$($conn.ServerInstance)].[$($conn.Database)] (cap ${cap}s)"

    $job = Start-Job -ScriptBlock {
        param($srv, $db, $file, $qt)
        if (-not (Get-Command Invoke-Sqlcmd -ErrorAction SilentlyContinue)) {
            Import-Module SqlServer -ErrorAction SilentlyContinue
            if (-not (Get-Command Invoke-Sqlcmd -ErrorAction SilentlyContinue)) {
                Import-Module SQLPS -ErrorAction SilentlyContinue
            }
        }
        if (Get-Command Invoke-Sqlcmd -ErrorAction SilentlyContinue) {
            Invoke-Sqlcmd -ServerInstance $srv -Database $db -InputFile $file -QueryTimeout $qt -ErrorAction Stop
        } else {
            $sqlText = Get-Content -LiteralPath $file -Raw -Encoding UTF8
            $connObj = New-Object System.Data.SqlClient.SqlConnection("Server=$srv;Database=$db;Integrated Security=True;Connection Timeout=30;")
            try {
                $connObj.Open()
                $cmd = $connObj.CreateCommand()
                $cmd.CommandText = $sqlText
                $cmd.CommandTimeout = $qt
                [void]$cmd.ExecuteNonQuery()
            } finally {
                $connObj.Dispose()
            }
        }
    } -ArgumentList $conn.ServerInstance, $conn.Database, $prep, $cap

    $sw = [System.Diagnostics.Stopwatch]::StartNew()
    while ($job.State -eq 'Running' -and $sw.Elapsed.TotalSeconds -lt $cap) {
        Start-Sleep -Seconds 5
        Write-Log "CANCEL_DPM_JOBS: still running... ($([int]$sw.Elapsed.TotalSeconds)s elapsed)"
    }
    if ($job.State -eq 'Running') {
        Stop-Job $job -ErrorAction SilentlyContinue
        Remove-Job $job -Force -ErrorAction SilentlyContinue
        throw "CANCEL_DPM_JOBS exceeded ${cap}s cap (SQL blocked). Treating as failure."
    }
    try {
        Receive-Job $job -ErrorAction Stop | Out-Null
    } catch {
        Remove-Job $job -Force -ErrorAction SilentlyContinue
        throw "CANCEL_DPM_JOBS SQL error: $($_.Exception.Message)"
    }
    Remove-Job $job -Force -ErrorAction SilentlyContinue
    Write-Log "CANCEL_DPM_JOBS complete in $([int]$sw.Elapsed.TotalSeconds)s."
}

function Step-Drivers {
    $sqlDir = Join-Path -Path $cfg.LocalSetupRoot -ChildPath $cfg.Folders.SQL2022

    $uninstallKeys = @(
        'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*',
        'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*'
    )
    foreach ($match in @($cfg.Drivers.OleDbProductMatch, $cfg.Drivers.OdbcProductMatch)) {
        $apps = @(Get-ItemProperty -Path $uninstallKeys -ErrorAction SilentlyContinue |
            Where-Object {
                $_.PSObject.Properties.Name -contains 'DisplayName' -and
                $_.DisplayName -like "*$match*" -and
                $_.PSChildName -match '^\{.*\}$'
            })
        foreach ($app in $apps) {
            Write-Log "Uninstalling existing driver: $($app.DisplayName)"
            Invoke-Installer -FilePath 'msiexec.exe' `
                -Arguments "/x `"$($app.PSChildName)`" /qn /norestart" `
                -TimeoutMinutes 15 `
                -SuccessCodes @(0, 1605, 3010) | Out-Null
        }
    }

    $oledb = Get-ChildItem -Path $sqlDir -Recurse -Filter $cfg.Drivers.OleDbMsiName -ErrorAction SilentlyContinue | Select-Object -First 1
    $odbc  = Get-ChildItem -Path $sqlDir -Recurse -Filter $cfg.Drivers.OdbcMsiName  -ErrorAction SilentlyContinue | Select-Object -First 1
    if (-not $script:DryRun) {
        if (-not $oledb) { throw "OLEDB MSI '$($cfg.Drivers.OleDbMsiName)' not found under $sqlDir" }
        if (-not $odbc)  { throw "ODBC MSI '$($cfg.Drivers.OdbcMsiName)' not found under $sqlDir" }
    }
    if ($oledb) {
        Invoke-Installer -FilePath 'msiexec.exe' `
            -Arguments "/i `"$($oledb.FullName)`" IACCEPTMSOLEDBSQLLICENSETERMS=YES /qn /norestart" `
            -TimeoutMinutes ([int]$cfg.StepTimeoutMinutes.DRIVERS) | Out-Null
    }
    if ($odbc) {
        Invoke-Installer -FilePath 'msiexec.exe' `
            -Arguments "/i `"$($odbc.FullName)`" IACCEPTMSODBCSQLLICENSETERMS=YES /qn /norestart" `
            -TimeoutMinutes ([int]$cfg.StepTimeoutMinutes.DRIVERS) | Out-Null
    }
}

function Step-Sql2022 {
    if ((Get-SqlMajorVersion) -ge [int]$cfg.TargetVersions.SqlMajorVersion) {
        Write-Log 'SQL already at target major version. Skipping.'
        return
    }
    $sqlSetup = Join-Path -Path (Join-Path -Path $cfg.LocalSetupRoot -ChildPath $cfg.Folders.SQL2022) -ChildPath $cfg.SetupFiles.SqlSetup

    if ([string]::IsNullOrWhiteSpace($cfg.Sql.ProductKey)) {
        throw 'Sql.ProductKey is empty in UpgradeConfig.psd1. The SQL upgrade requires /PID.'
    }
    $updateEnabled = if ($cfg.Sql.UpdateEnabled) { 'True' } else { 'False' }

    # Exact proven SQL Server 2022 upgrade switches
    $args = "/q /ACTION=Upgrade /INSTANCENAME=$($cfg.Sql.InstanceName) " +
            "/PID=$($cfg.Sql.ProductKey) " +
            "/UpdateEnabled=$updateEnabled " +
            "/IACCEPTSQLSERVERLICENSETERMS /SUPPRESSPRIVACYSTATEMENTNOTICE /ENU /INDICATEPROGRESS"

    Invoke-InstallerAsUser -FilePath $sqlSetup -Arguments $args `
        -TimeoutMinutes ([int]$cfg.StepTimeoutMinutes.SQL2022) `
        -UserName $cfg.UpgradeAccount.UserName -PlainPassword $cfg.UpgradeAccount.Password | Out-Null

    if (-not $script:DryRun) {
        $postMajor = Get-SqlMajorVersion
        if ($postMajor -lt [int]$cfg.TargetVersions.SqlMajorVersion) {
            throw "SQL2022 installer exited cleanly, but detected SQL major version is still $postMajor (expected >= $($cfg.TargetVersions.SqlMajorVersion))."
        }
        Write-Log "SQL2022 upgrade verified (Major Version = $postMajor)."
    }
}

function Step-Ssms {
    if ((Get-SsmsVersion) -ge [version]$cfg.TargetVersions.SsmsMinVersion) {
        Write-Log "SSMS already at or above $($cfg.TargetVersions.SsmsMinVersion). Skipping."
        return
    }
    $ssms = Join-Path -Path (Join-Path -Path $cfg.LocalSetupRoot -ChildPath $cfg.Folders.SSMS) -ChildPath $cfg.SetupFiles.SsmsSetup
    Invoke-Installer -FilePath $ssms -Arguments '/install /quiet /norestart' `
        -TimeoutMinutes ([int]$cfg.StepTimeoutMinutes.SSMS) | Out-Null
}

function Step-Ssrs {
    if ((Get-SsrsVersion) -ge [version]$cfg.TargetVersions.SsrsMinVersion) {
        Write-Log "SSRS already at or above $($cfg.TargetVersions.SsrsMinVersion). Skipping."
        return
    }
    $ssrs = Join-Path -Path (Join-Path -Path $cfg.LocalSetupRoot -ChildPath $cfg.Folders.SSRS) -ChildPath $cfg.SetupFiles.SsrsSetup
    Invoke-Installer -FilePath $ssrs -Arguments '/quiet /IAcceptLicenseTerms /norestart' `
        -TimeoutMinutes ([int]$cfg.StepTimeoutMinutes.SSRS) | Out-Null
}

function Step-SsrsTrustFix {
    if ($script:DryRun) {
        Write-Log '[DRYRUN] Would apply SSRS trust fix (unblock, CodeGroup, ACL, restart).'
        return
    }
    $s = $cfg.Ssrs

    # 1) Unblock the DPM installers and the trust DLL.
    $dpmDir = Join-Path -Path $cfg.LocalSetupRoot -ChildPath $cfg.Folders.DPM2022
    if (Test-Path -LiteralPath $dpmDir) {
        Get-ChildItem -Path $dpmDir -Recurse -File -ErrorAction SilentlyContinue |
            ForEach-Object { Unblock-File -LiteralPath $_.FullName -ErrorAction SilentlyContinue }
    }
    if (Test-Path -LiteralPath $s.TrustDllPath) {
        Unblock-File -LiteralPath $s.TrustDllPath -ErrorAction SilentlyContinue
    }

    # 2) Add a FullTrust CodeGroup for ReportSRV10.dll (idempotent).
    if (-not (Test-Path -LiteralPath $s.PolicyConfig)) {
        throw "rssrvpolicy.config not found: $($s.PolicyConfig)"
    }
    $backup = ('{0}.bak_{1:yyyyMMddHHmmss}' -f $s.PolicyConfig, (Get-Date))
    Copy-Item -LiteralPath $s.PolicyConfig -Destination $backup -Force
    Write-Log "Backed up rssrvpolicy.config to $backup"

    [xml]$xml = Get-Content -LiteralPath $s.PolicyConfig -Raw -Encoding UTF8
    $root = $xml.SelectSingleNode("//CodeGroup[@class='FirstMatchCodeGroup']")
    if (-not $root) { $root = $xml.SelectSingleNode('//CodeGroup') }
    if (-not $root) { throw 'No <CodeGroup> hierarchy found in rssrvpolicy.config' }
    $existing = $xml.SelectSingleNode("//CodeGroup[@Name='$($s.CodeGroupName)']")
    if (-not $existing) {
        $cg = $xml.CreateElement('CodeGroup')
        $cg.SetAttribute('class', 'UnionCodeGroup')
        $cg.SetAttribute('version', '1')
        $cg.SetAttribute('PermissionSetName', 'FullTrust')
        $cg.SetAttribute('Name', $s.CodeGroupName)
        $cg.SetAttribute('Description', 'Grants full trust to the ReportSRV10 assembly.')
        $mc = $xml.CreateElement('IMembershipCondition')
        $mc.SetAttribute('class', 'UrlMembershipCondition')
        $mc.SetAttribute('version', '1')
        $mc.SetAttribute('Url', $s.TrustDllPath)
        $cg.AppendChild($mc) | Out-Null
        $root.AppendChild($cg) | Out-Null
        $xml.Save($s.PolicyConfig)
        Write-Log "Added FullTrust CodeGroup '$($s.CodeGroupName)'."
    } else {
        Write-Log "CodeGroup '$($s.CodeGroupName)' already present. Skipping."
    }

    # 3) Grant Read & Execute on the DLL to the SSRS account + admins.
    if (Test-Path -LiteralPath $s.TrustDllPath) {
        $acl = Get-Acl -LiteralPath $s.TrustDllPath
        foreach ($acct in @($s.ServiceAccount, 'BUILTIN\Administrators')) {
            $rule = New-Object System.Security.AccessControl.FileSystemAccessRule($acct, 'ReadAndExecute', 'Allow')
            $acl.AddAccessRule($rule)
        }
        Set-Acl -LiteralPath $s.TrustDllPath -AclObject $acl
        Write-Log 'Granted Read & Execute on ReportSRV10.dll.'
    } else {
        Write-Log "ReportSRV10.dll not found yet at $($s.TrustDllPath). Permission step will re-run if needed." 'WARN'
    }

    # 4) Restart SSRS so it re-reads the policy file.
    if (Get-Service -Name $s.ServiceName -ErrorAction SilentlyContinue) {
        Restart-Service -Name $s.ServiceName -Force
        Start-AndVerifyService -ServiceName $s.ServiceName -TimeoutSeconds ([int]$cfg.Services.ServiceStartTimeoutSeconds)
        Write-Log "Restarted and verified SSRS service '$($s.ServiceName)'."
    } else {
        Write-Log "SSRS service '$($s.ServiceName)' not found; skipping restart." 'WARN'
    }
}

function New-DpmAnswerFile {
    param([Parameter(Mandatory = $true)] [string] $DpmDir)
    $template = Join-Path -Path $cfg.OrchRoot -ChildPath $cfg.Dpm.IniTemplate
    if (-not (Test-Path -LiteralPath $template)) {
        throw "DPM ini template not found: $template"
    }
    $ini = Get-Content -LiteralPath $template -Raw -Encoding UTF8
    $map = @{
        '{{DpmUserName}}'             = $cfg.UpgradeAccount.UserName
        '{{CompanyName}}'             = $cfg.Dpm.CompanyName
        '{{DPMProductKey}}'           = $cfg.Dpm.ProductKey
        '{{IntegratedInstallSource}}' = $DpmDir
        '{{LocalHostName}}'           = $env:COMPUTERNAME
        '{{SQLInstanceName}}'         = $cfg.Sql.InstanceName
        '{{SqlAccountPassword}}'      = $cfg.UpgradeAccount.Password
        '{{ReportingInstanceName}}'   = $cfg.Ssrs.ReportingInstanceName
    }
    foreach ($k in $map.Keys) {
        $ini = $ini.Replace($k, $map[$k])
    }
    $iniPath = Join-Path -Path $cfg.OrchRoot -ChildPath 'DpmUpgrade.ini'
    Set-Content -LiteralPath $iniPath -Value $ini -Encoding ASCII -Force
    return $iniPath
}

function Step-Dpm2022 {
    if ((Get-DpmBuild) -ge [version]$cfg.TargetVersions.DpmBaseMinBuild) {
        Write-Log "DPM 2022 base (>=$($cfg.TargetVersions.DpmBaseMinBuild)) already present. Skipping base upgrade."
        return
    }

    # Mandatory check: verify SQL Server and SSRS services are Running prior to DPM 2022 upgrade
    Write-Log 'DPM2022: Verifying SQL Server and SSRS services are Running before launching DPM 2022 setup...'
    Ensure-SqlAndSsrsRunning -IncludeSsrs

    $dpmDir   = Join-Path -Path $cfg.LocalSetupRoot -ChildPath $cfg.Folders.DPM2022
    $dpmSetup = Join-Path -Path $dpmDir -ChildPath $cfg.SetupFiles.DpmSetup
    if ($script:DryRun) {
        Write-Log "[DRYRUN] Would build answer file and run DPM setup: $dpmSetup /i /f <ini> /l <log>"
        return
    }

    $iniPath = New-DpmAnswerFile -DpmDir $dpmDir
    $log     = Join-Path -Path $LogDir -ChildPath 'DpmSetup.log'
    try {
        Invoke-InstallerAsUser -FilePath $dpmSetup -Arguments "/i /f `"$iniPath`" /l `"$log`"" `
            -TimeoutMinutes ([int]$cfg.StepTimeoutMinutes.DPM2022) `
            -UserName $cfg.UpgradeAccount.UserName -PlainPassword $cfg.UpgradeAccount.Password | Out-Null
    } finally {
        Remove-Item -LiteralPath $iniPath -Force -ErrorAction SilentlyContinue
    }

    $postBuild = Get-DpmBuild
    if ($postBuild -lt [version]$cfg.TargetVersions.DpmBaseMinBuild) {
        throw "DPM2022 setup returned exit code 0, but detected DPM build is $postBuild (expected >= $($cfg.TargetVersions.DpmBaseMinBuild)). Check $log."
    }
    Write-Log "DPM 2022 base upgrade verified (Build = $postBuild)."
}

function Step-DpmUr4 {
    if ((Get-DpmBuild) -ge [version]$cfg.TargetVersions.DpmUrMinBuild) {
        Write-Log "DPM already at UR target build ($($cfg.TargetVersions.DpmUrMinBuild)) or higher. Skipping."
        return
    }

    # Verify SQL Server services are running prior to UR4 upgrade
    Ensure-SqlAndSsrsRunning -IncludeSsrs

    $ur = Join-Path -Path (Join-Path -Path $cfg.LocalSetupRoot -ChildPath $cfg.Folders.DPM2022UR) -ChildPath $cfg.SetupFiles.DpmUrSetup
    Invoke-Installer -FilePath $ur -Arguments '/q /norestart' `
        -TimeoutMinutes ([int]$cfg.StepTimeoutMinutes.DPM_UR4) | Out-Null

    if (-not $script:DryRun) {
        $postBuild = Get-DpmBuild
        if ($postBuild -lt [version]$cfg.TargetVersions.DpmUrMinBuild) {
            throw "DPM_UR4 installer exited cleanly, but detected DPM build is $postBuild (expected >= $($cfg.TargetVersions.DpmUrMinBuild))."
        }
        Write-Log "DPM UR upgrade verified (Build = $postBuild)."
    }
}

function Step-VerifyServices {
    # Runs after the 3rd reboot to confirm all SQL, SSRS, and Core DPM services are Running.
    Write-Log 'VERIFY_SERVICES: Checking SQL Server, SSRS, and Core DPM services after final reboot...'
    Ensure-SqlAndSsrsRunning -IncludeSsrs

    $timeout = [int]$cfg.Services.ServiceStartTimeoutSeconds
    foreach ($svcName in $cfg.Services.CoreDpmServices) {
        if ($script:DryRun) {
            Write-Log "[DRYRUN] Would verify DPM service '$svcName' is Running."
            continue
        }
        $svc = Get-Service -Name $svcName -ErrorAction SilentlyContinue
        if ($null -eq $svc) {
            throw "Core DPM service '$svcName' is not installed on $env:COMPUTERNAME."
        }
        Start-AndVerifyService -ServiceName $svcName -TimeoutSeconds $timeout
    }
    Write-Log 'VERIFY_SERVICES: All SQL, SSRS, and Core DPM services are Running.'
}

# =====================================================================
#  THE STATE MACHINE ORCHESTRATOR (12 STEPS, 3 REBOOTS)
# =====================================================================
function Invoke-Pipeline {
    $state = Get-State
    if (-not [string]::IsNullOrWhiteSpace($SourceShare)) {
        $state.SourceShare = $SourceShare
    }

    if ($state.Status -in @('DONE', 'SKIPPED', 'FAILED')) {
        Write-Log "Pipeline already in terminal state ($($state.Status)). Cleaning up resume task."
        Unregister-ResumeTask
        return
    }

    $assessment = Get-ComponentAssessment
    $state.SqlVersion = [string]$assessment.SqlMajor
    $state.DpmBuild   = $assessment.DpmBuild.ToString()

    # Initial pre-check: if nothing has run yet and SQL + DPM UR already meet TargetVersions, skip whole server.
    if ($state.Step -in @('INIT', 'SMART_COPY') -and $state.Completed.Count -eq 0) {
        if ((-not $script:DryRun) -and $assessment.AllDone) {
            Write-Log "Server already meets TargetVersions (SQL Major=$($assessment.SqlMajor), DPM Build=$($assessment.DpmBuild)). Marking SKIPPED."
            $state.Step   = 'DONE'
            $state.Status = 'SKIPPED'
            $state.Detail = "Already at target SQL ($($assessment.SqlMajor)) + DPM ($($assessment.DpmBuild))"
            Save-State $state
            Unregister-ResumeTask
            return
        }
        Grant-BatchLogonRight -AccountName $cfg.UpgradeAccount.UserName
        Register-ResumeTask -EffectiveSourceShare $state.SourceShare
    }

    Start-Heartbeat

    # Define the 12-step pipeline with dynamic component skip rules:
    # - CANCEL_DPM_JOBS ALWAYS runs before any full or partial upgrade.
    # - DPM_UR4 triggers the 3rd reboot, followed by VERIFY_SERVICES.
    $Pipeline = @(
        @{
            Name        = 'SMART_COPY'
            ShouldRun   = { $true }
            Action      = { Step-SmartCopy -State $state -Assessment $assessment }
            RebootAfter = $false
        }
        @{
            Name        = 'CANCEL_DPM_JOBS'
            ShouldRun   = { $true } # Always runs before SQL, DPM 2022, or UR4 upgrade
            Action      = { Step-CancelDpmJobs }
            RebootAfter = $false
        }
        @{
            Name        = 'DRIVERS'
            ShouldRun   = { $assessment.NeedsSql }
            Action      = { Step-Drivers }
            RebootAfter = $false
        }
        @{
            Name        = 'BACKUP_PRE_SQL'
            ShouldRun   = { $assessment.NeedsSql }
            Action      = { Backup-DpmDatabase -Reason 'Pre-SQL' }
            RebootAfter = $false
        }
        @{
            Name        = 'SQL2022'
            ShouldRun   = { $assessment.NeedsSql }
            Action      = { Step-Sql2022 }
            RebootAfter = $false
        }
        @{
            Name        = 'SSMS'
            ShouldRun   = { $assessment.NeedsSsms }
            Action      = { Step-Ssms }
            RebootAfter = $false
        }
        @{
            Name        = 'SSRS'
            ShouldRun   = { $assessment.NeedsSsrs }
            Action      = { Step-Ssrs }
            RebootAfter = $false
        }
        @{
            Name        = 'SSRS_TRUSTFIX'
            ShouldRun   = { $assessment.NeedsSql -or $assessment.NeedsSsrs -or $assessment.NeedsDpmBase }
            Action      = { Step-SsrsTrustFix }
            RebootAfter = $true  # REBOOT 1
        }
        @{
            Name        = 'DPM2022'
            ShouldRun   = { $assessment.NeedsDpmBase }
            Action      = { Step-Dpm2022 }
            RebootAfter = $true  # REBOOT 2
        }
        @{
            Name        = 'BACKUP_PRE_UR4'
            ShouldRun   = { $assessment.NeedsDpmUr }
            Action      = { Backup-DpmDatabase -Reason 'Pre-UR4' }
            RebootAfter = $false
        }
        @{
            Name        = 'DPM_UR4'
            ShouldRun   = { $assessment.NeedsDpmUr }
            Action      = { Step-DpmUr4 }
            RebootAfter = $true  # REBOOT 3
        }
        @{
            Name        = 'VERIFY_SERVICES'
            ShouldRun   = { $true }
            Action      = { Step-VerifyServices }
            RebootAfter = $false
        }
    )

    $maxAttempts = [int]$cfg.MaxAttemptsPerStep
    if ($maxAttempts -lt 1) { $maxAttempts = 1 }

    foreach ($step in $Pipeline) {
        $name = $step.Name
        if ($state.Completed -contains $name) {
            continue
        }

        $isRequired = & $step.ShouldRun
        if (-not $isRequired) {
            Write-Log "Step '$name' is not required (component already at target version). Skipping step."
            $state.Completed += $name
            $state.Detail = "Skipped $name (already at target version)"
            Save-State $state
            continue
        }

        $stepSuccess = $false
        while ((Get-Attempts $state $name) -lt $maxAttempts) {
            $attempt = Add-Attempt $state $name
            $state.Step   = $name
            $state.Status = 'RUNNING'
            $state.Detail = "Running $name (attempt $attempt of $maxAttempts)"
            Save-State $state
            Write-Log "=== STEP $name (attempt $attempt of $maxAttempts) ==="

            try {
                & $step.Action
                $stepSuccess = $true
                break
            } catch {
                $errMsg = $_.Exception.Message
                $state.LastError = $errMsg
                $state.Detail    = "Error on $name (attempt $attempt): $errMsg"
                Save-State $state
                Write-Log "STEP $name FAILED (attempt $attempt of $maxAttempts): $errMsg" 'ERROR'

                if ($attempt -lt $maxAttempts) {
                    Write-Log "Retrying step $name in 15 seconds..." 'WARN'
                    Start-Sleep -Seconds 15
                }
            }
        }

        if (-not $stepSuccess) {
            $state.Status = 'FAILED'
            $state.Detail = "FAILED on step ${name}: $($state.LastError)"
            Save-State $state
            Write-Log "Max attempts ($maxAttempts) reached for $name. Marking server FAILED." 'ERROR'
            Stop-Heartbeat
            Unregister-ResumeTask
            return
        }

        # Refresh detected versions after each completed step
        $assessment       = Get-ComponentAssessment
        $state.SqlVersion = [string]$assessment.SqlMajor
        $state.DpmBuild   = $assessment.DpmBuild.ToString()
        $state.Completed += $name
        $state.LastError  = ''
        $state.Step       = $name
        $state.Status     = 'RUNNING'
        $state.Detail     = "Completed $name"
        Save-State $state
        Write-Log "STEP $name complete."

        if ($step.RebootAfter) {
            Register-ResumeTask -EffectiveSourceShare $state.SourceShare
            $state.Status = 'REBOOTING'
            $state.Detail = "Rebooting after $name"
            Save-State $state
            Write-Log "Rebooting now (after $name). Resume scheduled task will continue after boot."
            Stop-Heartbeat
            Restart-Computer -Force
            exit 0
        }
    }

    $finalAssessment  = Get-ComponentAssessment
    $state.SqlVersion = [string]$finalAssessment.SqlMajor
    $state.DpmBuild   = $finalAssessment.DpmBuild.ToString()
    $state.Status     = 'DONE'
    $state.Step       = 'DONE'
    $state.Detail     = "Upgrade complete (SQL Major=$($state.SqlVersion), DPM Build=$($state.DpmBuild))"
    Save-State $state
    Write-Log 'ALL STEPS COMPLETE. Server upgrade finished and all services verified Running.'
    Stop-Heartbeat
    Unregister-ResumeTask
}

# =====================================================================
#  ENTRYPOINT WITH SINGLE-INSTANCE MUTEX GUARD
# =====================================================================
try {
    $script:AgentMutex = New-Object System.Threading.Mutex($false, $script:AgentMutexName)
    try {
        $script:HasAgentMutex = $script:AgentMutex.WaitOne([TimeSpan]::FromSeconds(5))
    } catch [System.Threading.AbandonedMutexException] {
        $script:HasAgentMutex = $true
    }

    if (-not $script:HasAgentMutex) {
        Write-Log 'Another instance of Invoke-ServerUpgrade.ps1 is already running on this server. Exiting.' 'WARN'
        exit 0
    }

    Write-Log "Agent started. Resume=$($Resume.IsPresent) DryRun=$($script:DryRun)"
    Invoke-Pipeline
} catch {
    Write-Log "Agent run ended with fatal error: $($_.Exception.Message)" 'ERROR'
    Stop-Heartbeat
    exit 1
} finally {
    Stop-Heartbeat
    if ($script:HasAgentMutex -and $null -ne $script:AgentMutex) {
        try { $script:AgentMutex.ReleaseMutex() } catch {}
    }
    if ($null -ne $script:AgentMutex) {
        $script:AgentMutex.Dispose()
    }
}
