# =====================================================================
#  UpgradeConfig.psd1 - SINGLE SOURCE OF TRUTH CONFIGURATION
#  All paths, credentials, target versions, concurrency limits,
#  installer parameters, and timeouts are configured here.
# =====================================================================
@{
    # -----------------------------------------------------------------
    # 1. REGIONAL STAGING SHARES & LOCAL ORCHESTRATION PATHS
    # -----------------------------------------------------------------
    # Where setups are copied FROM, selected by the inventory "Location" column.
    RegionSources = @{
        APAC = '\\apac-staging\New_Setups'
        EMEA = '\\emea-staging\New_Setups'
        SCNA = '\\scna-staging\New_Setups'
    }

    # Where setups are copied TO on each target server.
    LocalSetupRoot = 'C:\DPM_Upgrade_Data\New_Setups'

    # Working folder on each target server (state.json, logs, local agent files).
    OrchRoot = 'C:\DPM_Upgrade_Data\Orchestrator'

    # Controller output files on the launcher / regional jump box.
    DashboardCsv  = 'C:\DPM_Upgrade_Data\FleetStatus.csv'
    ControllerLog = 'C:\DPM_Upgrade_Data\Controller.log'

    # Child folder names inside the setup root (both on staging share & local disk).
    Folders = @{
        SQL2022   = 'SQL2022'
        SSMS      = 'SSMS'
        SSRS      = 'SSRS'
        DPM2022   = 'DPM2022'
        DPM2022UR = 'DPM2022_UR4'
    }

    # Setup executable names inside each component folder.
    SetupFiles = @{
        SqlSetup   = 'setup.exe'
        SsmsSetup  = 'setup.exe'
        SsrsSetup  = 'setup.exe'
        DpmSetup   = 'setup.exe'
        DpmUrSetup = 'setup.exe'
    }

    # -----------------------------------------------------------------
    # 2. UPGRADE SERVICE ACCOUNT (USED AUTOMATICALLY EVERYWHERE)
    # -----------------------------------------------------------------
    # Used automatically for:
    #   - Controller WinRM connections (no interactive Get-Credential popup)
    #   - Authenticating to regional staging shares during SMART_COPY
    #   - Running SQL 2022 and DPM 2022 installers (holds Local Admin & SQL rights)
    #   - Populating the DPM unattended answer file
    UpgradeAccount = @{
        UserName = 'domain\svc_dpm_upgrade'
        Password = 'P@ssw0rd'
    }

    # -----------------------------------------------------------------
    # 3. CUSTOMIZABLE TARGET VERSIONS (PRE-CHECK, SMART COPY & VERIFY)
    # -----------------------------------------------------------------
    # Controls component-level skip decisions, selective folder copying,
    # and post-install version verification gates.
    TargetVersions = @{
        SqlMajorVersion = 16            # SQL Server 2022 major version (16.x)
        SsmsMinVersion  = '19.0.0.0'    # Minimum SSMS version to consider upgraded
        SsrsMinVersion  = '15.0.0.0'    # Minimum SSRS version to consider upgraded
        DpmBaseMinBuild = '10.22.123.0' # SCDPM 2022 RTM base minimum build
        DpmUrMinBuild   = '10.22.506.0' # SCDPM 2022 UR4 minimum build (update for future URs)
    }

    # -----------------------------------------------------------------
    # 4. FLEET CONCURRENCY, RETRY & WATCHDOG TIMING
    # -----------------------------------------------------------------
    MaxParallelCopies    = 1   # Max servers running SMART_COPY per region at once
    MaxParallelUpgrades  = 2   # Max servers actively upgrading at once per controller run
    MaxAttemptsPerStep   = 2   # In-process retry limit per step before marking FAILED
    MaxRebootWaitMinutes = 30  # Max minutes a rebooting server can stay offline before STUCK eviction
    HeartbeatSeconds     = 30  # Agent heartbeat & controller polling interval (seconds)

    # Per-step hard timeout budgets (minutes) for installer watchdogs & stuck eviction.
    StepTimeoutMinutes = @{
        SMART_COPY      = 180
        CANCEL_DPM_JOBS = 5
        DRIVERS         = 20
        BACKUP_PRE_SQL  = 60
        SQL2022         = 120
        SSMS            = 45
        SSRS            = 60
        SSRS_TRUSTFIX   = 15
        DPM2022         = 180
        BACKUP_PRE_UR4  = 60
        DPM_UR4         = 90
        VERIFY_SERVICES = 15
    }

    # -----------------------------------------------------------------
    # 5. SQL SERVER & DRIVER CONFIGURATION
    # -----------------------------------------------------------------
    Sql = @{
        InstanceName  = 'MSSQLSERVER'
        ProductKey    = 'XXXXX-XXXXX-XXXXX-XXXXX-XXXXX'
        UpdateEnabled = $false
    }

    Drivers = @{
        OleDbMsiName      = 'msoledbsql.msi'
        OdbcMsiName       = 'msodbcsql.msi'
        OleDbProductMatch = 'OLE DB Driver'
        OdbcProductMatch  = 'ODBC Driver'
    }

    # -----------------------------------------------------------------
    # 6. SSRS & TRUST-FIX CONFIGURATION
    # -----------------------------------------------------------------
    Ssrs = @{
        ReportingInstanceName = 'SSRS'
        PolicyConfig          = 'C:\Program Files\Microsoft SQL Server Reporting Services\SSRS\ReportServer\rssrvpolicy.config'
        TrustDllPath          = 'C:\Program Files\Microsoft SQL Server Reporting Services\SSRS\ReportServer\bin\ReportSRV10.dll'
        ServiceName           = 'SQLServerReportingServices'
        ServiceAccount        = 'NT AUTHORITY\NETWORK SERVICE'
        CodeGroupName         = 'DPM_ReportSRV10_Extension'
    }

    # -----------------------------------------------------------------
    # 7. SCDPM 2022 UNATTENDED UPGRADE CONFIGURATION
    # -----------------------------------------------------------------
    # Note: Sql.InstanceName, Ssrs.ReportingInstanceName, and UpgradeAccount
    # are automatically shared with the DPM answer file generator (no duplication).
    Dpm = @{
        CompanyName = 'My_Organization'
        ProductKey  = 'XXXXX-XXXXX-XXXXX-XXXXX-XXXXX'
        IniTemplate = 'DpmUpgrade.ini.template'
    }

    # -----------------------------------------------------------------
    # 8. DPM DATABASE JOB CANCELLATION & REFS BACKUP SETTINGS
    # -----------------------------------------------------------------
    DpmDb = @{
        PrepSqlFile         = 'CancelDpmJobs.sql'
        MaxCancelSeconds    = 300
        QueryTimeoutSeconds = 300
    }

    DpmBackup = @{
        ForceReFsDriveLetter = ''                      # Leave empty to auto-pick lettered ReFS volume with most free space
        BackupSubFolder      = 'DPMDB_Upgrade_Backups'
        FreeSpaceFactor      = 1.2
        QueryTimeoutSeconds  = 3600
    }

    # -----------------------------------------------------------------
    # 9. SERVICE VERIFICATION SETTINGS
    # -----------------------------------------------------------------
    # SQL services (MSSQLSERVER / MSSQL$<InstanceName> and SQLSERVERAGENT / SQLAgent$<InstanceName>)
    # plus Ssrs.ServiceName are verified prior to DPM2022, prior to BACKUP_PRE_UR4/DPM_UR4,
    # and after the 3rd reboot alongside CoreDpmServices.
    Services = @{
        CoreDpmServices            = @('MSDPM', 'DPMRA', 'DPMLA', 'DPMMAC', 'DPMWriter')
        ServiceStartTimeoutSeconds = 90
    }
}
