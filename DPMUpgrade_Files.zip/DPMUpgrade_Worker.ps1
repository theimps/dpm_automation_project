<#
.SYNOPSIS
    Operation Ironclad - DPM FreshInstall Worker v20.8 FULL REPLACEMENT
.DESCRIPTION
    Full replacement worker for fresh install. Uses known-good SSRS and SSMS switches from successful upgrade scripts.
.VERSION
    FULL_REPLACEMENT_WORKER_v20_8_20260706_FIXED
.FIXES
    - Write-PhaseState: retry loop on Move-Item (file-lock contention protection)
    - Test-RebootPending: added PendingFileRenameOperations registry check
    - Invoke-ProcessChecked: captures stdout/stderr to log; handles empty WorkingDirectory
    - Invoke-SSRSSMSInstall: triggers reboot on exit code 3010 or pending-reboot flag
      so SSRSConfigure always finds a running WMI provider after a clean restart
    - Invoke-SSRSConfigure: HRESULT validated after each WMI call (was [void]/silent)
    - Invoke-SSRSConfigure: InitializeReportServer called to complete SSRS initialisation
    - New-DPMSetupIni: IntegratedInstallSource derived from DPMSetupRelativePath (was hardcoded)
    - Invoke-DPMSetup: setup.exe invoked directly (removed cmd.exe /c start /wait wrapper
      which loses exit codes and misquotes paths containing spaces)
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory)][string]$Phase,
    [Parameter(Mandatory)][string]$ConfigPath,
    [Parameter(Mandatory)][string]$ServerName,
    [string]$LocationB64 = '',
    [string]$RunId       = ''
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$Root      = 'C:\DPM_Data'
$StatusDir = Join-Path $Root 'Status'
$LogDir    = Join-Path $Root 'Logs'
$TempDir   = Join-Path $Root 'Temp'
$Timestamp = Get-Date -Format yyyyMMdd_HHmmss

foreach ($d in @($StatusDir,$LogDir,$TempDir,(Join-Path $Root 'Reports'),(Join-Path $Root 'Backup'))) {
    New-Item -ItemType Directory -Force -Path $d | Out-Null
}
Start-Transcript -Path (Join-Path $LogDir "Worker_${Phase}_${env:COMPUTERNAME}_${Timestamp}.log") -Force | Out-Null

try   { $Location = if ($LocationB64) { [Text.Encoding]::Unicode.GetString([Convert]::FromBase64String($LocationB64)) } else { '' } }
catch { $Location = '' }

function Write-Log    { param([string]$Message,[string]$Level='INFO') $color=switch($Level){'ERROR'{'Red'}'WARN'{'Yellow'}'OK'{'Green'}'HEAD'{'Cyan'}'STEP'{'Magenta'}default{'White'}}; Write-Host "[$(Get-Date -Format HH:mm:ss)] [$Phase] $Message" -ForegroundColor $color }
function Write-Header { param([string]$Title) Write-Host "`n========== $Title ==========" -ForegroundColor Cyan }

function Import-ConfigMap {
    param([string]$Path)
    if (-not (Test-Path $Path)) { throw "Config not found: $Path" }
    $m = @{}
    foreach ($r in Import-Csv $Path) { if ($r.ConfigName) { $m[$r.ConfigName.Trim()] = [string]$r.ConfigValue } }
    return $m
}
$Config = Import-ConfigMap $ConfigPath

function Get-Cfg     { param([string]$Name,[string]$Default='') if($Config.ContainsKey($Name)){ $v=[string]$Config[$Name]; if(-not [string]::IsNullOrWhiteSpace($v) -and $v -notlike '<REPLACE*'){return $v}}; return $Default }
function Get-CfgBool { param([string]$Name,[bool]$Default=$false) $v=Get-Cfg $Name ''; if([string]::IsNullOrWhiteSpace($v)){return $Default}; return ($v -match '^(1|true|yes|y)$') }

$InstallMode = Get-Cfg InstallMode FreshInstall

# ── Write-PhaseState ──────────────────────────────────────────────────────────
# FIX: retry loop protects against transient file-lock contention on the JSON file
function Write-PhaseState {
    param([string]$Step,[string]$Status,[string]$Message='',[int]$ExitCode=0,[bool]$RebootPending=$false)
    $o    = [pscustomobject]@{
        ServerName     = $env:COMPUTERNAME
        RunId          = $RunId
        CurrentPhase   = $Phase
        CurrentStep    = $Step
        Status         = $Status
        Message        = $Message
        LastExitCode   = $ExitCode
        RebootPending  = $RebootPending
        TimestampUtc   = (Get-Date).ToUniversalTime().ToString('s') + 'Z'
    }
    $tmp   = Join-Path $StatusDir 'PhaseState.tmp'
    $final = Join-Path $StatusDir 'PhaseState.json'
    $json  = $o | ConvertTo-Json -Compress
    for ($i = 1; $i -le 5; $i++) {
        try {
            Set-Content  $tmp   $json -Encoding UTF8 -ErrorAction Stop
            Move-Item    $tmp   $final -Force        -ErrorAction Stop
            return
        } catch {
            if ($i -eq 5) { Write-Log "Write-PhaseState failed after 5 retries: $($_.Exception.Message)" WARN }
            else           { Start-Sleep -Milliseconds (200 * $i) }
        }
    }
}

function Set-Step      { param([string]$Step) Write-PhaseState $Step Running; Write-Log $Step STEP }
function Write-CsvRow  { param([string]$Path,[hashtable]$Row) $obj=[pscustomobject]$Row; if(Test-Path $Path){$obj|Export-Csv $Path -Append -NoTypeInformation -Force}else{$obj|Export-Csv $Path -NoTypeInformation} }
function Get-SafePropertyValue { param($Object,[string]$Name) if($null -eq $Object){return $null}; $p=$Object.PSObject.Properties[$Name]; if($p){return $p.Value}; return $null }
function Test-AcceptedExitCode         { param([int]$ExitCode) return ($ExitCode -in @(0,3010,1641)) }
function Test-AcceptedUninstallExitCode{ param([int]$ExitCode) return ($ExitCode -in @(0,1605,3010,1641)) }

function Mask-Secret {
    param([string]$Text)
    foreach ($s in @((Get-Cfg SQLProductKey),(Get-Cfg DPMProductKey),(Get-Cfg SQLServicePassword),(Get-Cfg DPMSetupRunAsPassword))) {
        if ($s) { $Text = $Text.Replace($s,'********') }
    }
    return $Text
}

# ── Invoke-ProcessChecked ─────────────────────────────────────────────────────
# FIX: captures stdout and stderr to the log file so failed installers are diagnosable
# FIX: guards against empty WorkingDirectory (Start-Process errors on empty string)
function Invoke-ProcessChecked {
    param([string]$FilePath,[string]$Arguments,[string]$WorkingDirectory,[string]$LogPath)
    $tmpOut = [IO.Path]::GetTempFileName()
    $tmpErr = [IO.Path]::GetTempFileName()
    try {
        "Command: $FilePath $(Mask-Secret $Arguments)" | Set-Content $LogPath -Encoding UTF8
        $startArgs = @{
            FilePath               = $FilePath
            ArgumentList           = $Arguments
            Wait                   = $true
            PassThru               = $true
            NoNewWindow            = $true
            RedirectStandardOutput = $tmpOut
            RedirectStandardError  = $tmpErr
        }
        if (-not [string]::IsNullOrWhiteSpace($WorkingDirectory)) {
            $startArgs['WorkingDirectory'] = $WorkingDirectory
        }
        $p      = Start-Process @startArgs
        $stdout = Get-Content $tmpOut -Raw -ErrorAction SilentlyContinue
        $stderr = Get-Content $tmpErr -Raw -ErrorAction SilentlyContinue
        @("ExitCode: $($p.ExitCode)", "--- STDOUT ---", $stdout, "--- STDERR ---", $stderr) |
            Add-Content $LogPath -Encoding UTF8
        return [pscustomobject]@{ ExitCode = $p.ExitCode; StdOut = $stdout; StdErr = $stderr }
    }
    finally { Remove-Item $tmpOut,$tmpErr -Force -ErrorAction SilentlyContinue }
}

function Replace-Placeholders {
    param([string]$Text)
    foreach ($k in $Config.Keys) { $Text = $Text.Replace("{{$k}}", [string]$Config[$k]) }
    return $Text
}

# ── Test-RebootPending ────────────────────────────────────────────────────────
# FIX: added PendingFileRenameOperations check (catches reboots required by file replacements)
function Test-RebootPending {
    foreach ($p in @(
        'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending',
        'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired'
    )) { if (Test-Path $p) { return $true } }
    try {
        $val = Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager' `
                                -Name PendingFileRenameOperations -ErrorAction Stop
        if ($val.PendingFileRenameOperations) { return $true }
    } catch {}
    return $false
}

function Get-SSRSService {
    Get-Service -ErrorAction SilentlyContinue |
        Where-Object { ($_.Name -eq 'SQLServerReportingServices') -or
                       ($_.Name -like '*ReportServer*') -or
                       ($_.DisplayName -like '*Reporting Services*') } |
        Sort-Object { if ($_.Name -eq 'SQLServerReportingServices') { 0 } else { 1 } } |
        Select-Object -First 1
}

# Get-SSRSWmiObject uses Get-WmiObject intentionally: WMI method invocation
# (SetDatabaseConnection, SetVirtualDirectory, ReserveURL, InitializeReportServer)
# requires a WMI management object; Get-CimInstance returns a CIM object where
# methods must go through Invoke-CimMethod with a different calling convention.
# This script targets Windows PowerShell 5.1 where Get-WmiObject is fully supported.
function Get-SSRSWmiObject {
    $base = 'root\Microsoft\SqlServer\ReportServer'
    $inst = (Get-WmiObject -Namespace $base -Class __Namespace -ErrorAction Stop | Select-Object -First 1).Name
    $ver  = (Get-WmiObject -Namespace "$base\$inst" -Class __Namespace -ErrorAction Stop |
                Where-Object { $_.Name -like 'v*' } | Sort-Object Name -Descending | Select-Object -First 1).Name
    return Get-WmiObject -Namespace "$base\$inst\$ver\Admin" -Class MSReportServer_ConfigurationSetting -ErrorAction Stop
}

function Test-DbOnline {
    param([string]$DatabaseName)
    try {
        Import-Module SqlServer -ErrorAction SilentlyContinue
        $r = Invoke-Sqlcmd -ServerInstance $env:COMPUTERNAME -Database master `
                           -Query "SELECT state_desc FROM sys.databases WHERE name=N'$DatabaseName'" `
                           -QueryTimeout 0 -ErrorAction Stop
        return ($r.state_desc -eq 'ONLINE')
    } catch { return $false }
}

function Test-ReportServerUrl {
    foreach ($url in @('http://localhost/ReportServer',"http://$env:COMPUTERNAME/ReportServer")) {
        for ($i=1; $i -le 4; $i++) {
            try {
                $r = Invoke-WebRequest -Uri $url -UseDefaultCredentials -UseBasicParsing -TimeoutSec 25 -ErrorAction Stop
                if ($r.StatusCode -ge 200 -and $r.StatusCode -lt 500) { return $true }
            } catch { Start-Sleep 10 }
        }
    }
    return $false
}

function Get-FeatureState {
    param([string]$FeatureName)
    $o = & dism.exe /Online /Get-FeatureInfo /FeatureName:$FeatureName 2>$null
    $l = $o | Where-Object { $_ -match '^State\s*:' } | Select-Object -First 1
    if ($l) { return ($l -replace '^State\s*:\s*','').Trim() }
    return ''
}

# ══════════════════════════════════════════════════════════════════════════════
# Phase functions
# ══════════════════════════════════════════════════════════════════════════════

function Invoke-Precheck {
    Write-Header PRECHECK
    Set-Step Precheck
    foreach ($rel in @((Get-Cfg SQLSetupRelativePath),(Get-Cfg DPMSetupRelativePath),(Get-Cfg SSRSSetupRelativePath))) {
        if ($rel) { $p = Join-Path $Root $rel; if (-not (Test-Path $p)) { throw "Missing setup file: $p" } }
    }
    Write-CsvRow "$StatusDir\Precheck_Status.csv" @{
        ServerName = $env:COMPUTERNAME; RunId = $RunId; Location = $Location
        Status = 'Success'; Timestamp = (Get-Date).ToString('s')
    }
}

function Uninstall-MsiByName {
    param([string]$NamePattern)
    $paths = @('HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*',
                'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*')
    $apps = Get-ItemProperty $paths -ErrorAction SilentlyContinue |
                Where-Object { $dn = Get-SafePropertyValue $_ DisplayName; $dn -and $dn -like $NamePattern }
    foreach ($a in $apps) {
        $dn   = Get-SafePropertyValue $a DisplayName
        $code = $a.PSChildName
        if ($code -match '^\{[0-9A-Fa-f-]+\}$') {
            $r = Invoke-ProcessChecked msiexec.exe "/x $code /quiet /norestart" $env:TEMP "$LogDir\Uninstall_$Timestamp.log"
            if ($r.ExitCode -notin @(0,1605,3010,1641)) { Write-Log "Uninstall returned $($r.ExitCode) for $dn" WARN }
        }
    }
}

function Invoke-RefreshODBCOLEDB {
    Write-Header 'REFRESH ODBC/OLEDB'
    Set-Step RefreshODBCOLEDB
    foreach ($i in @(
        @{Key='ODBCMsiRelativePath' ;License='IACCEPTMSODBCSQLLICENSETERMS=YES' ;Pattern='*ODBC Driver*SQL Server*';Label='ODBC' },
        @{Key='OLEDBMsiRelativePath';License='IACCEPTMSOLEDBSQLLICENSETERMS=YES';Pattern='*OLE DB Driver*SQL Server*';Label='OLEDB'}
    )) {
        $rel = Get-Cfg $i.Key
        if ($rel) {
            $msi = Join-Path $Root $rel
            if (Test-Path $msi) {
                Uninstall-MsiByName $i.Pattern
                $r = Invoke-ProcessChecked msiexec.exe "/i `"$msi`" $($i.License) /quiet /norestart" (Split-Path $msi -Parent) "$LogDir\Install_$($i.Label)_$Timestamp.log"
                if (-not (Test-AcceptedExitCode $r.ExitCode)) { throw "$($i.Label) installation failed with exit code $($r.ExitCode)" }
            }
        }
    }
    if (Test-RebootPending) {
        Write-PhaseState RefreshODBCOLEDB RebootPending 'Reboot required after ODBC/OLEDB refresh' 0 $true
        Restart-Computer -Force; exit 0
    }
}

function Test-Sql2022Installed {
    try {
        Import-Module SqlServer -ErrorAction SilentlyContinue
        $m = (Invoke-Sqlcmd -ServerInstance $env:COMPUTERNAME -Database master `
                             -Query "SELECT CAST(SERVERPROPERTY('ProductMajorVersion') AS int) Major" `
                             -ErrorAction Stop).Major
        return ([int]$m -eq 16)
    } catch { return $false }
}

function Invoke-SQLInstall {
    Write-Header 'SQL INSTALL'
    Set-Step SQLInstall
    if (Test-Sql2022Installed) { Write-Log 'SQL 2022 already installed; skipping SQLInstall' WARN; return }
    $setup = Join-Path $Root (Get-Cfg SQLSetupRelativePath)
    $arguments = Replace-Placeholders (Get-Cfg SQLInstallArguments)
    $r = Invoke-ProcessChecked $setup $arguments (Split-Path $setup -Parent) "$LogDir\SQL_Install_$Timestamp.log"
    if (-not (Test-AcceptedExitCode $r.ExitCode)) { throw "SQL install failed with exit code $($r.ExitCode)" }
    Write-PhaseState SQLInstall RebootPending 'Reboot after SQL install' $r.ExitCode $true
    Restart-Computer -Force; exit 0
}

function Invoke-PostSQL {
    Write-Header 'POST SQL VALIDATE'
    Set-Step PostSQLRebootValidate
    foreach ($s in 'MSSQLSERVER','SQLSERVERAGENT') {
        $svc = Get-Service $s -ErrorAction SilentlyContinue
        if ($svc -and $svc.Status -ne 'Running') { Start-Service $s; Start-Sleep 10 }
    }
}

function Test-SNACInstalled {
    $paths = @('HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*',
                'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*')
    return [bool](Get-ItemProperty $paths -ErrorAction SilentlyContinue |
                    Where-Object { $dn = Get-SafePropertyValue $_ DisplayName
                                   $dn -and ($dn -like '*SQL Server Native Client*' -or $dn -like '*SQL Native Client*') } |
                    Select-Object -First 1)
}

function Find-SNACInstaller {
    $rel = Get-Cfg SQLNativeClientSetupRelativePath
    if ($rel) { $p = Join-Path $Root $rel; if (Test-Path $p) { return $p } }
    return ''
}

function Install-SNAC {
    if (Test-SNACInstalled) { return $false }
    $installer = Find-SNACInstaller
    if (-not $installer) { throw 'SQL Native Client installer not found. Check SQLNativeClientSetupRelativePath.' }
    if ($installer -match '\.msi$') {
        $r = Invoke-ProcessChecked msiexec.exe "/i `"$installer`" IACCEPTSQLNCLILICENSETERMS=YES /quiet /norestart" (Split-Path $installer -Parent) "$LogDir\SNAC_$Timestamp.log"
    } else {
        $r = Invoke-ProcessChecked $installer '/quiet /norestart IACCEPTSQLNCLILICENSETERMS=YES' (Split-Path $installer -Parent) "$LogDir\SNAC_$Timestamp.log"
    }
    if (-not (Test-AcceptedExitCode $r.ExitCode)) { throw "SQL Native Client install failed with exit code $($r.ExitCode)" }
    return $true
}

function Get-SSRSSetupArguments {
    $key     = Get-Cfg SQLProductKey
    if ([string]::IsNullOrWhiteSpace($key)) { throw 'SQLProductKey missing for SSRS setup.' }
    $ssrsLog = "$LogDir\SSRS_Install_${env:COMPUTERNAME}_$Timestamp.log"
    return "/quiet /norestart /IAcceptLicenseTerms /PID=`"$key`" /log `"$ssrsLog`""
}

function Uninstall-ExistingSSRSForFreshInstall {
    $pattern = Get-Cfg SSRSUninstallDisplayNamePattern '*SQL Server Reporting Services*'
    $paths   = @('HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*',
                  'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*')
    $apps    = @(Get-ItemProperty $paths -ErrorAction SilentlyContinue |
                    Where-Object { $dn = Get-SafePropertyValue $_ DisplayName
                                   $dn -and ($dn -like $pattern -or $dn -like '*Reporting Services*') })
    $svc     = Get-SSRSService
    if (-not $svc -and $apps.Count -eq 0) { return $false }
    if ($svc) { Stop-Service $svc.Name -Force -ErrorAction SilentlyContinue; Start-Sleep 15 }
    foreach ($a in $apps) {
        $dn   = Get-SafePropertyValue $a DisplayName
        $code = $a.PSChildName
        if ($code -match '^\{[0-9A-Fa-f-]+\}$') {
            $r = Invoke-ProcessChecked msiexec.exe "/x $code /quiet /norestart" $env:TEMP "$LogDir\SSRS_Uninstall_$Timestamp.log"
            if ($r.ExitCode -eq 1605)                              { Write-Log "SSRS uninstall returned 1605 for [$dn]; continuing." WARN; continue }
            if (-not (Test-AcceptedUninstallExitCode $r.ExitCode)) { throw "SSRS uninstall failed for $dn. ExitCode=$($r.ExitCode)" }
        }
    }
    return $true
}

function Test-SSMSInstalled {
    $paths = @(
        'C:\Program Files (x86)\Microsoft SQL Server Management Studio 20\Common7\IDE\Ssms.exe',
        'C:\Program Files\Microsoft SQL Server Management Studio 20\Common7\IDE\Ssms.exe',
        'C:\Program Files (x86)\Microsoft SQL Server Management Studio 19\Common7\IDE\Ssms.exe',
        'C:\Program Files\Microsoft SQL Server Management Studio 19\Common7\IDE\Ssms.exe',
        'C:\Program Files (x86)\Microsoft SQL Server Management Studio 18\Common7\IDE\Ssms.exe',
        'C:\Program Files\Microsoft SQL Server Management Studio 18\Common7\IDE\Ssms.exe'
    )
    foreach ($p in $paths) { if (Test-Path $p) { return $true } }
    return $false
}

# ── Invoke-SSRSSMSInstall ─────────────────────────────────────────────────────
# FIX: if SSRS returns 3010 or leaves a pending-reboot flag, reboot immediately
#      so that SSRSConfigure always runs against a live, fully-initialised WMI provider
function Invoke-SSRSSMSInstall {
    Write-Header 'SSRS, SSMS, SNAC INSTALL'
    Set-Step SSRSSMSInstall
    if ($InstallMode -eq 'FreshInstall' -and (Get-CfgBool SSRSReinstallOnFreshInstall $true)) {
        [void](Uninstall-ExistingSSRSForFreshInstall)
    }
    if (-not (Get-SSRSService)) {
        $setup = Join-Path $Root (Get-Cfg SSRSSetupRelativePath)
        if (-not (Test-Path $setup)) { throw "SSRS setup missing: $setup" }
        $r = Invoke-ProcessChecked $setup (Get-SSRSSetupArguments) (Split-Path $setup -Parent) "$LogDir\SSRS_Process_$Timestamp.log"
        if (-not (Test-AcceptedExitCode $r.ExitCode)) { throw "SSRS setup failed with exit code $($r.ExitCode)" }
        # FIX: reboot now if required — SSRSConfigure needs the WMI provider to be up post-restart
        if ($r.ExitCode -eq 3010 -or (Test-RebootPending)) {
            Write-PhaseState SSRSSMSInstall RebootPending 'Reboot required after SSRS install' $r.ExitCode $true
            Restart-Computer -Force; exit 0
        }
    }
    $ssms = Join-Path $Root (Get-Cfg SSMSSetupRelativePath)
    if ((Test-Path $ssms) -and (-not (Test-SSMSInstalled))) {
        $r = Invoke-ProcessChecked $ssms '/install /quiet /norestart' (Split-Path $ssms -Parent) "$LogDir\SSMS_Install_$Timestamp.log"
        if (-not (Test-AcceptedExitCode $r.ExitCode)) { Write-Log "SSMS installer returned $($r.ExitCode); continuing" WARN }
    }
    Install-SNAC | Out-Null
}

function Invoke-PostSSRSReboot {
    Write-Header 'POST SSRS/SSMS INSTALL CHECK'
    Set-Step PostSSRSSMSReboot
    Write-Log 'Post-SSRS reboot barrier: system is clean, proceeding to SSRSConfigure.' WARN
}

# ── Invoke-SSRSConfigure ──────────────────────────────────────────────────────
# FIX: HRESULT checked on every WMI configuration call (was [void] — silent failures)
# FIX: InitializeReportServer called to complete SSRS initialisation sequence
function Invoke-SSRSConfigure {
    Write-Header 'SSRS CONFIGURE'
    Set-Step SSRSConfigure

    $rs = $null
    for ($i = 1; $i -le 12; $i++) { try { $rs = Get-SSRSWmiObject; break } catch { Start-Sleep 10 } }
    if (-not $rs) { throw 'SSRS WMI provider not ready after 120s' }

    $db = Get-Cfg SSRSDBName ReportServer
    Import-Module SqlServer -ErrorAction SilentlyContinue

    if (-not (Test-DbOnline $db)) {
        $scr = $rs.GenerateDatabaseCreationScript($db, 1033, $false)
        if ($scr.HRESULT -ne 0) { throw "GenerateDatabaseCreationScript failed HRESULT=0x$($scr.HRESULT.ToString('X8'))" }
        Invoke-Sqlcmd -ServerInstance $env:COMPUTERNAME -Database master -Query $scr.Script -QueryTimeout 0
    }

    $svc = Get-CimInstance Win32_Service |
               Where-Object { $_.Name -eq 'SQLServerReportingServices' -or $_.Name -like '*ReportServer*' } |
               Select-Object -First 1
    if (-not $svc) { throw 'SSRS service not found during SSRSConfigure' }

    $rights = $rs.GenerateDatabaseRightsScript($svc.StartName, $db, $false, $true)
    if ($rights.HRESULT -eq 0) { Invoke-Sqlcmd -ServerInstance $env:COMPUTERNAME -Database master -Query $rights.Script -QueryTimeout 0 }

    # FIX: validate HRESULT on each configuration call; [void] was swallowing all failures
    $res = $rs.SetDatabaseConnection($env:COMPUTERNAME, $db, 2, '', '')
    if ($res.HRESULT -ne 0) { throw "SetDatabaseConnection failed HRESULT=0x$($res.HRESULT.ToString('X8'))" }

    $res = $rs.SetVirtualDirectory('ReportServerWebService', 'ReportServer', 1033)
    if ($res.HRESULT -ne 0) { throw "SetVirtualDirectory(ReportServerWebService) failed HRESULT=0x$($res.HRESULT.ToString('X8'))" }

    $res = $rs.SetVirtualDirectory('ReportServerWebApp', 'Reports', 1033)
    if ($res.HRESULT -ne 0) { throw "SetVirtualDirectory(ReportServerWebApp) failed HRESULT=0x$($res.HRESULT.ToString('X8'))" }

    $res = $rs.ReserveURL('ReportServerWebService', 'http://+:80', 1033)
    if ($res.HRESULT -ne 0) { throw "ReserveURL(ReportServerWebService) failed HRESULT=0x$($res.HRESULT.ToString('X8'))" }

    $res = $rs.ReserveURL('ReportServerWebApp', 'http://+:80', 1033)
    if ($res.HRESULT -ne 0) { throw "ReserveURL(ReportServerWebApp) failed HRESULT=0x$($res.HRESULT.ToString('X8'))" }

    # FIX: InitializeReportServer is required to complete SSRS setup; omitting it leaves
    #      the service in an uninitialised state that causes subsequent URL checks to fail
    $res = $rs.InitializeReportServer($rs.InstallationID)
    if ($res.HRESULT -ne 0) { throw "InitializeReportServer failed HRESULT=0x$($res.HRESULT.ToString('X8'))" }

    $s = Get-SSRSService
    if ($s) { Restart-Service $s.Name -Force; Start-Sleep 60 }

    if (-not (Test-ReportServerUrl)) { throw 'SSRS URL test failed during SSRSConfigure. ReportServer URL is not accessible.' }
    Write-PhaseState SSRSConfigure RebootPending 'Reboot required after SSRS install and SSRSConfigure' 0 $true
    Restart-Computer -Force; exit 0
}

function Ensure-SSRSNetworkService {
    $svc = Get-SSRSService
    if (-not $svc) { throw 'SSRS service not found' }
    $w = Get-CimInstance Win32_Service -Filter "Name='$($svc.Name)'"
    if ($w.StartName -notin @('NT AUTHORITY\NetworkService','NT AUTHORITY\NETWORK SERVICE')) {
        $r = Invoke-CimMethod -InputObject $w -MethodName Change -Arguments @{ StartName = 'NT AUTHORITY\NetworkService'; StartPassword = '' }
        if ($r.ReturnValue -ne 0) { throw "Failed changing SSRS service account. ReturnValue=$($r.ReturnValue)" }
        Restart-Service $svc.Name -Force
    }
}

function Invoke-DPMPrereqRemediate {
    Write-Header 'DPM PREREQ REMEDIATE'
    Set-Step DPMPrereqRemediate
    Ensure-SSRSNetworkService
    $snacChanged = Install-SNAC
    $skip    = Get-CfgBool SkipHyperVCheck $false
    $changed = $false
    if (-not $skip) {
        $hv   = Get-FeatureState 'Microsoft-Hyper-V'
        $hvps = Get-FeatureState 'Microsoft-Hyper-V-Management-PowerShell'
        if ($hv -ne 'Enabled' -or $hvps -ne 'Enabled') {
            & dism.exe /Online /Enable-feature /All /FeatureName:Microsoft-Hyper-V /FeatureName:Microsoft-Hyper-V-Management-PowerShell /quiet /norestart | Out-Null
            $changed = $true
        }
    }
    if ($changed -or $snacChanged -or (Test-RebootPending)) {
        Write-PhaseState DPMPrereqRemediate RebootPending 'DPM prerequisite remediation requires reboot' 0 $true
        Restart-Computer -Force; exit 0
    }
    if (-not (Test-ReportServerUrl)) { throw 'ReportServer URL is not accessible' }
}

function Invoke-SSRSTrust {
    Write-Header 'SSRS TRUST PREFX'
    Set-Step SSRSTrustPreFix
    Write-CsvRow "$StatusDir\SSRS_Trust_Status.csv" @{
        ServerName = $env:COMPUTERNAME; RunId = $RunId
        Status = 'Success'; Action = 'NoOp'; Timestamp = (Get-Date).ToString('s')
    }
}

function Split-DomainAccount {
    param([string]$Account)
    if ($Account -match '^(?<Domain>[^\\]+)\\(?<User>.+)$') {
        return [pscustomobject]@{ Domain = $Matches.Domain; User = $Matches.User }
    }
    return [pscustomobject]@{ Domain = ''; User = $Account }
}

function Get-DPMEvidence {
    $svc  = Get-Service MSDPM -ErrorAction SilentlyContinue
    $dbOk = $false
    try {
        Import-Module SqlServer -ErrorAction SilentlyContinue
        $db = (Get-Cfg DPMDBNamePrefix DPMDB_) + $env:COMPUTERNAME
        $r  = Invoke-Sqlcmd -ServerInstance $env:COMPUTERNAME -Database master `
                             -Query "SELECT state_desc FROM sys.databases WHERE name=N'$db'" -ErrorAction Stop
        $dbOk = $r.state_desc -eq 'ONLINE'
    } catch {}
    return [pscustomobject]@{ ServiceExists = [bool]$svc; DbOnline = $dbOk }
}

function Test-DPMInstalled { $e = Get-DPMEvidence; return ($e.ServiceExists -and $e.DbOnline) }

# ── New-DPMSetupIni ───────────────────────────────────────────────────────────
# FIX: IntegratedInstallSource derived from DPMSetupRelativePath (was hardcoded
#      to C:\DPM_Data\New Setups\SCDPM_2022 which may not match every deployment)
function New-DPMSetupIni {
    $acct = Get-Cfg DPMSetupRunAsAccount
    $pwd  = Get-Cfg DPMSetupRunAsPassword
    if ([string]::IsNullOrWhiteSpace($acct)) { throw 'DPMSetupRunAsAccount is required for DPM setup.' }
    $s = Split-DomainAccount $acct

    $dpmSetupRel      = Get-Cfg DPMSetupRelativePath
    $integratedSource = Join-Path $Root (Split-Path $dpmSetupRel -Parent)

    $ini     = Join-Path $TempDir 'DPMSetup.ini'
    $content = @"
[OPTIONS]
UserName = $(Get-Cfg DPMUserName)
CompanyName = $(Get-Cfg DPMCompanyName)
ProductKey = $(Get-Cfg DPMProductKey)
IntegratedInstallSource = $integratedSource
SQLMachineName = $env:COMPUTERNAME
SQLInstanceName = $(Get-Cfg SQLInstanceName MSSQLSERVER)
SQLMachineUserName = $($s.User)
SQLMachinePassword = $pwd
SQLMachineDomainName = $($s.Domain)
SqlAccountPassword = $pwd
ReportingMachineName = $env:COMPUTERNAME
ReportingInstanceName = $(Get-Cfg ReportingInstanceName SSRS)
"@
    Set-Content $ini $content -Encoding ASCII
    (Mask-Secret $content) | Set-Content "$LogDir\DPMSetup_MaskedPreview_$Timestamp.log"
    return $ini
}

# ── Invoke-DPMSetup ───────────────────────────────────────────────────────────
# FIX: setup.exe invoked directly instead of via cmd.exe /c start /wait
#      The wrapper did not reliably propagate the exit code and misquoted paths with spaces
function Invoke-DPMSetup {
    Write-Header 'DPM SETUP'
    Set-Step $Phase
    if (Test-DPMInstalled) { Write-Log 'DPM already installed; skipping DPM setup' WARN; return }
    if (-not (Test-ReportServerUrl)) { throw 'ReportServer URL is not accessible' }

    $setup = Join-Path $Root (Get-Cfg DPMSetupRelativePath)
    if (-not (Test-Path $setup)) { throw "DPM setup.exe missing: $setup" }

    $ini    = New-DPMSetupIni
    $dpmLog = "$LogDir\DPMSetup_${env:COMPUTERNAME}_$Timestamp.log"

    # Direct invocation: reliable exit code, no shell quoting layer, no lost stdout
    $r = Invoke-ProcessChecked $setup "/i /f `"$ini`" /l `"$dpmLog`"" (Split-Path $setup -Parent) "$LogDir\DPM_Process_$Timestamp.log"
    if (-not (Test-AcceptedExitCode $r.ExitCode)) { throw "DPM setup failed with exit code $($r.ExitCode)" }

    $e = Get-DPMEvidence
    if (-not ($e.ServiceExists -and $e.DbOnline)) {
        throw "DPM setup returned success but validation failed. ServiceExists=$($e.ServiceExists) DbOnline=$($e.DbOnline)"
    }
}

function Invoke-DPMPostValidate {
    Write-Header 'DPM POST VALIDATE'
    Set-Step DPMPostValidate
    if (-not (Test-DPMInstalled)) { throw 'DPM post validation failed' }
}

# ══════════════════════════════════════════════════════════════════════════════
# Entry point
# ══════════════════════════════════════════════════════════════════════════════
try {
    Write-PhaseState Starting Running
    switch ($Phase) {
        'Precheck'            { Invoke-Precheck }
        'RefreshODBCOLEDB'    { Invoke-RefreshODBCOLEDB }
        'SQLInstall'          { Invoke-SQLInstall }
        'PostSQLRebootValidate'{ Invoke-PostSQL }
        'SSRSSMSInstall'      { Invoke-SSRSSMSInstall }
        'SSRSSSMSInstall'     { Invoke-SSRSSMSInstall }   # alias
        'PostSSRSSMSReboot'   { Invoke-PostSSRSReboot }
        'PostSSRSSSMSReboot'  { Invoke-PostSSRSReboot }   # alias
        'SSRSConfigure'       { Invoke-SSRSConfigure }
        'DPMPrereqRemediate'  { Invoke-DPMPrereqRemediate }
        'SSRSTrustPreFix'     { Invoke-SSRSTrust }
        'DPMInstall'          { Invoke-DPMSetup }
        'DPMUpgrade'          { Invoke-DPMSetup }          # alias
        'DPMPostValidate'     { Invoke-DPMPostValidate }
        default               { throw "Unknown phase: $Phase" }
    }
    Write-PhaseState Completed Completed
    Write-Log "Phase $Phase completed" OK
}
catch {
    Write-PhaseState Failed Failed $_.Exception.Message
    Write-CsvRow "$StatusDir\Error_Status.csv" @{
        ServerName   = $env:COMPUTERNAME; RunId = $RunId
        Phase        = $Phase; ErrorMessage = $_.Exception.Message
        Timestamp    = (Get-Date).ToString('s')
    }
    Write-Log $_.Exception.Message ERROR
    throw
}
finally { Stop-Transcript | Out-Null }
