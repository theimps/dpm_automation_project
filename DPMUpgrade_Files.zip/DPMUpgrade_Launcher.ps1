<#
.SYNOPSIS
    Operation Ironclad - DPM FreshInstall Launcher v20.8 FULL REPLACEMENT
.DESCRIPTION
    Full replacement launcher/orchestrator for config-driven DPM fresh install automation.
    Preserves working pipeline behavior and changes only previously failing/untried areas:
      - SSRS/SSMS stage uses known-good SSRS/SSMS syntax from successful upgrade scripts.
      - Automatic reboot count is capped at 3 per server run.
      - SSRS/SSMS install does not reboot; SSRSConfigure triggers the SSRS-area reboot.
.VERSION
    FULL_REPLACEMENT_LAUNCHER_v20_8_20260706_FIXED
.FIXES
    - Added elevation guard at entry
    - Self-unblocks script file on start (removes Zone.Identifier ADS)
    - Worker copy source corrected: DPMUpgrade_Worker.ps1 (was DPMUpgrade.Worker.ps1)
    - Unblock-File applied to worker after UNC copy
    - CMD bootstrap: 2>&1 corrected (was invalid 2>>&1)
    - CMD bootstrap: -ExecutionPolicy Bypass (was RemoteSigned; SYSTEM has no trust context)
    - CMD bootstrap: references DPMUpgrade_Worker.ps1 (consistent with deployed filename)
    - schtasks /ST now uses Get-Date +2min (was hardcoded 23:59, fails post-midnight)
    - $servers initialised before try block (StrictMode crash if try threw before assignment)
    - Wait-ExpectedState task-start timeout raised to 300s (was 180s)
#>
[CmdletBinding()]
param(
    [ValidateSet('All','CopyOnly','DPMOnly','SSRSTrustPreFixOnly')]
    [string]$Mode = 'All',

    [string]$ServerListPath = 'C:\DPM_Data\Config\ServerList.csv',
    [string]$ConfigPath     = 'C:\DPM_Data\Config\DPMUpgrade.Config.csv',
    [string]$ResumeFromPhase = ''
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# ── Elevation guard ────────────────────────────────────────────────────────────
if (-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]'Administrator')) {
    throw 'Launcher must be run as Administrator.'
}

# ── Self-unblock: strips Zone.Identifier ADS if script was downloaded/copied ──
if ($PSCommandPath) { Unblock-File -Path $PSCommandPath -ErrorAction SilentlyContinue }

$RunId         = 'RUN_{0}_{1}' -f (Get-Date -Format yyyyMMdd_HHmmss), ([Guid]::NewGuid().ToString('N').Substring(0,8))
$ConfigDir     = Split-Path $ConfigPath -Parent
$LauncherLogDir = Join-Path $ConfigDir '..\Logs'
$ReportDir     = Join-Path $ConfigDir '..\Reports'
New-Item -ItemType Directory -Force -Path $LauncherLogDir, $ReportDir | Out-Null
Start-Transcript -Path (Join-Path $LauncherLogDir "Launcher_$RunId.log") -Force | Out-Null

function Write-Log {
    param([string]$Message,[string]$Level='INFO',[string]$Tag='LAUNCHER')
    $color  = switch ($Level) { 'ERROR' {'Red'} 'WARN' {'Yellow'} 'OK' {'Green'} 'HEAD' {'Cyan'} 'PHASE' {'Magenta'} default {'White'} }
    $prefix = switch ($Level) { 'ERROR' {'[ERR]'} 'WARN' {'[WARN]'} 'OK' {'[OK]'} 'HEAD' {'>>'} 'PHASE' {'->'} default {'  '} }
    Write-Host ("[{0}] [{1}] {2} {3}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Tag.PadRight(8), $prefix, $Message) -ForegroundColor $color
}

function Import-ConfigMap {
    param([string]$Path)
    if (-not (Test-Path $Path)) { throw "Config not found: $Path" }
    $map = @{}
    foreach ($row in Import-Csv -Path $Path) {
        if ($row.ConfigName) { $map[$row.ConfigName.Trim()] = [string]$row.ConfigValue }
    }
    return $map
}

function Get-Cfg {
    param([hashtable]$Config,[string]$Name,[string]$Default='')
    if ($Config.ContainsKey($Name)) {
        $value = [string]$Config[$Name]
        if (-not [string]::IsNullOrWhiteSpace($value) -and $value -notlike '<REPLACE*') { return $value }
    }
    return $Default
}

function ConvertTo-B64Unicode { param([string]$Text) [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($Text)) }
function Test-AdminShare      { param([string]$Server) Test-Path "\\$Server\C$" }

function Invoke-NativeQuiet {
    param([string]$FilePath,[string]$ArgumentList)
    $id      = [Guid]::NewGuid().ToString('N')
    $outFile = Join-Path $env:TEMP "ironclad_out_$id.txt"
    $errFile = Join-Path $env:TEMP "ironclad_err_$id.txt"
    try {
        $p = Start-Process -FilePath $FilePath -ArgumentList $ArgumentList -Wait -NoNewWindow -PassThru `
                           -RedirectStandardOutput $outFile -RedirectStandardError $errFile -ErrorAction SilentlyContinue
        [pscustomobject]@{
            ExitCode = if ($p) { $p.ExitCode } else { -9999 }
            StdOut   = if (Test-Path $outFile) { Get-Content $outFile -Raw -ErrorAction SilentlyContinue } else { '' }
            StdErr   = if (Test-Path $errFile) { Get-Content $errFile -Raw -ErrorAction SilentlyContinue } else { '' }
        }
    }
    finally { Remove-Item $outFile,$errFile -Force -ErrorAction SilentlyContinue }
}

function Wait-AdminShareOnline {
    param([string]$Server,[int]$TimeoutMinutes=75)
    $deadline = (Get-Date).AddMinutes($TimeoutMinutes)
    while ((Get-Date) -lt $deadline) {
        if (Test-AdminShare $Server) { return }
        Start-Sleep -Seconds 20
    }
    throw "Timeout waiting for admin share on $Server"
}

function Wait-RebootCycle {
    param([string]$Server)
    Write-Log "Waiting reboot cycle for $Server" WARN REBOOT
    $offlineDeadline = (Get-Date).AddMinutes(10)
    while ((Get-Date) -lt $offlineDeadline) {
        if (-not (Test-AdminShare $Server)) { break }
        Start-Sleep -Seconds 10
    }
    Wait-AdminShareOnline -Server $Server -TimeoutMinutes 75
    Start-Sleep -Seconds 45
    Write-Log "$Server is online after reboot" OK REBOOT
}

function Remove-TempScheduledTaskSafe {
    param([string]$ServerName,[string]$TaskName)
    try {
        $r = Invoke-NativeQuiet schtasks.exe "/Delete /S $ServerName /TN $TaskName /F"
        $m = (($r.StdOut + ' ' + $r.StdErr).Trim())
        if ($r.ExitCode -eq 0) { Write-Log "Deleted temp task [$TaskName] on [$ServerName]" OK TASKRUN; return }
        if ($m -match 'cannot find|does not exist|not found') { Write-Log "Temp task [$TaskName] did not exist on [$ServerName]; continuing." WARN TASKRUN; return }
        Write-Log "Ignoring temp task delete failure [$TaskName] on [$ServerName]. ExitCode=$($r.ExitCode) Message=$m" WARN TASKRUN
    }
    catch { Write-Log "Ignoring temp task delete exception [$TaskName] on [$ServerName]: $($_.Exception.Message)" WARN TASKRUN }
}

function Import-ServerList {
    param([string]$Path,[hashtable]$Config)
    if (-not (Test-Path $Path)) { throw "Server list not found: $Path" }
    $servers = @()
    foreach ($row in Import-Csv $Path) {
        if ([string]::IsNullOrWhiteSpace($row.ServerName)) { continue }
        $enabled = if ($row.PSObject.Properties['Enabled']) { [string]$row.Enabled } else { 'True' }
        if ($enabled -notmatch '^(1|true|yes|y)$') { continue }
        $servers += [pscustomobject]@{
            ServerName = $row.ServerName.Trim().ToUpperInvariant()
            Location   = if ($row.PSObject.Properties['Location']) { [string]$row.Location } else { '' }
            State      = 'PendingCopy'
            CopyJob    = $null
            Upgrade    = $null
            Error      = ''
        }
    }
    $runMode = Get-Cfg $Config RunMode 'All'
    $pilot   = (Get-Cfg $Config PilotServer '').Trim()
    if ($runMode -eq 'Pilot' -and $pilot) { $servers = @($servers | Where-Object { $_.ServerName -ieq $pilot }) }
    if ($servers.Count -eq 0) { throw 'No enabled servers found matching RunMode.' }
    return $servers
}

function Get-PhaseList {
    param([string]$InstallMode,[string]$OperationMode)
    if ($OperationMode -eq 'CopyOnly')            { return @() }
    if ($OperationMode -eq 'SSRSTrustPreFixOnly')  { return @('SSRSTrustPreFix') }
    if ($OperationMode -eq 'DPMOnly')              { return @('DPMPrereqRemediate','SSRSTrustPreFix','DPMInstall','DPMPostValidate') }
    return @('Precheck','RefreshODBCOLEDB','SQLInstall','PostSQLRebootValidate',
             'SSRSSMSInstall','PostSSRSSMSReboot','SSRSConfigure',
             'DPMPrereqRemediate','SSRSTrustPreFix','DPMInstall','DPMPostValidate')
}

function Start-CopyJobForServer {
    param($Server,[hashtable]$Config,[string]$ConfigFile)
    $source = Get-Cfg $Config SourceSetupRoot
    if ([string]::IsNullOrWhiteSpace($source)) { throw 'SourceSetupRoot missing in config.' }
    $target = "\\$($Server.ServerName)\C$\DPM_Data"
    foreach ($dir in 'Scripts','Config','Logs','Status','Temp','Reports','Backup') {
        New-Item -ItemType Directory -Force -Path (Join-Path $target $dir) | Out-Null
    }

    # FIX: source filename is DPMUpgrade_Worker.ps1 (underscore), not DPMUpgrade.Worker.ps1 (dot)
    $localWorker = Join-Path $PSScriptRoot 'DPMUpgrade_Worker.ps1'
    if (-not (Test-Path $localWorker)) { throw "Worker script not found at expected path: $localWorker" }
    $remoteWorker = "$target\Scripts\DPMUpgrade_Worker.ps1"
    Copy-Item $localWorker $remoteWorker -Force

    # FIX: unblock after UNC copy — strips Zone.Identifier ADS that blocks SYSTEM execution
    Unblock-File -Path $remoteWorker -ErrorAction SilentlyContinue

    Copy-Item $ConfigFile "$target\Scripts\DPMUpgrade.Config.csv" -Force
    Copy-Item $ConfigFile "$target\Config\DPMUpgrade.Config.csv" -Force

    $destination  = Join-Path $target 'New Setups'
    $robocopyLog  = Join-Path $LauncherLogDir "Robocopy_$($Server.ServerName)_$(Get-Date -Format yyyyMMdd_HHmmss).log"
    Write-Log "Copy START to $($Server.ServerName)" HEAD COPY
    $Server.CopyJob = Start-Job -Name "Copy_$($Server.ServerName)" -ScriptBlock {
        param($Source,$Dest,$Log)
        New-Item -ItemType Directory -Force -Path $Dest | Out-Null
        & robocopy.exe $Source $Dest /MIR /R:2 /W:5 /NFL /NDL /NP *>> $Log
        $rc = $LASTEXITCODE
        if ($rc -gt 7) { throw "Robocopy failed ExitCode=$rc Log=$Log" }
        return $rc
    } -ArgumentList $source,$destination,$robocopyLog
    $Server.State = 'CopyInProgress'
}

function Complete-CopyIfDone {
    param($Server)
    if (-not $Server.CopyJob -or $Server.CopyJob.State -eq 'Running') { return }
    try {
        Receive-Job $Server.CopyJob -ErrorAction Stop | Out-Null
        Remove-Job $Server.CopyJob -Force
        $Server.CopyJob = $null
        $Server.State   = 'PendingUpgrade'
        Write-Log "Copy DONE: $($Server.ServerName)" OK COPY
    }
    catch {
        Remove-Job $Server.CopyJob -Force -ErrorAction SilentlyContinue
        $Server.State = 'Failed'
        $Server.Error = "Copy failed: $($_.Exception.Message)"
        Write-Log $Server.Error ERROR COPY
    }
}

function Get-RemotePhaseState {
    param([string]$Server)
    $path = "\\$Server\C$\DPM_Data\Status\PhaseState.json"
    if (-not (Test-Path $path)) { return $null }
    for ($i=1; $i -le 3; $i++) {
        try   { return Get-Content $path -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop }
        catch { Start-Sleep -Milliseconds 500 }
    }
    return $null
}

function Wait-ExpectedState {
    # FIX: raised default from 180s to 300s — slow task scheduler start on busy servers
    param([string]$Server,[string]$Phase,[string]$Run,[int]$Seconds=300)
    $deadline = (Get-Date).AddSeconds($Seconds)
    while ((Get-Date) -lt $deadline) {
        $state = Get-RemotePhaseState $Server
        if ($state -and $state.CurrentPhase -eq $Phase -and
           ((-not $state.PSObject.Properties['RunId']) -or $state.RunId -eq $Run)) { return $true }
        Start-Sleep -Seconds 5
    }
    return $false
}

function Start-Phase {
    param($Server,[string]$Phase,[hashtable]$Config)
    $taskName     = "DPM_Op_${Phase}_Temp"
    $remoteRoot   = "\\$($Server.ServerName)\C$\DPM_Data"
    $remoteTemp   = Join-Path $remoteRoot 'Temp'
    $remoteStatus = Join-Path $remoteRoot 'Status'
    New-Item -ItemType Directory -Force -Path $remoteTemp,$remoteStatus | Out-Null
    Remove-Item (Join-Path $remoteStatus 'PhaseState.json') -Force -ErrorAction SilentlyContinue

    $cmdName       = "RunPhase_${Phase}_${RunId}.cmd"
    $remoteCmd     = "C:\DPM_Data\Temp\$cmdName"
    $adminCmd      = Join-Path $remoteTemp $cmdName
    $bootstrapLocal = "C:\DPM_Data\Logs\TaskBootstrap_${Phase}_${RunId}.log"
    $bootstrapUnc  = "\\$($Server.ServerName)\C$\DPM_Data\Logs\TaskBootstrap_${Phase}_${RunId}.log"
    $locationB64   = ConvertTo-B64Unicode $Server.Location

    # FIX 1: -ExecutionPolicy Bypass — SYSTEM context has no signature trust; RemoteSigned blocks unsigned scripts
    # FIX 2: 2>&1 is correct CMD stderr-to-stdout redirect; 2>>&1 is invalid CMD syntax
    # FIX 3: filename aligned to DPMUpgrade_Worker.ps1 (underscore) matching deployed copy
    $cmd = @"
@echo off
setlocal enabledelayedexpansion
echo Phase $Phase RunId $RunId > "$bootstrapLocal"
powershell.exe -NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "C:\DPM_Data\Scripts\DPMUpgrade_Worker.ps1" -Phase "$Phase" -ConfigPath "C:\DPM_Data\Scripts\DPMUpgrade.Config.csv" -ServerName "$($Server.ServerName)" -LocationB64 "$locationB64" -RunId "$RunId" >> "$bootstrapLocal" 2>&1
set RC=%ERRORLEVEL%
echo ExitCode=!RC! >> "$bootstrapLocal"
exit /b !RC!
"@
    Set-Content -Path $adminCmd -Value $cmd -Encoding ASCII -Force

    Remove-TempScheduledTaskSafe -ServerName $Server.ServerName -TaskName $taskName

    $ru = Get-Cfg $Config TaskRunAsUser ''
    $rp = Get-Cfg $Config TaskRunAsPassword ''
    if ($Phase -in @('DPMInstall','DPMUpgrade')) {
        $dpmRunAs = Get-Cfg $Config DPMSetupRunAsAccount ''
        if ($dpmRunAs) {
            $ru = $dpmRunAs
            $rp = Get-Cfg $Config DPMSetupRunAsPassword ''
            if ([string]::IsNullOrWhiteSpace($rp)) { throw 'DPMSetupRunAsPassword is required when DPMSetupRunAsAccount is configured.' }
        }
    }

    # FIX: /ST set to now+2min so schtasks never rejects a "past" time near midnight
    $futureTime = (Get-Date).AddMinutes(2).ToString('HH:mm')
    $createArgs = "/Create /S $($Server.ServerName) /TN $taskName /SC ONCE /ST $futureTime /TR `"$remoteCmd`" /RL HIGHEST /F"
    if ($ru) { $createArgs += " /RU `"$ru`" /RP `"$rp`"" }

    $create = Invoke-NativeQuiet schtasks.exe $createArgs
    if ($create.ExitCode -ne 0) {
        throw "schtasks create failed ExitCode=$($create.ExitCode) Phase=$Phase Server=$($Server.ServerName) Message=$($create.StdOut) $($create.StdErr)"
    }

    $Server.Upgrade.CurrentTask   = $taskName
    $Server.Upgrade.CurrentPhase  = $Phase
    $Server.Upgrade.PhaseStartTime = Get-Date
    Write-Log "Phase [$($Server.Upgrade.Index + 1)/$($Server.Upgrade.Phases.Count)] [$Phase] to $($Server.ServerName)" PHASE UPGRADE
    Write-Log "Bootstrap log: $bootstrapUnc" INFO TASKRUN

    $run = Invoke-NativeQuiet schtasks.exe "/Run /S $($Server.ServerName) /TN $taskName"
    if ($run.ExitCode -ne 0) {
        throw "schtasks run failed ExitCode=$($run.ExitCode) Phase=$Phase Server=$($Server.ServerName) Message=$($run.StdOut) $($run.StdErr)"
    }
    if (-not (Wait-ExpectedState $Server.ServerName $Phase $RunId 300)) {
        throw "Task did not start/write PhaseState.json after 300s: $Phase on $($Server.ServerName)"
    }
    Write-Log "Worker state detected for $($Server.ServerName) phase [$Phase]" OK TASKRUN
}

function Start-Pipeline {
    param($Server,[string[]]$Phases,[hashtable]$Config)
    $Server.Upgrade = [pscustomobject]@{
        Phases         = $Phases
        Index          = 0
        CurrentPhase   = ''
        CurrentTask    = ''
        PhaseStartTime = $null
        RebootCount    = 0
        MaxReboots     = 3
    }
    $Server.State = 'UpgradeInProgress'
    Start-Phase $Server $Phases[0] $Config
}

function Poll-Pipeline {
    param($Server,[hashtable]$Config)
    $state = Get-RemotePhaseState $Server.ServerName
    if (-not $state -or $state.CurrentPhase -ne $Server.Upgrade.CurrentPhase) { return }

    $phaseTimeoutMin = [int](Get-Cfg $Config PhaseTimeoutMinutes '90')
    if ($Server.Upgrade.PhaseStartTime -and ((Get-Date) - $Server.Upgrade.PhaseStartTime).TotalMinutes -gt $phaseTimeoutMin) {
        $Server.State = 'Failed'
        $Server.Error = "Phase [$($Server.Upgrade.CurrentPhase)] timed out after ${phaseTimeoutMin}min"
        Write-Log $Server.Error ERROR TIMEOUT
        Remove-TempScheduledTaskSafe $Server.ServerName $Server.Upgrade.CurrentTask
        return
    }

    Write-Log "Monitor: $($Server.ServerName) :: $($state.CurrentPhase) :: $($state.Status)" PHASE POLL
    switch ($state.Status) {
        'Failed' {
            $Server.State = 'Failed'
            $Server.Error = $state.Message
            Write-Log "FAILED: $($Server.ServerName) - $($Server.Error)" ERROR UPGRADE
            Remove-TempScheduledTaskSafe $Server.ServerName $Server.Upgrade.CurrentTask
        }
        'RebootPending' {
            $Server.Upgrade.RebootCount++
            Write-Log "Reboot request accepted. Count=$($Server.Upgrade.RebootCount)/$($Server.Upgrade.MaxReboots). Phase=$($Server.Upgrade.CurrentPhase)" WARN REBOOT
            if ($Server.Upgrade.RebootCount -gt $Server.Upgrade.MaxReboots) {
                $Server.State = 'Failed'
                $Server.Error = 'Automatic reboot limit exceeded'
                Write-Log $Server.Error ERROR REBOOT
                Remove-TempScheduledTaskSafe $Server.ServerName $Server.Upgrade.CurrentTask
                return
            }
            Wait-RebootCycle $Server.ServerName
            if ($Server.Upgrade.CurrentPhase -eq 'DPMPrereqRemediate') {
                Start-Phase $Server $Server.Upgrade.CurrentPhase $Config
            } else {
                $Server.Upgrade.Index++
                if ($Server.Upgrade.Index -ge $Server.Upgrade.Phases.Count) {
                    $Server.State = 'Completed'
                } else {
                    Start-Phase $Server $Server.Upgrade.Phases[$Server.Upgrade.Index] $Config
                }
            }
        }
        'Completed' {
            Remove-TempScheduledTaskSafe $Server.ServerName $Server.Upgrade.CurrentTask
            $Server.Upgrade.Index++
            if ($Server.Upgrade.Index -ge $Server.Upgrade.Phases.Count) {
                $Server.State = 'Completed'
                Write-Log "COMPLETE: $($Server.ServerName)" OK UPGRADE
            } else {
                Start-Phase $Server $Server.Upgrade.Phases[$Server.Upgrade.Index] $Config
            }
        }
    }
}

# FIX: initialise $servers before try so the post-finally $failed check doesn't crash
#      under Set-StrictMode -Version Latest if the try block throws before assignment
$servers = @()
try {
    $Config      = Import-ConfigMap $ConfigPath
    $installMode = Get-Cfg $Config InstallMode FreshInstall
    $servers     = @(Import-ServerList $ServerListPath $Config)
    $phases      = @(Get-PhaseList $installMode $Mode)

    if ($ResumeFromPhase) {
        $idx = [array]::IndexOf([string[]]$phases, $ResumeFromPhase)
        if ($idx -lt 0) { throw "ResumeFromPhase not found: $ResumeFromPhase. PhaseList=$($phases -join ' -> ')" }
        $phases = @($phases[$idx..($phases.Count - 1)])
        Write-Log "Resume sequence: $($phases -join ' -> ')" WARN
    }
    Write-Log "RunId=$RunId InstallMode=$installMode Servers=$($servers.Count) Phases=$($phases.Count)" HEAD

    while ($true) {
        foreach ($s in @($servers | Where-Object State -eq CopyInProgress)) { Complete-CopyIfDone $s }
        if (@($servers | Where-Object State -eq CopyInProgress).Count -lt 1) {
            $nextCopy = $servers | Where-Object State -eq PendingCopy | Select-Object -First 1
            if ($nextCopy) { Start-CopyJobForServer $nextCopy $Config $ConfigPath }
        }
        if ($Mode -ne 'CopyOnly') {
            foreach ($s in @($servers | Where-Object State -eq UpgradeInProgress)) { Poll-Pipeline $s $Config }
            if (@($servers | Where-Object State -eq UpgradeInProgress).Count -lt 1) {
                $nextUpgrade = $servers | Where-Object State -eq PendingUpgrade | Select-Object -First 1
                if ($nextUpgrade) { Start-Pipeline $nextUpgrade $phases $Config }
            }
        } else {
            foreach ($s in @($servers | Where-Object State -eq PendingUpgrade)) { $s.State = 'Completed' }
        }
        if (@($servers | Where-Object { $_.State -notin 'Completed','Failed' }).Count -eq 0) { break }
        Start-Sleep -Seconds 20
    }
    $servers | Select-Object ServerName,Location,State,Error |
        Export-Csv (Join-Path $ReportDir "Final_Summary_$(Get-Date -Format yyyyMMdd_HHmmss).csv") -NoTypeInformation
}
finally { Stop-Transcript | Out-Null }

$failed = @($servers | Where-Object State -eq Failed)
if ($failed.Count) { throw "Failed: $($failed.ServerName -join ', ')" }
Write-Log 'All servers complete. Operation Ironclad DONE.' OK
