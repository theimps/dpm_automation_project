﻿#************************************************
#  DPM_Inventory_Launcher.ps1
#  Run this script FROM YOUR LOCAL MACHINE or directly on a DPM server.
#
#  For each server in DPMServers.csv it will:
#  1. Copy the inventory script and server list to the target server
#  2. Create a temporary scheduled task on that server running as SYSTEM
#     — execution time limit set to unlimited so it never gets killed
#  3. Wait for the task to complete
#  4. Delete the scheduled task immediately — no persistent tasks left
#  5. Copy the resulting CSV and task log back to the local machine
#  6. Merge all per-server CSVs into one combined DPM_Inventory.csv
#
#  REQUIREMENTS:
#  - Run as Administrator
#  - WinRM enabled on all target DPM servers
#  - Admin rights on all target DPM servers
#  - DPMServers.csv must list one server per row under "ServerName" column
#
#  EDIT the CONFIGURATION section below before running.
#************************************************

#--------------------------
# CONFIGURATION
#--------------------------
$LocalInventoryScript = "C:\DPM_Data\DPM_Inventory_Export.ps1"  # inventory script on THIS machine
$LocalServerListCSV   = "C:\DPM_Data\DPMServers.csv" # server list CSV on THIS machine
$LocalOutputFolder    = "C:\DPM_Data"                 # where final merged CSV is saved locally
$RemoteWorkFolder     = "C:\DPM_Data"                 # working folder on each remote server
$TempTaskName         = "DPM_Inventory_Temp"           # scheduled task name — deleted after each run
$TaskTimeoutMinutes   = 120                            # max minutes to wait per server before giving up
#--------------------------

# Versioned merged CSV — never overwrites existing files.
# First run  : DPM_Inventory.csv
# Second run : DPM_Inventory_v1.csv
# Third run  : DPM_Inventory_v2.csv  ... and so on.
$BaseMergedFile = "$LocalOutputFolder\DPM_Inventory.csv"
if (-not (Test-Path $BaseMergedFile)) {
    $MergedOutputFile = $BaseMergedFile
} else {
    $v = 1
    while (Test-Path "$LocalOutputFolder\DPM_Inventory_v$v.csv") { $v++ }
    $MergedOutputFile = "$LocalOutputFolder\DPM_Inventory_v$v.csv"
}
$StatusLogFile = "$LocalOutputFolder\DPM_Inventory_Status.log"
$StatusCSVFile = "$LocalOutputFolder\DPM_Inventory_Status.csv"
$LaunchStart   = Get-Date

#--------------------------
# Progress helper
#--------------------------
function Log {
    param([string]$Message, [string]$Type = 'INFO')
    $ts    = Get-Date -Format "HH:mm:ss"
    $color = switch ($Type) {
        'ERROR' { 'Red'    }
        'WARN'  { 'Yellow' }
        'OK'    { 'Green'  }
        'HEAD'  { 'Cyan'   }
        default { 'White'  }
    }
    Write-Host "[$ts] $Message" -ForegroundColor $color
}

# Writes a status entry to the status log file
# Status: SUCCESS | FAILED | SKIPPED | WARNING
function LogStatus {
    param(
        [string]$Server,
        [string]$Status,
        [string]$Detail = ""
    )
    $ts   = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $line = "$ts | $($Status.PadRight(8)) | $Server"
    if ($Detail -ne "") { $line += " | $Detail" }
    $line | Out-File $StatusLogFile -Append -Encoding UTF8
}

# Stores the final status for a DPM server in a hashtable.
# Only one status entry is kept per server — later calls overwrite earlier ones
# so the last outcome (success or failure) is what gets written to the CSV.
$ServerStatusMap = @{}

function LogStatusCSV {
    param(
        [string]$Server,
        [string]$Status,
        [string]$FailureReason = ""
    )
    $ServerStatusMap[$Server] = [PSCustomObject][ordered]@{
        "DPM Server Name" = $Server
        "Status"          = $Status
        "Failure Reason"  = $FailureReason
    }
}

Log "=================================================" -Type 'HEAD'
Log " DPM Inventory Launcher"                           -Type 'HEAD'
Log "=================================================" -Type 'HEAD'
Log "Server list  : $LocalServerListCSV"
Log "Output       : $MergedOutputFile"
Log ""

#--------------------------
# Load server list — first column, BOM-safe
#--------------------------
if (-not (Test-Path $LocalServerListCSV)) {
    Log "Server list CSV not found at: $LocalServerListCSV" -Type 'ERROR'
    exit 1
}

$ServerList = @(Import-Csv -Path $LocalServerListCSV |
                ForEach-Object { ($_.PSObject.Properties | Select-Object -First 1).Value } |
                Where-Object { $_ -and $_.Trim() -ne '' })

if ($ServerList.Count -eq 0) {
    Log "No server names found in $LocalServerListCSV" -Type 'ERROR'
    exit 1
}

Log "Servers to process: $($ServerList.Count)" -Type 'OK'
$ServerList | ForEach-Object { Log "  - $_" }
Log ""

# Initialise status log — overwrite any previous run
Remove-Item $StatusLogFile  -Force -ErrorAction SilentlyContinue
# $StatusCSVFile written once at end from $ServerStatusMap
Remove-Item $StatusCSVFile -Force -ErrorAction SilentlyContinue
"DPM Inventory Run Status"                                         | Out-File $StatusLogFile -Encoding UTF8
"Generated : $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"           | Out-File $StatusLogFile -Append -Encoding UTF8
"Servers in list : $($ServerList.Count)"                           | Out-File $StatusLogFile -Append -Encoding UTF8
("=" * 80)                                                         | Out-File $StatusLogFile -Append -Encoding UTF8
"Timestamp           | Status   | Server          | Detail"        | Out-File $StatusLogFile -Append -Encoding UTF8
("-" * 80)                                                         | Out-File $StatusLogFile -Append -Encoding UTF8

#--------------------------
# Detect local hostname
#--------------------------
$LocalHostname = $env:COMPUTERNAME

#--------------------------
# Collect per-server CSV paths for final merge
#--------------------------
$PerServerCSVs = [System.Collections.Generic.List[string]]::new()

#--------------------------
# Process each server
#--------------------------
$ServerIndex = 0

foreach ($TargetServer in $ServerList) {

    $ServerIndex++
    $ServerStart = Get-Date

    Log ""
    Log "=================================================" -Type 'HEAD'
    Log " Server $ServerIndex of $($ServerList.Count) : $TargetServer" -Type 'HEAD'
    Log "=================================================" -Type 'HEAD'

    $IsLocal = ($TargetServer -ieq $LocalHostname)         -or
               ($TargetServer -ieq "$LocalHostname.$env:USERDNSDOMAIN") -or
               ($TargetServer -ieq "localhost")             -or
               ($TargetServer -eq  "127.0.0.1")

    $RemoteScript     = "$RemoteWorkFolder\DPM_Inventory_Export.ps1"
    $RemoteOutputCSV  = "$RemoteWorkFolder\DPM_Inventory_$TargetServer.csv"
    $RemoteTaskLog    = "$RemoteWorkFolder\DPM_Inventory_$TargetServer.log"
    $LocalServerCSV   = "$LocalOutputFolder\DPM_Inventory_$TargetServer.csv"
    $LocalTaskLog     = "$LocalOutputFolder\DPM_Inventory_$TargetServer.log"

    # Single-server list — inventory script only processes this one server
    $SingleServerCSV  = "$env:TEMP\DPMSingleServer_$TargetServer.csv"
    "ServerName`n$TargetServer" | Out-File $SingleServerCSV -Encoding UTF8

    if ($IsLocal) {

        #--- LOCAL execution ---
        Log "Running locally on this machine (direct session call)..."

        $TempLocalScript = "$env:TEMP\Inventory_$TargetServer.ps1"
        $ScriptContent   = Get-Content $LocalInventoryScript -Raw
        # Target variable assignment lines directly — inventory script builds
        # $OutputFile from $OutputFolder so the full literal path never appears
        $ScriptContent   = $ScriptContent -replace '(?m)^\$OutputFile\s+=.*$',    "`$OutputFile    = `"$LocalServerCSV`""
        $ScriptContent   = $ScriptContent -replace '(?m)^\$ServerListCSV\s+=.*$', "`$ServerListCSV = `"$SingleServerCSV`""
        $ScriptContent | Out-File $TempLocalScript -Encoding UTF8

        try {
            & $TempLocalScript
            if (Test-Path $LocalServerCSV) {
                Log "Output CSV ready: $LocalServerCSV" -Type 'OK'
                $PerServerCSVs.Add($LocalServerCSV)
                LogStatus    $TargetServer "SUCCESS" "CSV produced locally — $LocalServerCSV"
                LogStatusCSV $TargetServer "Successful"
            } else {
                Log "Output CSV not found after local run." -Type 'WARN'
                LogStatus    $TargetServer "FAILED" "Output CSV not produced after local execution"
                LogStatusCSV $TargetServer "Failed" "Output CSV not produced after local execution"
            }
        } catch {
            Log "Local execution failed: $_" -Type 'ERROR'
            LogStatus    $TargetServer "FAILED" "Exception during local execution: $_"
            LogStatusCSV $TargetServer "Failed" "Exception during local execution: $_"
        } finally {
            Remove-Item $TempLocalScript -Force -ErrorAction SilentlyContinue
            Remove-Item $SingleServerCSV -Force -ErrorAction SilentlyContinue
        }

    } else {

        #--- REMOTE execution via temporary scheduled task ---
        Log "Preparing remote execution on $TargetServer via scheduled task..."

        # Step 1 — Pre-clean any leftover files from a previous run, then copy fresh
        Log "  Checking for leftover files from previous runs on $TargetServer..."
        $RemoteUNCFolder = "\\$TargetServer\C`$\DPM_Data"
        @(
            "$RemoteUNCFolder\DPM_Inventory_Export.ps1",
            "$RemoteUNCFolder\DPM_Inventory_Export.wrapper.ps1",
            "$RemoteUNCFolder\DPMServers.csv",
            "$RemoteUNCFolder\DPM_Inventory_$TargetServer.csv",
            "$RemoteUNCFolder\DPM_Inventory_$TargetServer.log"
        ) | ForEach-Object {
            if (Test-Path $_) {
                Remove-Item $_ -Force -ErrorAction SilentlyContinue
                Log "    Pre-cleaned: $_" -Type 'OK'
            }
        }

        Log "  Copying inventory script and server list to $TargetServer..."
        try {
            New-Item -ItemType Directory -Force -Path $RemoteUNCFolder | Out-Null

            # Patch output and server list paths in script copy
            $ScriptContent = Get-Content $LocalInventoryScript -Raw
            # Target variable assignment lines directly — inventory script builds
            # $OutputFile from $OutputFolder so the full literal path never appears
            $ScriptContent = $ScriptContent -replace '(?m)^\$OutputFile\s+=.*$',    "`$OutputFile    = `"$RemoteOutputCSV`""
            $ScriptContent = $ScriptContent -replace '(?m)^\$ServerListCSV\s+=.*$', "`$ServerListCSV = `"$RemoteWorkFolder\DPMServers.csv`""
            $ScriptContent | Out-File "$RemoteUNCFolder\DPM_Inventory_Export.ps1" -Encoding UTF8

            Copy-Item -Path $SingleServerCSV -Destination "$RemoteUNCFolder\DPMServers.csv" -Force
            Log "  Files copied." -Type 'OK'
        } catch {
            Log "  Could not copy files to $TargetServer — skipping. Error: $_" -Type 'ERROR'
            LogStatus    $TargetServer "SKIPPED" "File copy failed: $_"
            LogStatusCSV $TargetServer "Failed" "Could not copy files to remote server: $_"
            Remove-Item $SingleServerCSV -Force -ErrorAction SilentlyContinue
            # Clean up any partial files that may have been written before the failure
            Log "  Cleaning up any partial remote files on $TargetServer..."
            @(
                "$RemoteUNCFolder\DPM_Inventory_Export.ps1",
                "$RemoteUNCFolder\DPM_Inventory_Export.wrapper.ps1",
                "$RemoteUNCFolder\DPMServers.csv",
                "$RemoteUNCFolder\DPM_Inventory_$TargetServer.csv",
                "$RemoteUNCFolder\DPM_Inventory_$TargetServer.log"
            ) | ForEach-Object {
                if (Test-Path $_) { Remove-Item $_ -Force -ErrorAction SilentlyContinue; Log "    Removed: $_" -Type 'OK' }
            }
            continue
        }

        # Step 2 — Register scheduled task with UNLIMITED execution time
        # PT0S = zero duration = no time limit in Task Scheduler XML format
        # Without this Windows kills the task after its default ~1 hour or
        # session idle timeout — which was cutting the script off after ~20s
        Log "  Registering temporary scheduled task '$TempTaskName' on $TargetServer..."
        try {
            Invoke-Command -ComputerName $TargetServer -ErrorAction Stop -ScriptBlock {
                param($TaskName, $ScriptPath, $LogPath)

                # Clean up any leftover from previous run
                Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false -ErrorAction SilentlyContinue
                Remove-Item $LogPath -Force -ErrorAction SilentlyContinue

                # Write a small wrapper script that uses Start-Transcript for reliable
                # output capture — shell redirection (*>) is unreliable in scheduled tasks
                # because cmd.exe interprets it before PowerShell sees it
                $WrapperPath = [System.IO.Path]::ChangeExtension($ScriptPath, '.wrapper.ps1')
                @"
Start-Transcript -Path '$LogPath' -Force | Out-Null
try {
    & '$ScriptPath'
} catch {
    Write-Host "FATAL ERROR: `$_"
}
Stop-Transcript | Out-Null
"@ | Set-Content -Path $WrapperPath -Encoding UTF8

                $Argument  = "-NonInteractive -ExecutionPolicy Bypass -File `"$WrapperPath`""
                $Action    = New-ScheduledTaskAction -Execute "PowerShell.exe" -Argument $Argument
                $Principal = New-ScheduledTaskPrincipal -UserId "SYSTEM" -RunLevel Highest

                # TaskSettings with ExecutionTimeLimit = PT0S (unlimited)
                # New-TimeSpan -Seconds 0 = no time limit — task runs until finished
                $Settings  = New-ScheduledTaskSettingsSet `
                                -ExecutionTimeLimit      (New-TimeSpan -Seconds 0) `
                                -MultipleInstances        IgnoreNew                `
                                -RunOnlyIfNetworkAvailable:$false

                Register-ScheduledTask -TaskName  $TaskName  `
                                       -Action    $Action    `
                                       -Principal $Principal `
                                       -Settings  $Settings  `
                                       -Force | Out-Null

            } -ArgumentList $TempTaskName, $RemoteScript, $RemoteTaskLog
            Log "  Task registered (execution time limit: unlimited)." -Type 'OK'
        } catch {
            Log "  Could not register scheduled task on $TargetServer — skipping. Error: $_" -Type 'ERROR'
            LogStatus    $TargetServer "SKIPPED" "Scheduled task registration failed: $_"
            LogStatusCSV $TargetServer "Failed" "Scheduled task registration failed: $_"
            Remove-Item $SingleServerCSV -Force -ErrorAction SilentlyContinue
            # Clean up files that were already copied before task registration failed
            Log "  Cleaning up remote files on $TargetServer after registration failure..."
            @(
                "$RemoteUNCFolder\DPM_Inventory_Export.ps1",
                "$RemoteUNCFolder\DPM_Inventory_Export.wrapper.ps1",
                "$RemoteUNCFolder\DPMServers.csv",
                "$RemoteUNCFolder\DPM_Inventory_$TargetServer.csv",
                "$RemoteUNCFolder\DPM_Inventory_$TargetServer.log"
            ) | ForEach-Object {
                if (Test-Path $_) { Remove-Item $_ -Force -ErrorAction SilentlyContinue; Log "    Removed: $_" -Type 'OK' }
            }
            continue
        }

        # Step 3 — Start task and poll until complete
        Log "  Starting task and waiting for completion (timeout: $TaskTimeoutMinutes min)..."
        $TaskComplete = $false
        try {
            Invoke-Command -ComputerName $TargetServer -ErrorAction Stop -ScriptBlock {
                param($TaskName)
                Start-ScheduledTask -TaskName $TaskName
            } -ArgumentList $TempTaskName

            $Deadline = (Get-Date).AddMinutes($TaskTimeoutMinutes)
            while ((Get-Date) -lt $Deadline) {
                Start-Sleep -Seconds 15
                $State = Invoke-Command -ComputerName $TargetServer -ErrorAction SilentlyContinue -ScriptBlock {
                    param($TaskName)
                    (Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue).State
                } -ArgumentList $TempTaskName

                $Elapsed = [math]::Round(((Get-Date) - $ServerStart).TotalSeconds)
                Log "  Task state: $State — elapsed: ${Elapsed}s"

                # State 4 = Running (enum integer), 'Running' = string representation
                # must check both since Get-ScheduledTask returns the enum value
                if ($State -ne 'Running' -and $State -ne 4) {
                    $TaskComplete = $true
                    break
                }
            }

            if (-not $TaskComplete) {
                Log "  Task timed out after $TaskTimeoutMinutes minutes on $TargetServer." -Type 'WARN'
                LogStatus    $TargetServer "WARNING" "Task timed out after $TaskTimeoutMinutes minutes — CSV may be incomplete"
                LogStatusCSV $TargetServer "Failed" "Task timed out after $TaskTimeoutMinutes minutes — inventory incomplete"
            } else {
                Log "  Task completed." -Type 'OK'
            }

        } catch {
            Log "  Error while waiting for task: $_" -Type 'ERROR'
            LogStatus    $TargetServer "FAILED" "Error while waiting for task: $_"
            LogStatusCSV $TargetServer "Failed" "Error while waiting for scheduled task: $_"
        }

        # Step 4 — Delete scheduled task immediately
        Log "  Removing scheduled task from $TargetServer..."
        try {
            Invoke-Command -ComputerName $TargetServer -ErrorAction SilentlyContinue -ScriptBlock {
                param($TaskName)
                Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false -ErrorAction SilentlyContinue
            } -ArgumentList $TempTaskName
            Log "  Task removed." -Type 'OK'
        } catch {
            Log "  Could not remove task — delete '$TempTaskName' manually from $TargetServer." -Type 'WARN'
        }

        # Step 5 — Always copy task log back (even on failure — needed for diagnosis)
        $RemoteUNCLog = "\\$TargetServer\C`$\DPM_Data\DPM_Inventory_$TargetServer.log"
        if (Test-Path $RemoteUNCLog) {
            Copy-Item -Path $RemoteUNCLog -Destination $LocalTaskLog -Force -ErrorAction SilentlyContinue
            Log "  Task log copied to: $LocalTaskLog" -Type 'OK'
            Log "  --- Task log contents ---" -Type 'HEAD'
            Get-Content $LocalTaskLog | ForEach-Object { Log "  $_" }
            Log "  --- End of task log ---" -Type 'HEAD'
        } else {
            Log "  No task log found at $RemoteUNCLog" -Type 'WARN'
        }

        # Step 6 — Copy CSV back
        if ($TaskComplete) {
            Log "  Copying output CSV back to local machine..."
            $RemoteUNCOutput = "\\$TargetServer\C`$\DPM_Data\DPM_Inventory_$TargetServer.csv"
            if (Test-Path $RemoteUNCOutput) {
                try {
                    New-Item -ItemType Directory -Force -Path $LocalOutputFolder | Out-Null
                    Copy-Item -Path $RemoteUNCOutput -Destination $LocalServerCSV -Force
                    Log "  CSV copied: $LocalServerCSV" -Type 'OK'
                    $PerServerCSVs.Add($LocalServerCSV)
                    LogStatus    $TargetServer "SUCCESS" "CSV produced and copied — $LocalServerCSV"
                    LogStatusCSV $TargetServer "Successful"
                } catch {
                    Log "  Could not copy CSV from $TargetServer : $_" -Type 'ERROR'
                }
            } else {
                Log "  Output CSV not found on $TargetServer — check task log above." -Type 'WARN'
                LogStatus    $TargetServer "FAILED" "Task completed but output CSV was not found — check $LocalTaskLog"
                LogStatusCSV $TargetServer "Failed" "Task completed but output CSV was not produced — check $LocalTaskLog"
            }
        }

        Remove-Item $SingleServerCSV -Force -ErrorAction SilentlyContinue

        # Step 7 — Clean up all files left on the remote server
        # Always runs regardless of task success or failure.
        # Removes: Inventory.ps1, DPMServers.csv, per-server CSV, per-server log
        # Uses UNC path — no remoting session needed
        Log "  Cleaning up remote files on $TargetServer..."
        @(
            "$RemoteUNCFolder\DPM_Inventory_Export.ps1",
            "$RemoteUNCFolder\DPM_Inventory_Export.wrapper.ps1",
            "$RemoteUNCFolder\DPMServers.csv",
            "$RemoteUNCFolder\DPM_Inventory_$TargetServer.csv",
            "$RemoteUNCFolder\DPM_Inventory_$TargetServer.log"
        ) | ForEach-Object {
            if (Test-Path $_) {
                Remove-Item $_ -Force -ErrorAction SilentlyContinue
                Log "    Removed: $_" -Type 'OK'
            }
        }
        Log "  Remote cleanup complete." -Type 'OK'
    }

    $ServerElapsed = [math]::Round(((Get-Date) - $ServerStart).TotalSeconds, 1)
    Log "Server $TargetServer finished in ${ServerElapsed}s" -Type 'OK'
}

#--------------------------
# Merge all per-server CSVs
#--------------------------
Log ""
Log "=================================================" -Type 'HEAD'
Log " Merging $($PerServerCSVs.Count) CSV file(s)..."   -Type 'HEAD'
Log "=================================================" -Type 'HEAD'

if ($PerServerCSVs.Count -gt 0) {
    $AllRows    = [System.Collections.Generic.List[PSCustomObject]]::new()
    $SerialNum  = 0   # increments per DPM server — 1 for first server, 2 for second, etc.

    foreach ($csvPath in $PerServerCSVs) {
        if (Test-Path $csvPath) {
            $SerialNum++
            $rows = Import-Csv -Path $csvPath
            foreach ($row in $rows) {
                # Insert DPM Server Serial No as the first column
                $stamped = [PSCustomObject][ordered]@{ 'DPM Server Serial No' = $SerialNum }
                $row.PSObject.Properties | ForEach-Object { $stamped | Add-Member -NotePropertyName $_.Name -NotePropertyValue $_.Value }
                $AllRows.Add($stamped)
            }
            Log "  Merged: $csvPath ($($rows.Count) rows) — Serial No: $SerialNum"
        } else {
            Log "  Skipped (not found): $csvPath" -Type 'WARN'
        }
    }

    if ($AllRows.Count -gt 0) {
        $AllRows | Export-Csv -Path $MergedOutputFile -NoTypeInformation -Encoding UTF8
        $TotalElapsed = [math]::Round(((Get-Date) - $LaunchStart).TotalSeconds, 1)
        Log ""
        Log "===========================================" -Type 'HEAD'
        Log " Export complete"                            -Type 'OK'
        Log " Servers processed : $($PerServerCSVs.Count) of $($ServerList.Count)"
        Log " Total datasources : $($AllRows.Count)"
        Log " Total time        : ${TotalElapsed}s"
        Log " Output file       : $MergedOutputFile"
        Log "===========================================" -Type 'HEAD'
    } else {
        Log "No rows collected — merged CSV not written." -Type 'WARN'
    }
} else {
    Log "No per-server CSVs were produced — nothing to merge." -Type 'WARN'
}

#--------------------------
# Clean up local per-server working files — runs AFTER merge so per-server
# CSVs are available for merging first, then deleted once no longer needed.
# Keeps: 3 original files, all versioned merged CSVs
# Removes: per-server CSVs and logs, status files (refreshed each run)
#--------------------------
Log ""
Log "Cleaning up local per-server working files..." -Type 'HEAD'
$ProtectedFiles = @(
    "DPM_Inventory_Launcher.ps1",
    "DPM_Inventory_Export.ps1",
    "DPMServers.csv"
)
Get-ChildItem -Path $LocalOutputFolder -File | ForEach-Object {
    $fname = $_.Name
    # Keep the 3 original files
    if ($ProtectedFiles -contains $fname) { return }
    # Keep all versioned merged inventory CSVs
    if ($fname -match '^DPM_Inventory(_v\d+)?\.csv$') { return }
    # Delete everything else — per-server working CSVs, logs, status files
    Remove-Item $_.FullName -Force -ErrorAction SilentlyContinue
    Log "  Removed local working file: $fname" -Type 'OK'
}
Log "Local cleanup complete." -Type 'OK'
Log ""

#--------------------------
# Write status log summary
#--------------------------
("-" * 80)                                                         | Out-File $StatusLogFile -Append -Encoding UTF8
"SUMMARY"                                                          | Out-File $StatusLogFile -Append -Encoding UTF8
("-" * 80)                                                         | Out-File $StatusLogFile -Append -Encoding UTF8
"Total servers in list : $($ServerList.Count)"                     | Out-File $StatusLogFile -Append -Encoding UTF8
"Servers succeeded     : $($PerServerCSVs.Count)"                  | Out-File $StatusLogFile -Append -Encoding UTF8
"Servers failed/skipped: $($ServerList.Count - $PerServerCSVs.Count)" | Out-File $StatusLogFile -Append -Encoding UTF8
"Run completed         : $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')" | Out-File $StatusLogFile -Append -Encoding UTF8

Log ""
# Write one row per DPM server to the status CSV
if ($ServerStatusMap.Count -gt 0) {
    $ServerStatusMap.Values |
        Sort-Object "DPM Server Name" |
        Export-Csv -Path $StatusCSVFile -NoTypeInformation -Encoding UTF8
}
Log "Status log saved to : $StatusLogFile" -Type 'OK'
Log "Status CSV saved to : $StatusCSVFile" -Type 'OK'
Log ""