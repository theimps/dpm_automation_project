﻿#************************************************
#  DPM_Inventory_Export.ps1
#  Description : Full inventory of all DPM-protected datasources
#                across multiple DPM servers.
#                Reads server list from a CSV file.
#                Exports one combined row-per-datasource CSV with
#                full disk/tape/online schedule and retention detail.
#
#  SERVER LIST CSV:
#  Must have a column named "ServerName" (one DPM server per row).
#  Example C:\DPM_Data\DPMServers.csv:
#       ServerName
#       ITMIL1SVAS010
#       FRPAR1SVAS003
#
#  NOTE: The script reads the first column of the CSV regardless of
#  header name, so Excel-saved CSVs with BOM characters work correctly.
#
#  OUTPUT:
#  C:\DPM_Data\DPM_Inventory.csv  (combined, all servers)
#
#Requires -RunAsAdministrator
#************************************************

$progressPreference = "SilentlyContinue"

#--------------------------
# Paths
#--------------------------
$OutputFolder  = "C:\DPM_Data"
$OutputFile    = "$OutputFolder\DPM_Inventory.csv"
$ServerListCSV = "$OutputFolder\DPMServers.csv"

Remove-Item -Force $OutputFile -ErrorAction SilentlyContinue
New-Item -ItemType Directory -Force -Path $OutputFolder | Out-Null

#--------------------------
# Progress helper — prints timestamp + indented message
# Level 0 = top level  (white)
# Level 1 = server     (cyan)
# Level 2 = PG         (yellow)
# Level 3 = datasource (gray)
# Type  E = error/warning (red)
#--------------------------
function Log {
    param(
        [string]$Message,
        [int]$Level    = 0,
        [string]$Type  = 'INFO'
    )
    $ts     = Get-Date -Format "HH:mm:ss"
    $indent = "  " * $Level
    $color  = switch ($Type) {
        'ERROR' { 'Red'    }
        'WARN'  { 'Yellow' }
        'OK'    { 'Green'  }
        default {
            switch ($Level) {
                0 { 'White'  }
                1 { 'Cyan'   }
                2 { 'Yellow' }
                3 { 'Gray'   }
                default { 'White' }
            }
        }
    }
    Write-Host "[$ts]$indent $Message" -ForegroundColor $color
}

Log "DPM Multi-Server Inventory Export" -Level 0
Log "Server list : $ServerListCSV"      -Level 0
Log "Output      : $OutputFile"         -Level 0
Log ""                                  -Level 0

#--------------------------
# Load server list
# Reads first column — immune to Excel BOM on header
#--------------------------
Log "Loading server list..." -Level 0

if (-not (Test-Path $ServerListCSV)) {
    Log "Server list CSV not found at: $ServerListCSV" -Type 'ERROR'
    exit 1
}

$ServerList = @(Import-Csv -Path $ServerListCSV |
                ForEach-Object { ($_.PSObject.Properties | Select-Object -First 1).Value } |
                Where-Object { $_ -and $_.Trim() -ne '' })

if ($ServerList.Count -eq 0) {
    Log "No server names found in $ServerListCSV" -Type 'ERROR'
    exit 1
}

Log "Servers to process: $($ServerList.Count)" -Level 0 -Type 'OK'
$ServerList | ForEach-Object { Log "  - $_" -Level 0 }
Log "" -Level 0

#--------------------------
# Load DPM module
#--------------------------
Log "Loading DataProtectionManager module..." -Level 0
try {
    Import-Module DataProtectionManager -ErrorAction Stop
    Log "Module loaded successfully." -Level 0 -Type 'OK'
} catch {
    Log "Could not load DataProtectionManager module: $_" -Type 'ERROR'
    exit 1
}

#--------------------------
# Helpers
#--------------------------
function Safe([object]$val) {
    if ($null -eq $val -or $val -eq '') { return 'N/A' }
    return $val.ToString().Trim()
}

function FormatRetention([object]$obj) {
    if ($null -eq $obj) { return 'N/A' }
    try {
        $r = $obj.range
        $u = $obj.unit
        if ($r -and $u) { return "$r $u" }
    } catch { }
    return 'N/A'
}

function GetLastRP([object]$ds) {
    try {
        $rps = @(Get-DPMRecoveryPoint -Datasource $ds -ErrorAction SilentlyContinue |
                 Sort-Object RepresentedPointInTime -Descending)
        if ($rps.Count -gt 0) {
            return $rps[0].RepresentedPointInTime.ToString("yyyy-MM-dd HH:mm")
        }
    } catch { }
    return 'N/A'
}

# Formats a DPM schedule description string for display.
# If all 7 days (Sun-Sat) are present in the description it means
# the backup runs every day — reformat to "Daily Sun-Sat HH:MM AM/PM"
# for clarity instead of listing all 7 day names in full.
# Works for disk, tape and online schedule descriptions.
function FormatScheduleDesc([string]$desc) {
    if ([string]::IsNullOrWhiteSpace($desc) -or $desc -eq 'N/A') { return $desc }

    $d = $desc.ToLower()

    # Check if all 7 days are present in the description
    $allDays = @('sunday','monday','tuesday','wednesday','thursday','friday','saturday')
    $allPresent = $true
    foreach ($day in $allDays) {
        if ($d -notmatch $day) { $allPresent = $false; break }
    }

    if ($allPresent) {
        # Extract time portion — match patterns like "9:00 PM", "09:00 AM", "21:00"
        $timeMatch = [regex]::Match($desc, '\d{1,2}:\d{2}\s*(AM|PM)?', [System.Text.RegularExpressions.RegexOptions]::IgnoreCase)
        $timePart  = if ($timeMatch.Success) { $timeMatch.Value.Trim() } else { '' }
        if ($timePart -ne '') {
            return "Daily Sun-Sat $timePart"
        } else {
            return "Daily Sun-Sat"
        }
    }

    return $desc
}

# Builds a clean human-readable schedule description from raw schedule object properties.
# DPM's ScheduleDescription for monthly/yearly can be cryptic (e.g. "1 EveryMonth, 9:00 PM")
# This function uses the actual properties to produce readable output like:
#   "Day 1 of every month at 9:00 PM"
#   "Last Saturday at 9:00 PM"
#   "Last Saturday of March at 9:00 PM"
#   "Daily Sun-Sat at 9:00 PM"
function BuildScheduleDesc([object]$sched) {
    try {
        $freq = $sched.Frequency.ToString()

        # Extract time string from TimesOfDay array
        $times = @($sched.TimesOfDay) | Where-Object { $null -ne $_ } | ForEach-Object {
            $dt = [datetime]$_
            $dt.ToString("h:mm tt")
        }
        $timeStr = if ($times.Count -gt 0) { $times -join ', ' } else { '' }

        # Map RelativeInterval enum values to words
        $relIntervals = @($sched.RelativeIntervals) | Where-Object { $_ -and $_.ToString() -ne 'None' }
        $relWeekDays  = @($sched.RelativeWeekDays)  | Where-Object { $_ -and $_.ToString() -ne 'None' }
        $weekDays     = @($sched.WeekDays)           | Where-Object { $_ -and $_.ToString() -ne 'None' }
        $monthDays    = @($sched.MonthDays)          | Where-Object { $null -ne $_ -and $_ -gt 0 }
        $months       = @($sched.Months)             | Where-Object { $_ -and $_.ToString() -ne 'None' }

        # Lookup table — expand DPM abbreviated day names to full names
        $dayNameMap = @{
            'Su' = 'Sunday';    'Mo' = 'Monday';    'Tu' = 'Tuesday'
            'We' = 'Wednesday'; 'Th' = 'Thursday';  'Fr' = 'Friday'
            'Sa' = 'Saturday'
        }
        function ExpandDay([string]$d) {
            if ($dayNameMap.ContainsKey($d)) { return $dayNameMap[$d] }
            return $d   # already full name or unknown — return as-is
        }

        # Relative interval label (First/Second/Third/Fourth/Last)
        $relLabel = if ($relIntervals.Count -gt 0) { $relIntervals[0].ToString() } else { '' }

        # Relative weekday label — expanded to full day name (e.g. Sa -> Saturday)
        $relDayLabel = if ($relWeekDays.Count -gt 0) { ExpandDay $relWeekDays[0].ToString() } else { '' }

        # Month label (e.g. March)
        $monthLabel = if ($months.Count -gt 0) { $months[0].ToString() } else { '' }

        $at = if ($timeStr -ne '') { " at $timeStr" } else { '' }

        switch ($freq) {
            'Daily' {
                # All 7 days — already handled by FormatScheduleDesc
                # but rebuild cleanly here too
                if ($weekDays.Count -eq 7) {
                    return "Daily Sun-Sat$at"
                } elseif ($weekDays.Count -gt 0) {
                    $dayNames = ($weekDays | ForEach-Object { ExpandDay $_.ToString() }) -join ', '
                    return "$dayNames$at"
                }
                return "Daily$at"
            }
            'Weekly' {
                if ($weekDays.Count -gt 0) {
                    $dayNames = ($weekDays | ForEach-Object { ExpandDay $_.ToString() }) -join ', '
                    return "Every $dayNames$at"
                }
                return "Weekly$at"
            }
            'Monthly' {
                if ($relLabel -ne '' -and $relDayLabel -ne '') {
                    return "$relLabel $relDayLabel of every month$at"
                } elseif ($monthDays.Count -gt 0) {
                    $dayNum = $monthDays[0]
                    return "Day $dayNum of every month$at"
                }
                return "Monthly$at"
            }
            'Yearly' {
                if ($relLabel -ne '' -and $relDayLabel -ne '' -and $monthLabel -ne '') {
                    return "$relLabel $relDayLabel of $monthLabel$at"
                } elseif ($monthDays.Count -gt 0 -and $monthLabel -ne '') {
                    $dayNum = $monthDays[0]
                    return "Day $dayNum of $monthLabel$at"
                } elseif ($monthLabel -ne '') {
                    return "$monthLabel$at"
                }
                return "Yearly$at"
            }
            default {
                # Fall back to ScheduleDescription if we can't parse
                return Safe $sched.ScheduleDescription
            }
        }
    } catch {
        return Safe $sched.ScheduleDescription
    }
}

function DetectFrequency([string]$desc, [int]$goalIndex) {
    if ([string]::IsNullOrWhiteSpace($desc)) { return "Goal$goalIndex" }
    $d = $desc.ToLower()
    # Yearly — full month names, abbreviated month names (jan/feb/mar etc),
    # explicit 'yearly' keyword, 'every year', 'annual'
    if ($d -match 'january|february|march|april|may|june|july|august|september|october|november|december' -or
        $d -match 'jan|feb|mar|apr|jun|jul|aug|sep|oct|nov|dec' -or
        $d -match 'yearly' -or $d -match 'every year' -or $d -match 'annual') { return 'Yearly'  }
    if ($d -match 'month'  -or $d -match 'monthly')    { return 'Monthly' }
    if ($d -match 'week'   -or $d -match 'weekly' -or
        $d -match 'monday|tuesday|wednesday|thursday|friday|saturday|sunday') { return 'Weekly' }
    if ($d -match 'every day' -or $d -match 'daily')   { return 'Daily'   }
    return "Goal$goalIndex"
}

function ResolveRemoteDBInfo([string]$ServerName) {
    # If running on the target server itself, read registry locally — no Invoke-Command overhead
    $LocalHost = $env:COMPUTERNAME
    $IsLocalServer = ($ServerName -ieq $LocalHost -or
                      $ServerName -ieq "$LocalHost.$env:USERDNSDOMAIN" -or
                      $ServerName -ieq 'localhost')

    $regBlock = {
        $reg = Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Microsoft Data Protection Manager\DB" `
                                -ErrorAction SilentlyContinue
        $dbName = if ($reg -and $reg.DatabaseName -and $reg.DatabaseName -ne '') {
                      $reg.DatabaseName
                  } else {
                      "DPMDB_$env:COMPUTERNAME"
                  }
        $instanceName = $null
        if ($reg -and $reg.InstanceName -and
            $reg.InstanceName -ne '' -and
            $reg.InstanceName -ne 'MSSQLSERVER') {
            $instanceName = $reg.InstanceName
        } else {
            $svc = Get-Service -ErrorAction SilentlyContinue |
                   Where-Object { $_.Name -match "^MSSQL\$" -and
                                  $_.Name -ne 'MSSQLSERVER'  -and
                                  $_.Status -eq 'Running' } |
                   Select-Object -First 1
            if ($svc -and $svc.Name -match 'MSSQL\$(.+)') {
                $instanceName = $Matches[1]
            }
        }
        $srvInstance = if ($instanceName) { "$env:COMPUTERNAME\$instanceName" } else { $env:COMPUTERNAME }
        return @{ DPMDB = $dbName; SRVInstance = $srvInstance }
    }

    if ($IsLocalServer) {
        # Run directly — no remoting, no latency
        try {
            return & $regBlock
        } catch {
            Log "  Could not read local registry — using defaults. Error: $_" -Level 1 -Type 'WARN'
            return @{ DPMDB = "DPMDB_$LocalHost"; SRVInstance = $LocalHost }
        }
    } else {
        # Remote server — use Invoke-Command
        try {
            $result = Invoke-Command -ComputerName $ServerName -ErrorAction Stop -ScriptBlock $regBlock
            return $result
        } catch {
            Log "  Could not read remote registry on $ServerName — using defaults. Error: $_" -Level 1 -Type 'WARN'
            return @{ DPMDB = "DPMDB_$ServerName"; SRVInstance = $ServerName }
        }
    }
}

#--------------------------
# Main loop
#--------------------------
$Inventory      = [System.Collections.Generic.List[PSCustomObject]]::new()
$ScriptStart    = Get-Date
$ServerCount    = 0
$ServerTotal    = $ServerList.Count

foreach ($DPMServerName in $ServerList) {

    $ServerCount++
    $ServerStart = Get-Date
    Log "" -Level 0
    Log "=================================================" -Level 0
    Log "Server $ServerCount of $ServerTotal : $DPMServerName" -Level 1
    Log "=================================================" -Level 0

    # Connect
    # When the script runs ON the DPM server itself (via scheduled task),
    # Connect-DPMServer is skipped entirely — DPM cmdlets default to the
    # local server automatically, making startup near-instant.
    # Connect-DPMServer is only called when targeting a genuinely remote server.
    $LocalHost   = $env:COMPUTERNAME
    $IsLocalDPM  = ($DPMServerName -ieq $LocalHost -or
                    $DPMServerName -ieq "$LocalHost.$env:USERDNSDOMAIN" -or
                    $DPMServerName -ieq 'localhost')
    $ConnectName = if ($IsLocalDPM) { $LocalHost } else { $DPMServerName }

    if ($IsLocalDPM) {
        Log "Running on local DPM server — no Connect-DPMServer needed." -Level 1 -Type 'OK'
    } else {
        Log "Connecting to remote DPM server: $ConnectName..." -Level 1
        try {
            Connect-DPMServer -DPMServerName $ConnectName | Out-Null
            Log "Connected successfully." -Level 1 -Type 'OK'
        } catch {
            Log "Could not connect to $ConnectName — skipping. Error: $_" -Level 1 -Type 'ERROR'
            continue
        }
    }

    # Remote DB info
    Log "Resolving SQL instance and DPMDB name..." -Level 1
    $DBInfo      = ResolveRemoteDBInfo $DPMServerName
    $DPMDB       = $DBInfo.DPMDB
    $SRVInstance = $DBInfo.SRVInstance
    Log "DPMDB        : $DPMDB"       -Level 1
    Log "SQL Instance : $SRVInstance" -Level 1

    # Protection groups
    Log "Fetching protection groups..." -Level 1
    # When local, call Get-ProtectionGroup without a server name
    # so it uses the default local DPM connection — fastest path
    if ($IsLocalDPM) {
        $PGList = @(Get-ProtectionGroup 2>$null | Sort-Object Name)
    } else {
        $PGList = @(Get-ProtectionGroup $ConnectName 2>$null | Sort-Object Name)
    }
    Log "Protection groups found: $($PGList.Count)" -Level 1 -Type 'OK'

    if ($PGList.Count -eq 0) {
        Log "No protection groups on $DPMServerName — skipping." -Level 1 -Type 'WARN'
        continue
    }

    $PGCount = 0
    $PGTotal = $PGList.Count

    foreach ($pg in $PGList) {

        $PGCount++
        $PGStart = Get-Date
        Log "" -Level 1
        Log "PG $PGCount of $PGTotal : $($pg.Name)" -Level 2

        #--- Initialise all policy fields ---
        $DiskBackupSchedule  = 'N/A'; $DiskBackupRetention = 'N/A'
        $TapeDaily_Schedule   = 'N/A'; $TapeDaily_Retention   = 'N/A'
        $TapeWeekly_Schedule  = 'N/A'; $TapeWeekly_Retention  = 'N/A'
        $TapeMonthly_Schedule = 'N/A'; $TapeMonthly_Retention = 'N/A'
        $TapeYearly_Schedule  = 'N/A'; $TapeYearly_Retention  = 'N/A'
        $OnlineDaily_Schedule   = 'N/A'; $OnlineDaily_Retention   = 'N/A'
        $OnlineWeekly_Schedule  = 'N/A'; $OnlineWeekly_Retention  = 'N/A'
        $OnlineMonthly_Schedule = 'N/A'; $OnlineMonthly_Retention = 'N/A'
        $OnlineYearly_Schedule  = 'N/A'; $OnlineYearly_Retention  = 'N/A'

        #--- Short-term disk ---
        # NOTE: Get-DPMPolicySchedule -ShortTerm can return MORE THAN ONE schedule
        # object for a single PG (e.g. a different RP schedule for weekdays vs.
        # weekends). Accessing .ScheduleDescription directly on a multi-item result
        # triggers PowerShell member-enumeration, returning an array of strings —
        # which Safe() then stringifies to the literal "System.Object[]". Force
        # array context with @() and format/join each schedule individually instead.
        if ($pg.IsDiskShortTerm) {
            Log "  Reading disk short-term policy..." -Level 2
            try {
                $diskSchedules = @(Get-DPMPolicySchedule -ProtectionGroup $pg -ShortTerm -ErrorAction SilentlyContinue)
                $diskDescs = @($diskSchedules | ForEach-Object { FormatScheduleDesc (Safe $_.ScheduleDescription) } |
                               Where-Object { $_ -and $_ -ne 'N/A' } | Select-Object -Unique)
                if ($diskDescs.Count -gt 0) {
                    $DiskBackupSchedule = $diskDescs -join ' | '
                }
            } catch {}
            try {
                $obj = Get-DPMPolicyObjective -ProtectionGroup $pg -ShortTerm -ErrorAction SilentlyContinue
                $DiskBackupRetention = FormatRetention $obj.RetentionRange
                if ($DiskBackupRetention -eq 'N/A') { $DiskBackupRetention = FormatRetention $obj.retentionrange }
            } catch {}
        }

        #--- Long-term tape ---
        if ($pg.IsTapeLongTerm) {
            Log "  Reading tape long-term policy..." -Level 2
            try {
                $ltSchedules = @(Get-DPMPolicySchedule -ProtectionGroup $pg -LongTerm Tape -ErrorAction SilentlyContinue |
                                 Sort-Object jobtype -Descending)
                $retentions = @()
                try { $retentions += Safe $pg.ArchiveIntent.RetentionPolicy.OffsiteFather.ToString() }          catch { $retentions += 'N/A' }
                try {
                    if ($pg.ArchiveIntent.RetentionPolicy.OffsiteGrandfather.Enabled) {
                        $retentions += Safe $pg.ArchiveIntent.RetentionPolicy.OffsiteGrandfather.ToString()
                    } else { $retentions += 'N/A' }
                } catch { $retentions += 'N/A' }
                try {
                    if ($pg.ArchiveIntent.RetentionPolicy.OffsiteGreatGrandfather.Enabled) {
                        $retentions += Safe $pg.ArchiveIntent.RetentionPolicy.OffsiteGreatGrandfather.ToString()
                    } else { $retentions += 'N/A' }
                } catch { $retentions += 'N/A' }

                for ($i = 0; $i -lt $ltSchedules.Count; $i++) {
                    $schedDesc = FormatScheduleDesc (Safe $ltSchedules[$i].ScheduleDescription)
                    $retention = if ($i -lt $retentions.Count) { $retentions[$i] } else { 'N/A' }
                    $freq      = DetectFrequency $schedDesc ($i + 1)
                    switch ($freq) {
                        'Daily'   { $TapeDaily_Schedule   = $schedDesc; $TapeDaily_Retention   = $retention }
                        'Weekly'  { $TapeWeekly_Schedule  = $schedDesc; $TapeWeekly_Retention  = $retention }
                        'Monthly' { $TapeMonthly_Schedule = $schedDesc; $TapeMonthly_Retention = $retention }
                        'Yearly'  { $TapeYearly_Schedule  = $schedDesc; $TapeYearly_Retention  = $retention }
                        default   {
                            if      ($TapeDaily_Schedule   -eq 'N/A') { $TapeDaily_Schedule   = $schedDesc; $TapeDaily_Retention   = $retention }
                            elseif  ($TapeWeekly_Schedule  -eq 'N/A') { $TapeWeekly_Schedule  = $schedDesc; $TapeWeekly_Retention  = $retention }
                            elseif  ($TapeMonthly_Schedule -eq 'N/A') { $TapeMonthly_Schedule = $schedDesc; $TapeMonthly_Retention = $retention }
                            elseif  ($TapeYearly_Schedule  -eq 'N/A') { $TapeYearly_Schedule  = $schedDesc; $TapeYearly_Retention  = $retention }
                        }
                    }
                }
            } catch {}
        }

        #--- Online / Azure ---
        # Get-DPMPolicySchedule -LongTerm online returns an ARRAY of schedule objects.
        # Each object has a native Frequency property used for schedule mapping.
        #
        # RETENTION SOURCE STRATEGY:
        # RetentionRangeWeekly is NOT exposed by DPM cmdlets (confirmed via testing).
        # All four retention values are read from tbl_IM_CloudPolicy in DPMDB via SQL
        # which stores RecoveryRangeDaily/Weekly/Monthly/Yearly as integers.
        # Units: Daily=Days, Weekly=Weeks, Monthly=Months, Yearly=Years.
        # Cmdlet values used as fallback if SQL lookup fails or returns 0.
        if ($pg.IsCloudLongTerm) {
            Log "  Reading online/Azure policy..." -Level 2
            try {
                $onlineSchedules = @(Get-DPMPolicySchedule -ProtectionGroup $pg -LongTerm online -ErrorAction SilentlyContinue)
                $onlineObj       = Get-DPMPolicyObjective $pg -LongTerm Online -ErrorAction SilentlyContinue

                # --- SQL-sourced retention (authoritative) ---
                # Keyed by CloudPolicyId which links ProtectedGroup to CloudPolicy
                $sqlOnlineRetention = $null
                if ($DPMDB -and $SRVInstance) {
                    try {
                        $pgIdClean = $pg.ProtectionGroupId.ToString().Trim('{}')
                        $sqlRetQuery = "
                            SELECT
                                cp.RecoveryRangeDaily   AS Daily,
                                cp.RecoveryRangeWeekly  AS Weekly,
                                cp.RecoveryRangeMonthly AS Monthly,
                                cp.RecoveryRangeYearly  AS Yearly
                            FROM [$DPMDB].[dbo].[tbl_IM_ProtectedGroup] pg
                            JOIN [$DPMDB].[dbo].[tbl_IM_CloudPolicy] cp
                                ON pg.CloudPolicyId = cp.CloudPolicyId
                            WHERE pg.ProtectedGroupId = '$pgIdClean'"
                        $sqlOnlineRetention = Invoke-Sqlcmd -ServerInstance $SRVInstance -Query $sqlRetQuery -ErrorAction SilentlyContinue |
                                             Select-Object -First 1
                    } catch {}
                }

                # Helper — format SQL integer retention with explicit unit label
                function FormatSQLRetention([object]$val, [string]$unit) {
                    if ($null -eq $val) { return 'N/A' }
                    $n = [int]$val
                    if ($n -le 0)      { return 'N/A' }
                    return "$n $unit"
                }

                # AUTHORITATIVE SOURCE FOR ENABLED TIERS:
                # Get-DPMPolicySchedule only returns objects for ENABLED/CHECKED tiers.
                # Unchecked tiers produce no schedule object regardless of SQL retention value.
                # Strategy:
                #   1. Iterate schedule objects — these define which tiers are active
                #   2. For each active tier, populate schedule from raw properties
                #   3. Populate retention from SQL for that tier only
                #   4. Any tier with no schedule object stays N/A for both schedule AND retention
                # This ensures a tier with retention stored in SQL but checkbox unchecked
                # in the UI never appears in the CSV output.

                # Build a set of enabled frequency names from schedule objects
                $enabledFreqs = @{}
                foreach ($onlineSched in $onlineSchedules) {
                    $freq = $onlineSched.Frequency.ToString()
                    $enabledFreqs[$freq] = $onlineSched
                }

                # Daily
                if ($enabledFreqs.ContainsKey('Daily')) {
                    $OnlineDaily_Schedule  = BuildScheduleDesc $enabledFreqs['Daily']
                    $OnlineDaily_Retention = if ($sqlOnlineRetention) {
                                                FormatSQLRetention $sqlOnlineRetention.Daily 'Days'
                                            } else {
                                                FormatRetention $onlineObj.RetentionRangeDaily
                                            }
                }

                # Weekly
                if ($enabledFreqs.ContainsKey('Weekly')) {
                    $OnlineWeekly_Schedule  = BuildScheduleDesc $enabledFreqs['Weekly']
                    $OnlineWeekly_Retention = if ($sqlOnlineRetention) {
                                                 FormatSQLRetention $sqlOnlineRetention.Weekly 'Weeks'
                                             } else {
                                                 FormatRetention $onlineObj.RetentionRangeWeekly
                                             }
                }

                # Monthly
                if ($enabledFreqs.ContainsKey('Monthly')) {
                    $OnlineMonthly_Schedule  = BuildScheduleDesc $enabledFreqs['Monthly']
                    $OnlineMonthly_Retention = if ($sqlOnlineRetention) {
                                                  FormatSQLRetention $sqlOnlineRetention.Monthly 'Months'
                                              } else {
                                                  FormatRetention $onlineObj.RetentionRangeMonthly
                                              }
                }

                # Yearly
                if ($enabledFreqs.ContainsKey('Yearly')) {
                    $OnlineYearly_Schedule  = BuildScheduleDesc $enabledFreqs['Yearly']
                    $OnlineYearly_Retention = if ($sqlOnlineRetention) {
                                                 FormatSQLRetention $sqlOnlineRetention.Yearly 'Years'
                                             } else {
                                                 FormatRetention $onlineObj.RetentionRangeYearly
                                             }
                }

                # Handle any unrecognised Frequency values via DetectFrequency fallback
                foreach ($onlineSched in $onlineSchedules) {
                    $freq = $onlineSched.Frequency.ToString()
                    if ($freq -notin @('Daily','Weekly','Monthly','Yearly')) {
                        $schedDesc = BuildScheduleDesc $onlineSched
                        $freq2     = DetectFrequency $schedDesc 0
                        switch ($freq2) {
                            'Daily'   {
                                if ($OnlineDaily_Schedule -eq 'N/A') {
                                    $OnlineDaily_Schedule  = $schedDesc
                                    $OnlineDaily_Retention = if ($sqlOnlineRetention) { FormatSQLRetention $sqlOnlineRetention.Daily   'Days'   } else { FormatRetention $onlineObj.RetentionRangeDaily   }
                                }
                            }
                            'Weekly'  {
                                if ($OnlineWeekly_Schedule -eq 'N/A') {
                                    $OnlineWeekly_Schedule  = $schedDesc
                                    $OnlineWeekly_Retention = if ($sqlOnlineRetention) { FormatSQLRetention $sqlOnlineRetention.Weekly  'Weeks'  } else { FormatRetention $onlineObj.RetentionRangeWeekly  }
                                }
                            }
                            'Monthly' {
                                if ($OnlineMonthly_Schedule -eq 'N/A') {
                                    $OnlineMonthly_Schedule  = $schedDesc
                                    $OnlineMonthly_Retention = if ($sqlOnlineRetention) { FormatSQLRetention $sqlOnlineRetention.Monthly 'Months' } else { FormatRetention $onlineObj.RetentionRangeMonthly }
                                }
                            }
                            'Yearly'  {
                                if ($OnlineYearly_Schedule -eq 'N/A') {
                                    $OnlineYearly_Schedule  = $schedDesc
                                    $OnlineYearly_Retention = if ($sqlOnlineRetention) { FormatSQLRetention $sqlOnlineRetention.Yearly  'Years'  } else { FormatRetention $onlineObj.RetentionRangeYearly  }
                                }
                            }
                        }
                    }
                }
            } catch {}
        }

        # Protection method summary
        $ProtMethod = @()
        if ($pg.IsDiskShortTerm) { $ProtMethod += 'Short-Term Disk'   }
        if ($pg.IsTapeLongTerm)  { $ProtMethod += 'Long-Term Tape'    }
        if ($pg.IsCloudLongTerm) { $ProtMethod += 'Long-Term Online'  }
        $ProtMethodStr = if ($ProtMethod.Count -gt 0) { $ProtMethod -join ' | ' } else { Safe $pg.ProtectionMethod }

        # Datasources
        Log "  Fetching datasources..." -Level 2
        $DSList   = @(Get-Datasource $pg 2>$null | Sort-Object ProductionServerName, Name)
        $DSCount  = 0
        $DSTotal  = $DSList.Count
        Log "  Datasources found: $DSTotal" -Level 2

        foreach ($ds in $DSList) {

            $DSCount++
            $DSStart = Get-Date
            $isHyperV = ($ds.ObjectType -eq 'HyperVComponent') -or ($ds.ObjectType -like '*HyperV*')
            $DatasourceDisplayName = if ($isHyperV) { Safe $ds.DatasourcePath } else { Safe $ds.Name }

            Log "  DS $DSCount of $DSTotal : $($ds.ProductionServerName) | $($ds.ObjectType) | $DatasourceDisplayName" -Level 3

            # Last recovery point — log before and after so we know if it hangs here
            Log "    Fetching last recovery point..." -Level 3
            $LastRP = GetLastRP $ds
            $DSElapsed = [math]::Round(((Get-Date) - $DSStart).TotalSeconds, 1)
            Log "    Last RP: $LastRP  (took ${DSElapsed}s)" -Level 3

            $row = [PSCustomObject][ordered]@{
                'DPM Server'                     = $DPMServerName
                'Production Server'              = Safe $ds.ProductionServerName
                'Protection Group'               = Safe $pg.Name
                'Datasource Name'                = $DatasourceDisplayName
                'Datasource Type'                = Safe $ds.ObjectType
                'Protection Method'              = $ProtMethodStr
                'Disk Backup Schedule'           = $DiskBackupSchedule
                'Disk Backup Retention'          = $DiskBackupRetention
                'Daily Tape Backup Schedule'     = $TapeDaily_Schedule
                'Daily Tape Backup Retention'    = $TapeDaily_Retention
                'Weekly Tape Backup Schedule'    = $TapeWeekly_Schedule
                'Weekly Tape Backup Retention'   = $TapeWeekly_Retention
                'Monthly Tape Backup Schedule'   = $TapeMonthly_Schedule
                'Monthly Tape Backup Retention'  = $TapeMonthly_Retention
                'Yearly Tape Backup Schedule'    = $TapeYearly_Schedule
                'Yearly Tape Backup Retention'   = $TapeYearly_Retention
                'Daily Online Backup Schedule'   = $OnlineDaily_Schedule
                'Daily Online Backup Retention'  = $OnlineDaily_Retention
                'Weekly Online Backup Schedule'  = $OnlineWeekly_Schedule
                'Weekly Online Backup Retention' = $OnlineWeekly_Retention
                'Monthly Online Backup Schedule' = $OnlineMonthly_Schedule
                'Monthly Online Backup Retention'= $OnlineMonthly_Retention
                'Yearly Online Backup Schedule'  = $OnlineYearly_Schedule
                'Yearly Online Backup Retention' = $OnlineYearly_Retention
                'Last Recovery Point'            = $LastRP
            }

            $Inventory.Add($row)
        }

        $PGElapsed = [math]::Round(((Get-Date) - $PGStart).TotalSeconds, 1)
        Log "  PG complete — $DSTotal datasources processed in ${PGElapsed}s" -Level 2 -Type 'OK'
    }

    # Disconnect cleanly
    if (-not $IsLocalDPM) {
        try { Disconnect-DPMServer -DPMServerName $ConnectName -ErrorAction SilentlyContinue } catch {}
    }

    $ServerElapsed = [math]::Round(((Get-Date) - $ServerStart).TotalSeconds, 1)
    Log "" -Level 0
    Log "Server $DPMServerName complete in ${ServerElapsed}s" -Level 1 -Type 'OK'
}

#--------------------------
# Export
#--------------------------
$TotalElapsed = [math]::Round(((Get-Date) - $ScriptStart).TotalSeconds, 1)
Log "" -Level 0

if ($Inventory.Count -gt 0) {
    Log "Writing CSV..." -Level 0
    $Inventory | Export-Csv -Path $OutputFile -NoTypeInformation -Encoding UTF8
    Log "===========================================" -Level 0
    Log " Export complete"                            -Level 0 -Type 'OK'
    Log " Servers processed  : $($ServerList.Count)" -Level 0
    Log " Total datasources  : $($Inventory.Count)"  -Level 0
    Log " Total time         : ${TotalElapsed}s"      -Level 0
    Log " Output file        : $OutputFile"           -Level 0
    Log "===========================================" -Level 0
} else {
    Log "No datasources found across any server. CSV not written." -Type 'WARN'
}