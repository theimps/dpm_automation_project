#Requires -Version 5.1
#Requires -Modules Hyper-V

[CmdletBinding()]
param(
    [Parameter(Mandatory = $false)]
    [ValidateNotNullOrEmpty()]
    [string]$InputCsv = 'C:\DPM_Data\HyperVHosts.csv',

    [Parameter(Mandatory = $false)]
    [ValidateNotNullOrEmpty()]
    [string]$OutputCsv = 'C:\DPM_Data\HyperV_VM_Inventory.csv',

    [Parameter(Mandatory = $false)]
    [ValidateNotNullOrEmpty()]
    [string]$ErrorCsv = 'C:\DPM_Data\HyperV_VM_Inventory_Errors.csv'
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Ensure-ParentFolder {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$FilePath
    )

    $ParentFolder = Split-Path -Path $FilePath -Parent

    if ($ParentFolder -and -not (Test-Path -LiteralPath $ParentFolder -PathType Container)) {
        New-Item -Path $ParentFolder -ItemType Directory -Force | Out-Null
    }
}

if (-not (Test-Path -LiteralPath $InputCsv -PathType Leaf)) {
    throw "Input CSV file not found: $InputCsv"
}

Ensure-ParentFolder -FilePath $OutputCsv
Ensure-ParentFolder -FilePath $ErrorCsv

Import-Module Hyper-V -ErrorAction Stop

$InputRows = @(Import-Csv -LiteralPath $InputCsv -ErrorAction Stop)

if ($InputRows.Count -eq 0) {
    throw 'The input CSV contains no data rows.'
}

$ColumnNames = @($InputRows[0].PSObject.Properties.Name)

if ($ColumnNames -notcontains 'ServerName') {
    throw 'The input CSV must contain a column named ServerName.'
}

$HyperVHosts = @(
    $InputRows |
        ForEach-Object {
            $Value = [string]$_.ServerName

            if ($null -ne $Value) {
                $Value = $Value.Trim()
            }

            if ($Value) {
                $Value
            }
        } |
        Sort-Object -Unique
)

if ($HyperVHosts.Count -eq 0) {
    throw 'The input CSV contains no valid server names.'
}

$Inventory = @()
$Failures = @()
$Index = 0

foreach ($HyperVHost in $HyperVHosts) {
    $Index++
    $PercentComplete = ($Index / $HyperVHosts.Count) * 100

    Write-Progress -Activity 'Collecting Hyper-V VM inventory' -Status "Querying $HyperVHost" -PercentComplete $PercentComplete
    Write-Host "Querying $HyperVHost" -ForegroundColor Cyan

    try {
        $VMs = @(Get-VM -ComputerName $HyperVHost -ErrorAction Stop | Sort-Object -Property Name)

        if ($VMs.Count -eq 0) {
            Write-Warning "No VMs found on $HyperVHost"

            $Inventory += [PSCustomObject]@{
                HyperVHost = $HyperVHost
                VMName     = ''
                State      = ''
                Status     = 'No VMs Found'
                VMId       = ''
                CollectedAt = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
            }
        }
        else {
            foreach ($VM in $VMs) {
                $Inventory += [PSCustomObject]@{
                    HyperVHost = $HyperVHost
                    VMName     = [string]$VM.Name
                    State      = [string]$VM.State
                    Status     = [string]$VM.Status
                    VMId       = [string]$VM.VMId
                    CollectedAt = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
                }
            }

            Write-Host "Found $($VMs.Count) VM(s) on $HyperVHost" -ForegroundColor Green
        }
    }
    catch {
        $Message = $_.Exception.Message
        Write-Warning "Failed to query $HyperVHost. $Message"

        $Failures += [PSCustomObject]@{
            HyperVHost = $HyperVHost
            Error      = $Message
            CheckedAt  = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
        }
    }
}

Write-Progress -Activity 'Collecting Hyper-V VM inventory' -Completed

if ($Inventory.Count -gt 0) {
    $Inventory |
        Sort-Object -Property HyperVHost, VMName |
        Export-Csv -LiteralPath $OutputCsv -NoTypeInformation -Encoding UTF8 -Force
}
else {
    if (Test-Path -LiteralPath $OutputCsv -PathType Leaf) {
        Remove-Item -LiteralPath $OutputCsv -Force
    }

    Write-Warning 'No VM inventory rows were collected. No inventory CSV was created.'
}

if ($Failures.Count -gt 0) {
    $Failures |
        Sort-Object -Property HyperVHost |
        Export-Csv -LiteralPath $ErrorCsv -NoTypeInformation -Encoding UTF8 -Force
}
else {
    if (Test-Path -LiteralPath $ErrorCsv -PathType Leaf) {
        Remove-Item -LiteralPath $ErrorCsv -Force
    }
}

$VMRecordCount = @($Inventory | Where-Object { $_.VMName }).Count

Write-Host ''
Write-Host 'Inventory collection completed.' -ForegroundColor Green
Write-Host "Hyper-V hosts supplied  : $($HyperVHosts.Count)"
Write-Host "VM records collected    : $VMRecordCount"
Write-Host "Hosts with no VMs       : $(@($Inventory | Where-Object { $_.Status -eq 'No VMs Found' }).Count)"
Write-Host "Hosts with errors       : $($Failures.Count)"

if ($Inventory.Count -gt 0) {
    Write-Host "Inventory CSV           : $OutputCsv"
}

if ($Failures.Count -gt 0) {
    Write-Host "Error CSV               : $ErrorCsv" -ForegroundColor Yellow
}
