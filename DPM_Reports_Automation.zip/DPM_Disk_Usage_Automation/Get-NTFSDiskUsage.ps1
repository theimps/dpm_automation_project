# Get-NTFSDiskUsage.ps1
# Remotely fetch NTFS disk size and utilization from servers in CSV

param(
    [Parameter(Mandatory=$true)]
    [ValidateScript({Test-Path -Path $_})]
    [string]$ServerListPath,
    
    [Parameter(Mandatory=$true)]
    [string]$OutputPath
)

# Validate server list file
if (-not (Test-Path -Path $ServerListPath)) {
    Write-Error "Server list file not found: $ServerListPath"
    exit 1
}

# Validate output path directory exists
$outputDirectory = Split-Path -Parent $OutputPath
if (-not (Test-Path -Path $outputDirectory)) {
    Write-Error "Output directory does not exist: $outputDirectory"
    exit 1
}

# Import server list
try {
    $ServerList = Import-Csv -Path $ServerListPath
} catch {
    Write-Error "Failed to import server list file: $_"
    exit 1
}

# Validate CSV has required columns
$requiredColumns = @('servername', 'location')
$csvColumns = $ServerList[0].PSObject.Properties.Name
foreach ($column in $requiredColumns) {
    if ($column -notin $csvColumns) {
        Write-Error "CSV missing required column: $column"
        exit 1
    }
}

# Script block to run on remote servers
$remoteScriptBlock = {
    $NTFSDisks = Get-Volume | Where-Object { $_.FileSystem -eq 'NTFS' }
    
    if ($NTFSDisks) {
        foreach ($disk in $NTFSDisks) {
            $sizeBytes = $disk.Size
            $usedBytes = $disk.SizeRemaining
            $utilizedBytes = $sizeBytes - $usedBytes
            
            [PSCustomObject]@{
                DriveLetter    = $disk.DriveLetter
                FileSystem     = $disk.FileSystem
                Label          = $disk.Label
                SizeGB         = [math]::Round($sizeBytes / 1GB, 2)
                UtilizedGB     = [math]::Round($utilizedBytes / 1GB, 2)
                AvailableGB    = [math]::Round($usedBytes / 1GB, 2)
                UtilizedPercent = [math]::Round(($utilizedBytes / $sizeBytes) * 100, 2)
            }
        }
    } else {
        [PSCustomObject]@{
            DriveLetter     = "N/A"
            FileSystem      = "N/A"
            Label           = "No NTFS volumes found"
            SizeGB          = 0
            UtilizedGB      = 0
            AvailableGB     = 0
            UtilizedPercent = 0
        }
    }
}

# Collection for results
$results = @()

# Process each server
foreach ($server in $ServerList) {
    $serverName = $server.servername.Trim()
    $location = $server.location.Trim()
    
    Write-Host "Processing: $serverName (Location: $location)" -ForegroundColor Cyan
    
    try {
        # Test connectivity
        if (Test-Connection -ComputerName $serverName -Count 1 -Quiet) {
            # Remote execution
            $diskInfo = Invoke-Command -ComputerName $serverName -ScriptBlock $remoteScriptBlock -ErrorAction Stop
            
            if ($diskInfo) {
                foreach ($disk in $diskInfo) {
                    $results += [PSCustomObject]@{
                        ServerName      = $serverName
                        Location        = $location
                        DriveLetter     = $disk.DriveLetter
                        FileSystem      = $disk.FileSystem
                        Label           = $disk.Label
                        SizeGB          = $disk.SizeGB
                        UtilizedGB      = $disk.UtilizedGB
                        AvailableGB     = $disk.AvailableGB
                        UtilizedPercent = $disk.UtilizedPercent
                        Status          = "Success"
                    }
                }
            }
        } else {
            Write-Warning "Cannot reach server: $serverName"
            $results += [PSCustomObject]@{
                ServerName      = $serverName
                Location        = $location
                DriveLetter     = "N/A"
                FileSystem      = "N/A"
                Label           = "Unreachable"
                SizeGB          = 0
                UtilizedGB      = 0
                AvailableGB     = 0
                UtilizedPercent = 0
                Status          = "Unreachable"
            }
        }
    } catch {
        Write-Warning "Error connecting to $serverName : $_"
        $results += [PSCustomObject]@{
            ServerName      = $serverName
            Location        = $location
            DriveLetter     = "N/A"
            FileSystem      = "N/A"
            Label           = "Error"
            SizeGB          = 0
            UtilizedGB      = 0
            AvailableGB     = 0
            UtilizedPercent = 0
            Status          = "Error: $_"
        }
    }
}

# Output results
Write-Host "`n========== NTFS Disk Information Report ==========" -ForegroundColor Green
$results | Format-Table -AutoSize

# Export to CSV
$results | Export-Csv -Path $OutputPath -NoTypeInformation -Force
Write-Host "`nResults exported to: $OutputPath" -ForegroundColor Green
