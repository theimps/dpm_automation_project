﻿#Requires -Version 5.1
#Requires -RunAsAdministrator
<#
.SYNOPSIS
    Read-only, datasource-centric DPM backup history collector.
.DESCRIPTION
    Rebuilt from the previously working v8 direct task-processing path.
    No mandatory generic task-normalization gateway is used.

    Creates two CSV files per local DPM server:
      DPM_Backup_Status_<DPMServer>.csv
      DPM_Backup_JobHistory_<DPMServer>.csv

    Four reader-facing operations are used:
      Disk Sync, Disk RP, Tape Backup, Online RP

    Timestamps are exported exactly as returned by the local DPM/SQL source.
    No timezone conversion or manual offset is applied.
#>
[CmdletBinding()]
param(
    [ValidateRange(1,365)]
    [int]$HistoryDays = 30,

    [ValidateNotNullOrEmpty()]
    [string]$OutputDirectory = 'C:\DPM_Data\BackupHistory',

    [ValidateNotNullOrEmpty()]
    [string]$SqlTarget = 'localhost',

    [Guid]$OnlineRPVerbID = '6E7C76F4-A832-4418-A772-8E58FD7466CB'
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'

$script:DPMServer = $env:COMPUTERNAME
$script:DPMServerShort = ''
$script:DPMDatabase = ''
$script:DiskTapeCollectionError = ''
$script:OnlineCollectionError = ''
$script:ParentJobsRetrieved = 0
$script:TasksExamined = 0
$script:SupportedTasksCollected = 0
$script:UnsupportedTasksSkipped = 0
$script:MalformedTasksSkipped = 0
$script:OnlineRowsCollected = 0
$script:TaskWarnings = New-Object System.Collections.Generic.List[string]
$script:DiscardedTasks = New-Object System.Collections.Generic.List[object]

function Test-SameTaskDatasource {
    param(
        [Parameter(Mandatory=$true)][object]$LeftTask,
        [Parameter(Mandatory=$true)][object]$RightTask
    )

    $leftId = [string](Get-TaskDatasourceId $LeftTask)
    $rightId = [string](Get-TaskDatasourceId $RightTask)

    if (
        -not [string]::IsNullOrWhiteSpace($leftId) -and
        -not [string]::IsNullOrWhiteSpace($rightId)
    ) {
        return $leftId -eq $rightId
    }

    $leftInfo = Get-SafeValue $LeftTask @('TaskInfo')
    $rightInfo = Get-SafeValue $RightTask @('TaskInfo')
    $leftDatasource = Get-SafeValue $leftInfo @('DataSource','Datasource')
    $rightDatasource = Get-SafeValue $rightInfo @('DataSource','Datasource')

    $leftServer = [string](Get-SafeValue $LeftTask @('ProductionServerName'))
    if ([string]::IsNullOrWhiteSpace($leftServer)) {
        $leftServer = [string](Get-SafeValue $leftDatasource @('ProductionServerName','Computer'))
    }

    $rightServer = [string](Get-SafeValue $RightTask @('ProductionServerName'))
    if ([string]::IsNullOrWhiteSpace($rightServer)) {
        $rightServer = [string](Get-SafeValue $rightDatasource @('ProductionServerName','Computer'))
    }

    $leftPath = Normalize-Path (Get-SafeValue $LeftTask @('DatasourcePath'))
    if ([string]::IsNullOrWhiteSpace($leftPath)) {
        $leftPath = Normalize-Path (Get-SafeValue $leftDatasource @('DisplayPath','Name','DatasourcePath'))
    }

    $rightPath = Normalize-Path (Get-SafeValue $RightTask @('DatasourcePath'))
    if ([string]::IsNullOrWhiteSpace($rightPath)) {
        $rightPath = Normalize-Path (Get-SafeValue $rightDatasource @('DisplayPath','Name','DatasourcePath'))
    }

    if (
        [string]::IsNullOrWhiteSpace($leftServer) -or
        [string]::IsNullOrWhiteSpace($rightServer) -or
        [string]::IsNullOrWhiteSpace($leftPath) -or
        [string]::IsNullOrWhiteSpace($rightPath)
    ) {
        return $false
    }

    return (Get-Key $leftServer $leftPath) -eq (Get-Key $rightServer $rightPath)
}

function Get-ValidTaskSize {
    param([AllowNull()][object]$Task)

    $size = Get-TaskSize $Task
    if ($null -eq $size) {
        return $null
    }

    [double]$numericSize = 0
    if (-not [double]::TryParse([string]$size,[ref]$numericSize)) {
        return $null
    }

    if ($numericSize -lt 0) {
        return $null
    }

    return [int64]$numericSize
}

function New-DiscardedTaskRecord {
    param(
        [Parameter(Mandatory=$true)][string]$Category,
        [Parameter(Mandatory=$true)][string]$Reason,
        [AllowNull()][object]$Job,
        [AllowNull()][object]$Task
    )

    $taskInfo = Get-SafeValue $Task @('TaskInfo')
    $taskDatasource = Get-SafeValue $taskInfo @('DataSource','Datasource')
    $productionServer = [string](Get-SafeValue $Task @('ProductionServerName'))
    if ([string]::IsNullOrWhiteSpace($productionServer)) {
        $productionServer = [string](Get-SafeValue $taskDatasource @('ProductionServerName','Computer'))
    }
    $datasourcePath = Normalize-Path (Get-SafeValue $Task @('DatasourcePath'))
    if ([string]::IsNullOrWhiteSpace($datasourcePath)) {
        $datasourcePath = Normalize-Path (Get-SafeValue $taskDatasource @('DisplayPath','Name','DatasourcePath'))
    }

    return [pscustomobject][ordered]@{
        'DPM Server' = $script:DPMServerShort
        'Discard Category' = $Category
        'Discard Reason' = $Reason
        'Parent Job ID' = [string](Get-SafeValue $Job @('JobId','JobID','Id'))
        'Parent Job Type' = [string](Get-SafeValue $Job @('Type','JobType'))
        'Parent Job Status' = Normalize-Status (Get-SafeValue $Job @('Status'))
        'Task ID' = [string](Get-SafeValue $Task @('TaskId','TaskID'))
        'Task Type' = [string](Get-SafeValue $Task @('Type'))
        'Operation Type' = [string](Get-SafeValue $taskInfo @('OperationType'))
        'Task Status' = Normalize-Status (Get-SafeValue $Task @('Status'))
        'Created Time' = Get-SafeValue $Task @('CreatedTime','CreatedDateTime')
        'Start Time' = Get-SafeValue $Task @('StartTime')
        'End Time' = Get-SafeValue $Task @('EndTime')
        'Production Server' = Get-ShortName $productionServer
        'DPM Datasource Path' = $datasourcePath
        'Datasource ID' = Get-TaskDatasourceId $Task
        'Error Code' = [string](Get-SafeValue $Task @('ErrorCode'))
        'Error Details' = Convert-ErrorText (Get-SafeValue $Task @('ErrorInfo','Error','ErrorInfoXml'))
    }
}

function Get-SafeValue {
    param(
        [AllowNull()][object]$InputObject,
        [Parameter(Mandatory=$true)][string[]]$Names
    )
    if ($null -eq $InputObject) { return $null }
    foreach ($name in $Names) {
        $property = $InputObject.PSObject.Properties[$name]
        if ($null -ne $property -and $null -ne $property.Value) {
            return $property.Value
        }
    }
    return $null
}

function Test-AnyTrueProperty {
    param(
        [AllowNull()][object]$InputObject,
        [Parameter(Mandatory=$true)][string[]]$Names
    )
    if ($null -eq $InputObject) { return $false }
    foreach ($name in $Names) {
        $property = $InputObject.PSObject.Properties[$name]
        if ($null -ne $property -and $null -ne $property.Value -and [bool]$property.Value) {
            return $true
        }
    }
    return $false
}

function Get-ShortName {
    param([AllowNull()][object]$Name)
    $text = [string]$Name
    if ([string]::IsNullOrWhiteSpace($text)) { return '' }
    return (($text -split '\.')[0]).ToUpperInvariant()
}

function Normalize-Path {
    param([AllowNull()][object]$Path)
    $text = [string]$Path
    if ([string]::IsNullOrWhiteSpace($text)) { return '' }
    if ($text -match '^RCT\\(.+)$') { return $Matches[1] }
    return $text
}

function Get-ValidDate {
    param([AllowNull()][object]$Value)
    if ($null -eq $Value) { return $null }
    try {
        $date = [datetime]$Value
        if ($date -eq [datetime]::MinValue -or $date.Year -le 1) { return $null }
        return $date
    }
    catch { return $null }
}

function Format-Duration {
    param([AllowNull()][object]$Start,[AllowNull()][object]$End)
    $startDate = Get-ValidDate $Start
    $endDate = Get-ValidDate $End
    if ($null -eq $startDate -or $null -eq $endDate) { return '' }
    $span = $endDate - $startDate
    if ($span.TotalSeconds -lt 0) { return '' }
    return ('{0:00}:{1:00}:{2:00}' -f [math]::Floor($span.TotalHours),$span.Minutes,$span.Seconds)
}

function Convert-Bytes {
    param([AllowNull()][object]$Bytes)
    $empty = [pscustomobject]@{ MB=''; GB=''; TB='' }
    if ($null -eq $Bytes) { return $empty }
    [double]$number = 0
    if (-not [double]::TryParse([string]$Bytes,[ref]$number)) { return $empty }
    if ($number -lt 0) { return $empty }
    return [pscustomobject]@{
        MB = [math]::Round($number / [math]::Pow(1024,2),2)
        GB = [math]::Round($number / [math]::Pow(1024,3),3)
        TB = [math]::Round($number / [math]::Pow(1024,4),4)
    }
}

function Get-FriendlyType {
    param([AllowNull()][object]$Datasource)
    $objectType = [string](Get-SafeValue $Datasource @('ObjectType'))
    $name = [string](Get-SafeValue $Datasource @('Name','DatasourceName'))
    $path = [string](Get-SafeValue $Datasource @('DisplayPath','DatasourcePath'))
    if ($objectType -match 'SQL.*database|SQL Server.*database') { return 'Database' }
    if ($objectType -match 'Hyper-V|HyperV' -or $name -match '^RCT\\' -or $path -match '^RCT\\') { return 'VM' }
    if ($objectType -match 'Host Component' -or $name -match 'Host Component' -or $path -match 'Host Component') { return 'Host Component' }
    return 'File Level'
}

function Get-InventoryPath {
    param([AllowNull()][object]$Datasource)
    $objectType = [string](Get-SafeValue $Datasource @('ObjectType'))
    if ($objectType -match 'Hyper-V|HyperV') {
        $value = Get-SafeValue $Datasource @('DatasourcePath','DisplayPath','Name')
    }
    else {
        $value = Get-SafeValue $Datasource @('Name','DisplayPath','DatasourcePath')
    }
    return (Normalize-Path $value)
}

function Get-Key {
    param([AllowNull()][object]$Server,[AllowNull()][object]$Path)
    return ('{0}|{1}' -f (Get-ShortName $Server),(Normalize-Path $Path)).ToUpperInvariant()
}

function Get-TaskDatasourceId {
    param([AllowNull()][object]$Task)
    $taskInfo = Get-SafeValue $Task @('TaskInfo')
    $value = Get-SafeValue $taskInfo @('DatasourceId','DataSourceId')
    if ($null -ne $value) { return [string]$value }
    $dataSource = Get-SafeValue $taskInfo @('DataSource','Datasource')
    $value = Get-SafeValue $dataSource @('DatasourceId','DataSourceId','Id')
    if ($null -ne $value) { return [string]$value }
    return ''
}

function Get-TaskSize {
    param([AllowNull()][object]$Task)
    $taskInfo = Get-SafeValue $Task @('TaskInfo')
    $value = Get-SafeValue $taskInfo @('DataSize','BytesTransferred','TransferredBytes')
    if ($null -eq $value) { return $null }
    [double]$number = 0
    if (-not [double]::TryParse([string]$value,[ref]$number)) { return $null }
    if ($number -lt 0) { return $null }
    return [int64]$number
}

function Convert-ErrorText {
    param([AllowNull()][object]$Value,[int]$MaxLength=1000)
    $text = [string]$Value
    if ([string]::IsNullOrWhiteSpace($text)) { return '' }
    if ($text.TrimStart().StartsWith('<')) {
        try {
            [xml]$xml = $text
            $node = $xml.SelectSingleNode('//*[local-name()="ErrorInfo"]')
            if ($null -ne $node) {
                $parts = New-Object System.Collections.Generic.List[string]
                foreach ($attributeName in @('ExceptionDetails','DetailedCode','DetailedSource','ErrorCode')) {
                    $attribute = $node.Attributes[$attributeName]
                    if ($null -ne $attribute -and -not [string]::IsNullOrWhiteSpace($attribute.Value) -and $attribute.Value -ne '0') {
                        $parts.Add(('{0}={1}' -f $attributeName,$attribute.Value))
                    }
                }
                if ($parts.Count -gt 0) { $text = $parts -join '; ' }
            }
        }
        catch { }
    }
    $text = ($text -replace '[\r\n\t]+',' ').Trim()
    if ($text.Length -gt $MaxLength) { return $text.Substring(0,$MaxLength) }
    return $text
}

function Normalize-Status {
    param([AllowNull()][object]$Status)
    $text = [string]$Status
    switch ($text) {
        '2' { return 'Succeeded' }
        '3' { return 'Failed' }
        default {
            if ([string]::IsNullOrWhiteSpace($text)) { return 'Unknown' }
            return $text
        }
    }
}

function Get-TaskClassification {
    param([AllowNull()][object]$TaskType,[AllowNull()][object]$TaskInfo)
    $typeText = [string]$TaskType
    $nativeOperation = [string](Get-SafeValue $TaskInfo @('OperationType'))
    $nativeBackupType = [string](Get-SafeValue $TaskInfo @('BackupType'))
    $method=''; $operation=''; $activity=''; $backupType=''

    switch -Regex ($typeText) {
        '^Replication$' {
            $method='Disk'; $operation='Disk Sync'
            if ($nativeOperation -match 'InitialReplication|Initial Replica|Initial') {
                $activity='Initial Replication'; $backupType='Full'
            }
            else {
                $activity='Synchronization'; $backupType='Incremental'
            }
            break
        }
        '^(Validation|ConsistencyCheck|Consistency Check|CC)$' {
            $method='Disk'; $operation='Disk Sync'; $activity='Consistency Check'; $backupType='Incremental'
            break
        }
        '^ShadowCopy$' {
            $method='Disk'; $operation='Disk RP'; $activity='Recovery Point Creation'; $backupType=''
            break
        }
        '^ArchiveFromSC$' {
            $method='Tape'; $operation='Tape Backup'; $activity='Tape Backup'; $backupType='Full'
            break
        }
        default { return $null }
    }

    # Apply the agreed reporting rules for Disk and Tape rather than allowing a generic
    # TaskInfo BackupType value to relabel a normal Disk Sync as Full.
    # Online RP uses its own DPMDB RecoverySource.BackupType handling below.

    return [pscustomobject]@{
        BackupMethod=$method
        Operation=$operation
        ActivityType=$activity
        BackupType=$backupType
        NativeOperation=$(if ([string]::IsNullOrWhiteSpace($nativeOperation)) {$typeText} else {$nativeOperation})
    }
}

function Get-AttemptTime {
    param(
        [AllowNull()][object]$Record
    )
    if ($null -eq $Record) { return $null }
    $status = [string](Get-SafeValue $Record @('Status'))
    $created = Get-ValidDate (Get-SafeValue $Record @('CreatedTime'))
    $started = Get-ValidDate (Get-SafeValue $Record @('StartTime'))
    $ended = Get-ValidDate (Get-SafeValue $Record @('EndTime'))

    if ($status -match '^(Queued|Pending|Scheduled)$') {
        if ($null -ne $created) { return $created }
        if ($null -ne $started) { return $started }
        return $ended
    }
    if ($status -match '^(InProgress|Running)$') {
        if ($null -ne $started) { return $started }
        if ($null -ne $created) { return $created }
        return $ended
    }
    if ($null -ne $started) { return $started }
    if ($null -ne $created) { return $created }
    return $ended
}

function New-HistoryRecord {
    param(
        [AllowEmptyString()][string]$ProtectionGroup,
        [AllowEmptyString()][string]$ProductionServer,
        [AllowEmptyString()][string]$DatasourcePath,
        [AllowEmptyString()][string]$DatasourceType,
        [string]$BackupMethod,
        [string]$Operation,
        [AllowNull()][object]$CreatedTime,
        [AllowNull()][object]$StartTime,
        [AllowNull()][object]$EndTime,
        [string]$Status,
        [AllowNull()][object]$SizeBytes,
        [string]$ActivityType='',
        [string]$TaskID='',
        [string]$ErrorCode='',
        [string]$ErrorDetails='',
        [string]$BackupType='',
        [string]$TapeLibrary='',
        [string]$NativeOperation='',
        [string]$DatasourceId=''
    )
    if ($BackupMethod -notin @('Disk','Tape','Online')) { throw "Invalid BackupMethod '$BackupMethod'." }
    if ($Operation -notin @('Disk Sync','Disk RP','Tape Backup','Online RP')) { throw "Invalid Operation '$Operation'." }

    $created = Get-ValidDate $CreatedTime
    $start = Get-ValidDate $StartTime
    $end = Get-ValidDate $EndTime
    $sizes = Convert-Bytes $SizeBytes
    if ($null -eq $SizeBytes -or $sizes.MB -eq '') { $sizeState='Unavailable' }
    elseif ($Status -match 'InProgress|Running|Pending|Queued') { $sizeState='Transferred So Far' }
    else { $sizeState='Final' }

    if ($Status -match '^(Succeeded|Completed)$') {
        $ErrorCode=''
        $ErrorDetails=''
    }

    return [pscustomobject][ordered]@{
        DPMServer=$script:DPMServerShort
        ProtectionGroup=$ProtectionGroup
        ProductionServer=(Get-ShortName $ProductionServer)
        DPMDatasourcePath=(Normalize-Path $DatasourcePath)
        DatasourceType=$DatasourceType
        BackupMethod=$BackupMethod
        Operation=$Operation
        ActivityType=$ActivityType
        CreatedTime=$created
        StartTime=$start
        EndTime=$end
        Duration=(Format-Duration $start $end)
        Status=$Status
        SizeMB=$sizes.MB
        SizeGB=$sizes.GB
        SizeTB=$sizes.TB
        SizeState=$sizeState
        TaskID=$TaskID
        ErrorCode=$ErrorCode
        ErrorDetails=$ErrorDetails
        BackupType=$BackupType
        TapeLibrary=$TapeLibrary
        NativeOperation=$NativeOperation
        DatasourceId=$DatasourceId
    }
}

function Test-HistoryRecord {
    param([AllowNull()][object]$Record)
    if ($null -eq $Record) { return $false }
    foreach ($name in @('DPMServer','ProductionServer','DPMDatasourcePath','Operation','Status')) {
        if ($null -eq $Record.PSObject.Properties[$name]) { return $false }
    }
    return $true
}

function Add-CoreStatusFields {
    param(
        [psobject]$Object,[string]$Prefix,[AllowNull()][object]$Latest,[AllowNull()][object]$Success,
        [bool]$Configured,[bool]$IncludeSize,[string]$CollectionError=''
    )
    $noAttempt="No Backup Attempt Found in $HistoryDays-Day History"
    $noSuccess="Not Found in $HistoryDays-Day History"
    $latestNames=@('Time','Status','Duration','TaskID','Error Code','Error Details')
    $successNames=@('Time','Duration','TaskID')
    if ($IncludeSize) { $latestNames+=@('Size MB','Size GB','Size TB','Size State'); $successNames+=@('Size MB','Size GB','Size TB') }

    $Object | Add-Member NoteProperty "$Prefix Protected" $(if($Configured){'Yes'}else{'No'})
    if (-not $Configured) {
        foreach($n in $latestNames){$Object|Add-Member NoteProperty "$Prefix Latest Attempt $n" 'Not Configured'}
        foreach($n in $successNames){$Object|Add-Member NoteProperty "$Prefix Last Successful $n" 'Not Configured'}
        return
    }
    if (-not [string]::IsNullOrWhiteSpace($CollectionError)) {
        foreach($n in $latestNames){$Object|Add-Member NoteProperty "$Prefix Latest Attempt $n" 'Unavailable - Collection Failed'}
        foreach($n in $successNames){$Object|Add-Member NoteProperty "$Prefix Last Successful $n" 'Unavailable - Collection Failed'}
        return
    }
    if ($null -eq $Latest) {
        foreach($n in $latestNames){$Object|Add-Member NoteProperty "$Prefix Latest Attempt $n" $noAttempt}
    } else {
        $Object|Add-Member NoteProperty "$Prefix Latest Attempt Time" (Get-SafeValue $Latest @('StartTime'))
        $Object|Add-Member NoteProperty "$Prefix Latest Attempt Status" (Get-SafeValue $Latest @('Status'))
        $Object|Add-Member NoteProperty "$Prefix Latest Attempt Duration" (Get-SafeValue $Latest @('Duration'))
        $Object|Add-Member NoteProperty "$Prefix Latest Attempt TaskID" (Get-SafeValue $Latest @('TaskID'))
        $Object|Add-Member NoteProperty "$Prefix Latest Attempt Error Code" (Get-SafeValue $Latest @('ErrorCode'))
        $Object|Add-Member NoteProperty "$Prefix Latest Attempt Error Details" (Get-SafeValue $Latest @('ErrorDetails'))
        if($IncludeSize){
            $Object|Add-Member NoteProperty "$Prefix Latest Attempt Size MB" (Get-SafeValue $Latest @('SizeMB'))
            $Object|Add-Member NoteProperty "$Prefix Latest Attempt Size GB" (Get-SafeValue $Latest @('SizeGB'))
            $Object|Add-Member NoteProperty "$Prefix Latest Attempt Size TB" (Get-SafeValue $Latest @('SizeTB'))
            $Object|Add-Member NoteProperty "$Prefix Latest Attempt Size State" (Get-SafeValue $Latest @('SizeState'))
        }
    }
    if ($null -eq $Success) {
        foreach($n in $successNames){$Object|Add-Member NoteProperty "$Prefix Last Successful $n" $noSuccess}
    } else {
        $Object|Add-Member NoteProperty "$Prefix Last Successful Time" (Get-SafeValue $Success @('StartTime'))
        $Object|Add-Member NoteProperty "$Prefix Last Successful Duration" (Get-SafeValue $Success @('Duration'))
        $Object|Add-Member NoteProperty "$Prefix Last Successful TaskID" (Get-SafeValue $Success @('TaskID'))
        if($IncludeSize){
            $Object|Add-Member NoteProperty "$Prefix Last Successful Size MB" (Get-SafeValue $Success @('SizeMB'))
            $Object|Add-Member NoteProperty "$Prefix Last Successful Size GB" (Get-SafeValue $Success @('SizeGB'))
            $Object|Add-Member NoteProperty "$Prefix Last Successful Size TB" (Get-SafeValue $Success @('SizeTB'))
        }
    }
}

function Add-ActivityFields {
    param([psobject]$Object,[string]$Prefix,[AllowNull()][object]$Latest,[AllowNull()][object]$Success,[bool]$Configured,[string]$CollectionError='')
    if(-not $Configured){$latest='Not Configured';$success='Not Configured'}
    elseif(-not [string]::IsNullOrWhiteSpace($CollectionError)){$latest='Unavailable - Collection Failed';$success=$latest}
    else{
        $latest=if($null -eq $Latest){"No Backup Attempt Found in $HistoryDays-Day History"}else{''}
        $success=if($null -eq $Success){"Not Found in $HistoryDays-Day History"}else{''}
    }
    $Object|Add-Member NoteProperty "$Prefix Latest Attempt Activity Type" $(if($latest){$latest}else{Get-SafeValue $Latest @('ActivityType')})
    $Object|Add-Member NoteProperty "$Prefix Latest Attempt Backup Type" $(if($latest){$latest}else{Get-SafeValue $Latest @('BackupType')})
    $Object|Add-Member NoteProperty "$Prefix Last Successful Activity Type" $(if($success){$success}else{Get-SafeValue $Success @('ActivityType')})
    $Object|Add-Member NoteProperty "$Prefix Last Successful Backup Type" $(if($success){$success}else{Get-SafeValue $Success @('BackupType')})
}

function Add-TapeFields {
    param([psobject]$Object,[AllowNull()][object]$Latest,[AllowNull()][object]$Success,[bool]$Configured,[string]$CollectionError='')
    if(-not $Configured){$latest='Not Configured';$success='Not Configured'}
    elseif(-not [string]::IsNullOrWhiteSpace($CollectionError)){$latest='Unavailable - Collection Failed';$success=$latest}
    else{
        $latest=if($null -eq $Latest){"No Backup Attempt Found in $HistoryDays-Day History"}else{''}
        $success=if($null -eq $Success){"Not Found in $HistoryDays-Day History"}else{''}
    }
    $Object|Add-Member NoteProperty 'Latest Tape Backup Attempt Backup Type' $(if($latest){$latest}else{Get-SafeValue $Latest @('BackupType')})
    $Object|Add-Member NoteProperty 'Latest Tape Backup Attempt Tape Library' $(if($latest){$latest}else{Get-SafeValue $Latest @('TapeLibrary')})
    $Object|Add-Member NoteProperty 'Last Successful Tape Backup Backup Type' $(if($success){$success}else{Get-SafeValue $Success @('BackupType')})
    $Object|Add-Member NoteProperty 'Last Successful Tape Backup Tape Library' $(if($success){$success}else{Get-SafeValue $Success @('TapeLibrary')})
}

function Write-HeaderOnlyCsv {
    param([string]$Path,[psobject]$Template)
    $header=($Template|ConvertTo-Csv -NoTypeInformation|Select-Object -First 1)
    Set-Content -LiteralPath $Path -Value $header -Encoding UTF8
}

function Test-ReportCsv {
    param(
        [Parameter(Mandatory=$true)][string]$Path,
        [Parameter(Mandatory=$true)][string[]]$ExpectedHeaders,
        [AllowNull()][object]$ExpectedRowCount
    )

    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return $false }
    $file = Get-Item -LiteralPath $Path -ErrorAction Stop
    if ($file.Length -le 0) { return $false }

    $header = Get-Content -LiteralPath $Path -TotalCount 1 -ErrorAction Stop
    if ([string]::IsNullOrWhiteSpace($header)) { return $false }
    foreach ($expectedHeader in $ExpectedHeaders) {
        if ($header -notmatch ('(^|,)"' + [regex]::Escape($expectedHeader) + '"(,|$)')) { return $false }
    }

    if ($null -ne $ExpectedRowCount) {
        $rows = @(Import-Csv -LiteralPath $Path -ErrorAction Stop)
        if ($rows.Count -ne [int]$ExpectedRowCount) { return $false }
    }
    return $true
}

function Remove-ReportFileSafely {
    param([Parameter(Mandatory=$true)][string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) { return }
    try { Remove-Item -LiteralPath $Path -Force -ErrorAction Stop }
    catch { Write-Warning ("Unable to remove report file '{0}'. It may be open or locked. {1}" -f $Path,$_.Exception.Message) }
}

function Invoke-ReportRetention {
    param(
        [Parameter(Mandatory=$true)][string]$Directory,
        [Parameter(Mandatory=$true)][string]$DPMServer,
        [Parameter(Mandatory=$true)][string]$CurrentRunId,
        [ValidateRange(1,100)][int]$KeepCompleteRuns = 3
    )

    $serverPattern = [regex]::Escape($DPMServer)
    $namePattern = '^DPM_Backup_(Status|JobHistory)_' + $serverPattern + '_(\d{8}_\d{6}_\d{3})\.csv$'
    $groups = @{}

    foreach ($file in @(Get-ChildItem -LiteralPath $Directory -File -ErrorAction Stop)) {
        $match = [regex]::Match($file.Name,$namePattern,[System.Text.RegularExpressions.RegexOptions]::IgnoreCase)
        if (-not $match.Success) { continue }
        $type = $match.Groups[1].Value
        $runId = $match.Groups[2].Value
        if (-not $groups.ContainsKey($runId)) {
            $groups[$runId] = [ordered]@{ RunId=$runId; Status=$null; JobHistory=$null }
        }
        if ($type -eq 'Status') { $groups[$runId]['Status'] = $file.FullName }
        elseif ($type -eq 'JobHistory') { $groups[$runId]['JobHistory'] = $file.FullName }
    }

    $complete = @($groups.Values | Where-Object { $null -ne $_['Status'] -and $null -ne $_['JobHistory'] } | Sort-Object @{Expression={$_['RunId']};Descending=$true})
    $olderComplete = @($complete | Select-Object -Skip $KeepCompleteRuns)
    foreach ($run in $olderComplete) {
        Remove-ReportFileSafely -Path ($run['Status'])
        Remove-ReportFileSafely -Path ($run['JobHistory'])
    }

    $orphans = @($groups.Values | Where-Object {
        (($_['Status'] -eq $null) -xor ($_['JobHistory'] -eq $null)) -and $_['RunId'] -lt $CurrentRunId
    })
    foreach ($run in $orphans) {
        if ($null -ne $run['Status']) { Remove-ReportFileSafely -Path ($run['Status']) }
        if ($null -ne $run['JobHistory']) { Remove-ReportFileSafely -Path ($run['JobHistory']) }
    }
}

$script:Mutex = $null
$script:MutexOwned = $false
$mutexName = 'Global\DPMBackupHistory_' + (Get-ShortName $env:COMPUTERNAME)
$createdNew = $false
try {
    $script:Mutex = [System.Threading.Mutex]::new($true,$mutexName,[ref]$createdNew)
    if (-not $createdNew) {
        throw "Another DPM backup history collection is already running on this server. Mutex: $mutexName"
    }
    $script:MutexOwned = $true

Write-Host ''
Write-Host 'DPM Backup History Collector v8' -ForegroundColor Cyan
Write-Host 'Read-only collection: DPM PowerShell plus SELECT-only local DPMDB query.' -ForegroundColor DarkGray

$script:DPMServerShort=Get-ShortName $script:DPMServer
New-Item -ItemType Directory -Path $OutputDirectory -Force|Out-Null
try{Import-Module DataProtectionManager -ErrorAction Stop}catch{throw "Unable to load DataProtectionManager module: $($_.Exception.Message)"}

$registryPath='HKLM:\SOFTWARE\Microsoft\Microsoft Data Protection Manager\DB'
$registryValueName='DatabaseName'
if(-not(Test-Path -LiteralPath $registryPath)){throw "DPM DB registry path not found: $registryPath"}
try{$script:DPMDatabase=[string](Get-ItemPropertyValue -LiteralPath $registryPath -Name $registryValueName -ErrorAction Stop)}catch{throw "Unable to read DPM database name: $($_.Exception.Message)"}
if([string]::IsNullOrWhiteSpace($script:DPMDatabase)){throw 'DPM database registry value is empty.'}
if($null -eq (Get-Command Invoke-Sqlcmd -ErrorAction SilentlyContinue)){$script:OnlineCollectionError='Invoke-Sqlcmd is unavailable.'}

Write-Host "DPM Server : $script:DPMServerShort"
Write-Host "SQL Target : $SqlTarget"
Write-Host "DPM DB     : $script:DPMDatabase"
Write-Host "History    : $HistoryDays days"
Write-Host "Output     : $OutputDirectory"
Write-Host 'Time policy: timestamps are exported as returned; no conversion is applied.'
Write-Host ''

$from=(Get-Date).AddDays(-$HistoryDays);$to=Get-Date
$inventory=New-Object System.Collections.Generic.List[object]
$inventoryById=@{};$inventoryByKey=@{}

try{
    $groups=@(Get-DPMProtectionGroup -DPMServerName $script:DPMServer -ErrorAction Stop)
    foreach($group in $groups){
        $groupName=[string](Get-SafeValue $group @('Name','ProtectionGroupName'))
        $disk=Test-AnyTrueProperty $group @('IsDiskShortTerm')
        $tape=Test-AnyTrueProperty $group @('IsTapeLongTerm','IsTapeShortTerm','IsTapeEnabled')
        $cloudGroup=Test-AnyTrueProperty $group @('IsCloudLongTerm','IsNewCloudProtection')
        foreach($ds in @(Get-DPMDatasource -ProtectionGroup $group -ErrorAction Stop)){
            $prod=[string](Get-SafeValue $ds @('ProductionServerName','Computer'))
            $path=Get-InventoryPath $ds
            $id=[string](Get-SafeValue $ds @('DatasourceId','DataSourceId','Id'))
            $cloudValue=Get-SafeValue $ds @('ProtectedOnCloud')
            $cloud=if($null -eq $cloudValue){$cloudGroup}else{[bool]$cloudValue}
            $row=[pscustomobject][ordered]@{
                DPMServer=$script:DPMServerShort;ProtectionGroup=$groupName;ProductionServer=(Get-ShortName $prod);ProductionServerFqdn=$prod
                DPMDatasourcePath=$path;DatasourceType=(Get-FriendlyType $ds);DatasourceId=$id
                DiskProtected=$disk;TapeProtected=$tape;OnlineProtected=$cloud
            }
            $inventory.Add($row)
            if(-not [string]::IsNullOrWhiteSpace($id)){$inventoryById[$id.ToUpperInvariant()]=$row}
            $inventoryByKey[(Get-Key $prod $path)]=$row
        }
    }
}catch{throw "Protection inventory failed: $($_.Exception.Message)"}

$history=New-Object System.Collections.Generic.List[object]
$jobs=@()
try{
    $jobs=@(Get-DPMJob -DPMServerName $script:DPMServer -From $from -To $to -NoLimitOnJobCount -AllJobsInInterval -ErrorAction Stop)
    $script:ParentJobsRetrieved=$jobs.Count
}catch{$script:DiskTapeCollectionError=$_.Exception.Message}

if([string]::IsNullOrWhiteSpace($script:DiskTapeCollectionError)){
    foreach($job in $jobs){
        $tasks=Get-SafeValue $job @('TaskList','Tasks')
        if($null -eq $tasks){continue}

        $jobTasks = @($tasks)
        $parentJobId = [string](Get-SafeValue $job @('JobId','JobID','Id'))

        foreach($task in $jobTasks){
            $script:TasksExamined++
            try{
                if($null -eq $task){throw 'Task object is null.'}
                $taskType=[string](Get-SafeValue $task @('Type'))
                $taskInfo=Get-SafeValue $task @('TaskInfo')
                $class=Get-TaskClassification $taskType $taskInfo
                if($null -eq $class){
                    $script:UnsupportedTasksSkipped++
                    $script:DiscardedTasks.Add((New-DiscardedTaskRecord -Category 'Unsupported Task Type' -Reason 'Task classification returned no supported backup operation.' -Job $job -Task $task))
                    continue
                }

                $method=[string](Get-SafeValue $class @('BackupMethod'))
                $operation=[string](Get-SafeValue $class @('Operation'))
                $activity=[string](Get-SafeValue $class @('ActivityType'))
                $backupType=[string](Get-SafeValue $class @('BackupType'))
                $nativeOperation=[string](Get-SafeValue $class @('NativeOperation'))
                if([string]::IsNullOrWhiteSpace($method)-or[string]::IsNullOrWhiteSpace($operation)){throw 'Task classification is incomplete.'}

                $taskDs=Get-SafeValue $taskInfo @('DataSource','Datasource')
                $prod=[string](Get-SafeValue $task @('ProductionServerName'))
                if([string]::IsNullOrWhiteSpace($prod)){$prod=[string](Get-SafeValue $taskDs @('ProductionServerName','Computer'))}
                $path=Normalize-Path (Get-SafeValue $task @('DatasourcePath'))
                if([string]::IsNullOrWhiteSpace($path)){$path=Normalize-Path (Get-SafeValue $taskDs @('DisplayPath','Name','DatasourcePath'))}
                $id=Get-TaskDatasourceId $task

                $inv=$null
                if(-not [string]::IsNullOrWhiteSpace($id)){$inv=$inventoryById[$id.ToUpperInvariant()]}
                if($null -eq $inv){$inv=$inventoryByKey[(Get-Key $prod $path)]}
                if($null -ne $inv){
                    $prod=[string](Get-SafeValue $inv @('ProductionServerFqdn','ProductionServer'))
                    $path=[string](Get-SafeValue $inv @('DPMDatasourcePath'))
                    if([string]::IsNullOrWhiteSpace($id)){$id=[string](Get-SafeValue $inv @('DatasourceId'))}
                }
                if([string]::IsNullOrWhiteSpace($prod)-or[string]::IsNullOrWhiteSpace($path)){throw 'Production server or datasource path is unavailable.'}

                $pg=if($null -ne $inv){[string](Get-SafeValue $inv @('ProtectionGroup'))}else{[string](Get-SafeValue $job @('ProtectionGroupName'))}
                $dsType=if($null -ne $inv){[string](Get-SafeValue $inv @('DatasourceType'))}else{''}

                # SQL database Replication tasks are the recurring disk-backup activity used
                # for the database datasource. Present these as Disk RP, not reader-facing Disk Sync.
                if ($taskType -eq 'Replication' -and $dsType -eq 'Database') {
                    $method='Disk'
                    $operation='Disk RP'
                }

                # VM/Host Component backend behavior:
                # Replication commonly carries transferred bytes, while ShadowCopy carries
                # the reader-facing recovery-point result. Export one VM Disk RP row.
                $sizeBytesForRecord = Get-ValidTaskSize $task

                if ($dsType -eq 'VM') {
                    if ($taskType -eq 'ShadowCopy') {
                        $method = 'Disk'
                        $operation = 'Disk RP'

                        if ($null -eq $sizeBytesForRecord) {
                            $replicationCandidates = @(
                                $jobTasks | Where-Object {
                                    ([string](Get-SafeValue $_ @('Type')) -eq 'Replication') -and
                                    (Test-SameTaskDatasource -LeftTask $task -RightTask $_) -and
                                    ($null -ne (Get-ValidTaskSize $_))
                                }
                            )

                            if ($replicationCandidates.Count -eq 1) {
                                $sizeBytesForRecord = Get-ValidTaskSize $replicationCandidates[0]
                            }
                            elseif ($replicationCandidates.Count -gt 1) {
                                $script:TaskWarnings.Add((
                                    "VM Disk RP size correlation was ambiguous. ParentJobID={0}; ShadowCopyTaskID={1}; Candidates={2}" -f
                                    $parentJobId,
                                    ([string](Get-SafeValue $task @('TaskId','TaskID'))),
                                    $replicationCandidates.Count
                                ))
                            }
                        }
                    }
                    elseif ($taskType -eq 'Replication') {
                        $matchingShadowCopies = @(
                            $jobTasks | Where-Object {
                                ([string](Get-SafeValue $_ @('Type')) -eq 'ShadowCopy') -and
                                (Test-SameTaskDatasource -LeftTask $task -RightTask $_)
                            }
                        )

                        if ($matchingShadowCopies.Count -gt 0) {
                            $script:DiscardedTasks.Add((
                                New-DiscardedTaskRecord `
                                    -Category 'Consumed as VM Disk RP Transfer Source' `
                                    -Reason 'The VM Replication task is a backend transfer component. Its transferred size is consumed by the matching ShadowCopy Disk RP row when uniquely correlated.' `
                                    -Job $job `
                                    -Task $task
                            ))
                            continue
                        }

                        # Some DPM jobs expose only Replication for the VM. For VM workloads,
                        # report that task as the reader-facing Disk RP rather than Disk Sync.
                        $method = 'Disk'
                        $operation = 'Disk RP'
                    }
                }

                $status=Normalize-Status (Get-SafeValue $task @('Status'))
                $errorCode=[string](Get-SafeValue $task @('ErrorCode'))
                $errorText=Convert-ErrorText (Get-SafeValue $task @('ErrorInfo','Error','ErrorInfoXml'))
                $record=New-HistoryRecord -ProtectionGroup $pg -ProductionServer $prod -DatasourcePath $path -DatasourceType $dsType `
                    -BackupMethod $method -Operation $operation -ActivityType $activity `
                    -CreatedTime (Get-SafeValue $task @('CreatedTime','CreatedDateTime')) `
                    -StartTime (Get-SafeValue $task @('StartTime')) -EndTime (Get-SafeValue $task @('EndTime')) `
                    -Status $status -SizeBytes $sizeBytesForRecord -TaskID ([string](Get-SafeValue $task @('TaskId','TaskID'))) `
                    -ErrorCode $errorCode -ErrorDetails $errorText -BackupType $backupType `
                    -TapeLibrary ([string](Get-SafeValue $taskInfo @('Library'))) -NativeOperation $nativeOperation -DatasourceId $id
                if(Test-HistoryRecord $record){$history.Add($record);$script:SupportedTasksCollected++}
            }catch{
                $script:MalformedTasksSkipped++
                $failureReason = $_.Exception.Message
                $script:TaskWarnings.Add(("Task processing failed. TaskID={0}; Type={1}; Error={2}" -f ([string](Get-SafeValue $task @('TaskId','TaskID'))),([string](Get-SafeValue $task @('Type'))),$failureReason))
                $script:DiscardedTasks.Add((New-DiscardedTaskRecord -Category 'Task Processing Failure' -Reason $failureReason -Job $job -Task $task))
                continue
            }
        }
    }
}

if([string]::IsNullOrWhiteSpace($script:OnlineCollectionError)){
    $verb=$OnlineRPVerbID.ToString()
    $query=@"
SET NOCOUNT ON;
SELECT task.TaskID,task.ExecutionState,task.CreatedDateTime,task.StartedDateTime,task.StoppedDateTime,
       task.ErrorCode,task.ErrorDetailsXml,rep.DatasourceId,rep.OperationType,recoverysource.BackupType,
       (ISNULL(rep.ReceiverTransferredBytes,0)+ISNULL(rep.HWVSenderTransferredBytes,0)+ISNULL(rep.LWVReceiverTransferredBytes,0)) AS TransferredBytes
FROM dbo.tbl_TE_TaskTrail task WITH (NOLOCK)
INNER JOIN dbo.tbl_RM_ReplicaTrail rep WITH (NOLOCK) ON rep.TaskId=task.TaskID
LEFT JOIN dbo.tbl_RM_RecoverySource recoverysource WITH (NOLOCK) ON recoverysource.DatasetId=rep.DatasetId
WHERE task.VerbID='$verb' AND task.CreatedDateTime>=DATEADD(day,-$HistoryDays,GETUTCDATE())
ORDER BY task.CreatedDateTime DESC;
"@
    try{
        $online=@(Invoke-Sqlcmd -ServerInstance $SqlTarget -Database $script:DPMDatabase -Query $query -ConnectionTimeout 30 -QueryTimeout 120 -MaxCharLength 65535 -AbortOnError -OutputSqlErrors $true -ErrorAction Stop)
        foreach($r in $online){
            $id=[string](Get-SafeValue $r @('DatasourceId','DataSourceId'))
            $inv=if([string]::IsNullOrWhiteSpace($id)){$null}else{$inventoryById[$id.ToUpperInvariant()]}
            if($null -eq $inv){continue}
            $nativeType=[string](Get-SafeValue $r @('BackupType'))
            $backupType='';$activity='Online Recovery Point'
            if($nativeType -match 'Full'){$backupType='Full';$activity='Initial Online Replication'}
            elseif($nativeType -match 'Incremental'){$backupType='Incremental'}
            $status=Normalize-Status (Get-SafeValue $r @('ExecutionState'))
            $errorCode=[string](Get-SafeValue $r @('ErrorCode'))
            $errorText=if($errorCode -eq '0'){''}else{Convert-ErrorText (Get-SafeValue $r @('ErrorDetailsXml'))}
            $record=New-HistoryRecord -ProtectionGroup ([string](Get-SafeValue $inv @('ProtectionGroup'))) `
                -ProductionServer ([string](Get-SafeValue $inv @('ProductionServer'))) -DatasourcePath ([string](Get-SafeValue $inv @('DPMDatasourcePath'))) `
                -DatasourceType ([string](Get-SafeValue $inv @('DatasourceType'))) -BackupMethod 'Online' -Operation 'Online RP' `
                -ActivityType $activity -CreatedTime (Get-SafeValue $r @('CreatedDateTime')) `
                -StartTime (Get-SafeValue $r @('StartedDateTime')) -EndTime (Get-SafeValue $r @('StoppedDateTime')) `
                -Status $status -SizeBytes (Get-SafeValue $r @('TransferredBytes')) -TaskID ([string](Get-SafeValue $r @('TaskID','TaskId'))) `
                -ErrorCode $errorCode -ErrorDetails $errorText -BackupType $backupType -NativeOperation 'CloudRep/OnlineRP' -DatasourceId $id
            if(Test-HistoryRecord $record){$history.Add($record);$script:OnlineRowsCollected++}
        }
    }catch{$script:OnlineCollectionError=$_.Exception.Message}
}

$validHistory = @(
    $history | Where-Object {
        if (-not (Test-HistoryRecord $_)) { return $false }
        $operation = [string](Get-SafeValue $_ @('Operation'))
        $datasourceType = [string](Get-SafeValue $_ @('DatasourceType'))
        if ($operation -eq 'Disk Sync' -and $datasourceType -ne 'File Level') { return $false }
        return $true
    }
)

$historySelect=@(
    @{N='DPM Server';E={Get-SafeValue $_ @('DPMServer')}},
    @{N='Protection Group';E={Get-SafeValue $_ @('ProtectionGroup')}},
    @{N='Production Server';E={Get-SafeValue $_ @('ProductionServer')}},
    @{N='DPM Datasource Path';E={Get-SafeValue $_ @('DPMDatasourcePath')}},
    @{N='Datasource Type';E={Get-SafeValue $_ @('DatasourceType')}},
    @{N='Backup Media';E={Get-SafeValue $_ @('BackupMethod')}},
    @{N='Operation';E={Get-SafeValue $_ @('Operation')}},
    @{N='Status';E={Get-SafeValue $_ @('Status')}},
    @{N='Start Time';E={Get-SafeValue $_ @('StartTime')}},
    @{N='End Time';E={Get-SafeValue $_ @('EndTime')}},
    @{N='Duration';E={Get-SafeValue $_ @('Duration')}},
    @{N='Size MB';E={Get-SafeValue $_ @('SizeMB')}},
    @{N='Size GB';E={Get-SafeValue $_ @('SizeGB')}},
    @{N='Size TB';E={Get-SafeValue $_ @('SizeTB')}}
)

$statusRows=New-Object System.Collections.Generic.List[object]
foreach($inv in $inventory){
    $prod=[string](Get-SafeValue $inv @('ProductionServer'))
    $path=[string](Get-SafeValue $inv @('DPMDatasourcePath'))
    $invId=[string](Get-SafeValue $inv @('DatasourceId'))
    $matching=@($validHistory|Where-Object{
        $historyId=[string](Get-SafeValue $_ @('DatasourceId'))
        if(-not [string]::IsNullOrWhiteSpace($invId)-and -not [string]::IsNullOrWhiteSpace($historyId)){$historyId -eq $invId}
        else{(Get-SafeValue $_ @('ProductionServer')) -eq $prod -and (Get-SafeValue $_ @('DPMDatasourcePath')) -eq $path}
    })

    $status=[pscustomobject][ordered]@{
        'DPM Server'=[string](Get-SafeValue $inv @('DPMServer'))
        'Protection Group'=[string](Get-SafeValue $inv @('ProtectionGroup'))
        'Production Server'=$prod
        'DPM Datasource Path'=$path
        'Datasource Type'=[string](Get-SafeValue $inv @('DatasourceType'))
    }

    $sections=@(
        @{Label='Disk Recovery Point';Operation='Disk RP';Configured=[bool](Get-SafeValue $inv @('DiskProtected'));CollectionError=$script:DiskTapeCollectionError},
        @{Label='Tape Backup';Operation='Tape Backup';Configured=[bool](Get-SafeValue $inv @('TapeProtected'));CollectionError=$script:DiskTapeCollectionError},
        @{Label='Online Backup';Operation='Online RP';Configured=[bool](Get-SafeValue $inv @('OnlineProtected'));CollectionError=$script:OnlineCollectionError}
    )

    $sectionData=@{}
    foreach($section in $sections){
        $label=[string]$section['Label']
        $operation=[string]$section['Operation']
        $configured=[bool]$section['Configured']
        $collectionError=[string]$section['CollectionError']
        $opHistory=@($matching|Where-Object{(Get-SafeValue $_ @('Operation')) -eq $operation}|Sort-Object @{E={Get-AttemptTime $_};Descending=$true})
        $latest=$opHistory|Select-Object -First 1
        $lastSuccessful=$opHistory|Where-Object{(Get-SafeValue $_ @('Status')) -match '^(Succeeded|Completed)$'}|Select-Object -First 1

        $protectedValue=if($configured){'Yes'}else{'No'}
        if(-not $configured){
            $lastTime='Not Configured';$lastDuration='Not Configured';$lastMB='Not Configured';$lastGB='Not Configured';$lastTB='Not Configured'
            $latestStatusValue='Not Configured';$latestTimeValue='Not Configured'
        }
        elseif(-not [string]::IsNullOrWhiteSpace($collectionError)){
            $lastTime='Unavailable - Collection Failed';$lastDuration=$lastTime;$lastMB=$lastTime;$lastGB=$lastTime;$lastTB=$lastTime
            $latestStatusValue=$lastTime;$latestTimeValue=$lastTime
        }
        else{
            if($null -eq $lastSuccessful){
                $notFound="Not Found in $HistoryDays-Day History"
                $lastTime=$notFound;$lastDuration=$notFound;$lastMB=$notFound;$lastGB=$notFound;$lastTB=$notFound
            }
            else{
                $lastTime=Get-SafeValue $lastSuccessful @('EndTime')
                if($null -eq $lastTime){$lastTime='Not Available'}
                $lastDuration=Get-SafeValue $lastSuccessful @('Duration')
                $lastMB=Get-SafeValue $lastSuccessful @('SizeMB')
                $lastGB=Get-SafeValue $lastSuccessful @('SizeGB')
                $lastTB=Get-SafeValue $lastSuccessful @('SizeTB')
                if($null -eq $lastMB -or [string]::IsNullOrWhiteSpace([string]$lastMB)){$lastMB='Not Available';$lastGB='Not Available';$lastTB='Not Available'}
            }

            if($null -eq $latest){
                $latestStatusValue="No Attempt Found in $HistoryDays-Day History"
                $latestTimeValue=$latestStatusValue
            }
            else{
                $latestStatusValue=[string](Get-SafeValue $latest @('Status'))
                $latestTimeValue=Get-AttemptTime $latest
                if($null -eq $latestTimeValue){$latestTimeValue='Not Available'}
            }
        }

        $sectionData[$label]=[ordered]@{
            Protected=$protectedValue
            LastTime=$lastTime
            LatestStatus=$latestStatusValue
            LatestTime=$latestTimeValue
            LastDuration=$lastDuration
            LastMB=$lastMB
            LastGB=$lastGB
            LastTB=$lastTB
        }
    }

    # Quick-check pairs first, exactly in Disk, Tape, Online order.
    $status|Add-Member NoteProperty 'Disk Recovery Point Protected' $sectionData['Disk Recovery Point']['Protected']
    $status|Add-Member NoteProperty 'Disk Recovery Point Last Successful Time' $sectionData['Disk Recovery Point']['LastTime']
    $status|Add-Member NoteProperty 'Tape Backup Protected' $sectionData['Tape Backup']['Protected']
    $status|Add-Member NoteProperty 'Tape Backup Last Successful Time' $sectionData['Tape Backup']['LastTime']
    $status|Add-Member NoteProperty 'Online Backup Protected' $sectionData['Online Backup']['Protected']
    $status|Add-Member NoteProperty 'Online Backup Last Successful Time' $sectionData['Online Backup']['LastTime']

    foreach($label in @('Disk Recovery Point','Tape Backup','Online Backup')){
        $status|Add-Member NoteProperty "$label Latest Attempt Status" $sectionData[$label]['LatestStatus']
        $status|Add-Member NoteProperty "$label Latest Attempt Time" $sectionData[$label]['LatestTime']
        $status|Add-Member NoteProperty "$label Last Successful Duration" $sectionData[$label]['LastDuration']
        $status|Add-Member NoteProperty "$label Last Successful Size MB" $sectionData[$label]['LastMB']
        $status|Add-Member NoteProperty "$label Last Successful Size GB" $sectionData[$label]['LastGB']
        $status|Add-Member NoteProperty "$label Last Successful Size TB" $sectionData[$label]['LastTB']
    }
    $statusRows.Add($status)
}

$runId = Get-Date -Format 'yyyyMMdd_HHmmss_fff'
$statusPath = Join-Path $OutputDirectory ("DPM_Backup_Status_{0}_{1}.csv" -f $script:DPMServerShort,$runId)
$historyPath = Join-Path $OutputDirectory ("DPM_Backup_JobHistory_{0}_{1}.csv" -f $script:DPMServerShort,$runId)
$discardedPath = Join-Path $OutputDirectory ("DPM_Backup_DiscardedTasks_{0}_{1}.csv" -f $script:DPMServerShort,$runId)
$publicationSucceeded = $false

try {
    if ($script:DiscardedTasks.Count -gt 0) {
        $script:DiscardedTasks |
            Sort-Object 'Discard Category','Parent Job ID','Task ID' |
            Export-Csv -LiteralPath $discardedPath -NoTypeInformation -Encoding UTF8 -ErrorAction Stop
    }
    else {
        $discardTemplate = [pscustomobject][ordered]@{
            'DPM Server'='';'Discard Category'='';'Discard Reason'='';'Parent Job ID'='';'Parent Job Type'='';'Parent Job Status'='';'Task ID'='';'Task Type'='';'Operation Type'='';'Task Status'='';'Created Time'='';'Start Time'='';'End Time'='';'Production Server'='';'DPM Datasource Path'='';'Datasource ID'='';'Error Code'='';'Error Details'=''
        }
        Write-HeaderOnlyCsv $discardedPath $discardTemplate
    }

    if ($validHistory.Count -gt 0) {
        $operationOrder=@{'Disk Sync'=1;'Disk RP'=2;'Tape Backup'=3;'Online RP'=4}
        $validHistory |
            Sort-Object `
                @{E={Get-SafeValue $_ @('ProductionServer')}},
                @{E={Get-SafeValue $_ @('DPMDatasourcePath')}},
                @{E={$operationOrder[[string](Get-SafeValue $_ @('Operation'))]}},
                @{E={Get-SafeValue $_ @('StartTime')};Descending=$true} |
            Select-Object $historySelect |
            Export-Csv -LiteralPath $historyPath -NoTypeInformation -Encoding UTF8 -ErrorAction Stop
    }
    else {
        $historyTemplate=[pscustomobject][ordered]@{
            'DPM Server'='';'Protection Group'='';'Production Server'='';'DPM Datasource Path'='';'Datasource Type'='';'Backup Media'='';Operation='';Status='';'Start Time'='';'End Time'='';Duration='';'Size MB'='';'Size GB'='';'Size TB'=''
        }
        Write-HeaderOnlyCsv $historyPath $historyTemplate
    }

    if ($statusRows.Count -gt 0) {
        $statusRows | Export-Csv -LiteralPath $statusPath -NoTypeInformation -Encoding UTF8 -ErrorAction Stop
    }
    else {
        $statusTemplate=[pscustomobject][ordered]@{
            'DPM Server'='';'Protection Group'='';'Production Server'='';'DPM Datasource Path'='';'Datasource Type'='';
            'Disk Recovery Point Protected'='';'Disk Recovery Point Last Successful Time'='';
            'Tape Backup Protected'='';'Tape Backup Last Successful Time'='';
            'Online Backup Protected'='';'Online Backup Last Successful Time'='';
            'Disk Recovery Point Latest Attempt Status'='';'Disk Recovery Point Latest Attempt Time'='';'Disk Recovery Point Last Successful Duration'='';'Disk Recovery Point Last Successful Size MB'='';'Disk Recovery Point Last Successful Size GB'='';'Disk Recovery Point Last Successful Size TB'='';
            'Tape Backup Latest Attempt Status'='';'Tape Backup Latest Attempt Time'='';'Tape Backup Last Successful Duration'='';'Tape Backup Last Successful Size MB'='';'Tape Backup Last Successful Size GB'='';'Tape Backup Last Successful Size TB'='';
            'Online Backup Latest Attempt Status'='';'Online Backup Latest Attempt Time'='';'Online Backup Last Successful Duration'='';'Online Backup Last Successful Size MB'='';'Online Backup Last Successful Size GB'='';'Online Backup Last Successful Size TB'=''
        }
        Write-HeaderOnlyCsv $statusPath $statusTemplate
    }

    $historyHeaders=@('DPM Server','Protection Group','Production Server','DPM Datasource Path','Datasource Type','Backup Media','Operation','Status','Start Time','End Time','Duration','Size MB','Size GB','Size TB')
    $statusHeaders=@('DPM Server','Protection Group','Production Server','DPM Datasource Path','Datasource Type','Disk Recovery Point Protected','Disk Recovery Point Last Successful Time','Tape Backup Protected','Tape Backup Last Successful Time','Online Backup Protected','Online Backup Last Successful Time','Disk Recovery Point Latest Attempt Status','Tape Backup Latest Attempt Status','Online Backup Latest Attempt Status')

    $discardedHeaders=@('DPM Server','Discard Category','Discard Reason','Parent Job ID','Parent Job Type','Parent Job Status','Task ID','Task Type','Operation Type','Task Status','Created Time','Start Time','End Time','Production Server','DPM Datasource Path','Datasource ID','Error Code','Error Details')
    $discardedValid = Test-ReportCsv -Path $discardedPath -ExpectedHeaders $discardedHeaders -ExpectedRowCount $null
    $historyValid = Test-ReportCsv -Path $historyPath -ExpectedHeaders $historyHeaders -ExpectedRowCount $null
    $statusValid = Test-ReportCsv -Path $statusPath -ExpectedHeaders $statusHeaders -ExpectedRowCount ([int]$inventory.Count)
    if (-not $historyValid -or -not $statusValid -or -not $discardedValid) {
        throw ("Report validation failed. StatusValid={0}; HistoryValid={1}; DiscardedValid={2}" -f $statusValid,$historyValid,$discardedValid)
    }
    $publicationSucceeded = $true
}
catch {
    $publicationError = $_.Exception.Message
    Remove-ReportFileSafely -Path $statusPath
    Remove-ReportFileSafely -Path $historyPath
    Remove-ReportFileSafely -Path $discardedPath
    throw "Report file generation or validation failed for Run ID $runId. $publicationError"
}

if ($publicationSucceeded) {
    try {
        Invoke-ReportRetention -Directory $OutputDirectory -DPMServer $script:DPMServerShort -CurrentRunId $runId -KeepCompleteRuns 3
    }
    catch {
        Write-Warning ("Report retention cleanup failed, but the new report pair is valid and retained. {0}" -f $_.Exception.Message)
    }
}

Write-Host ''
Write-Host 'Collection and report publication completed.' -ForegroundColor Green
Write-Host "Run ID                : $runId"
Write-Host "Inventory datasources : $($inventory.Count)"
Write-Host "Parent jobs retrieved : $script:ParentJobsRetrieved"
Write-Host "Tasks examined         : $script:TasksExamined"
Write-Host "Supported tasks        : $script:SupportedTasksCollected"
Write-Host "Unsupported tasks      : $script:UnsupportedTasksSkipped"
Write-Host "Malformed tasks        : $script:MalformedTasksSkipped"
Write-Host "Online RP rows         : $script:OnlineRowsCollected"
Write-Host "History records        : $($validHistory.Count)"
if($script:TaskWarnings.Count -gt 0){Write-Warning "Task processing warnings: $($script:TaskWarnings.Count). Run with -Verbose for details.";foreach($w in $script:TaskWarnings){Write-Verbose $w}}
if(-not [string]::IsNullOrWhiteSpace($script:DiskTapeCollectionError)){Write-Warning "Disk/Tape collection failed: $script:DiskTapeCollectionError"}
if(-not [string]::IsNullOrWhiteSpace($script:OnlineCollectionError)){Write-Warning "Online RP collection failed: $script:OnlineCollectionError"}
Write-Host "Status CSV  : $statusPath"
Write-Host "History CSV : $historyPath"
Write-Host "Discarded Tasks CSV : $discardedPath"

}
finally {
    if ($script:MutexOwned -and $null -ne $script:Mutex) {
        try { $script:Mutex.ReleaseMutex() } catch { }
    }
    if ($null -ne $script:Mutex) { $script:Mutex.Dispose() }
}
