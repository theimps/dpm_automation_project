﻿#Requires -Version 5.1
#Requires -RunAsAdministrator
<#
.SYNOPSIS
    Exports current DPM storage consumption for every protected datasource.
.DESCRIPTION
    Read-only collector. Uses Get-DPMProtectionGroup and Get-DPMDatasource.
    Disk Storage Consumed GB is calculated from ShadowCopyUsedSpace / 1024^3
    and truncated to two decimal places to match the DPM console display.
    Disk Storage Consumed TB is calculated as GB / 1024 and truncated to four decimals.
#>
[CmdletBinding()]
param(
    [ValidateNotNullOrEmpty()]
    [string]$OutputDirectory = 'C:\DPM_Data\StorageUtilization'
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'

function Get-SafeValue {
    param(
        [AllowNull()][object]$InputObject,
        [Parameter(Mandatory = $true)][string[]]$Names
    )

    if ($null -eq $InputObject) { return $null }

    foreach ($name in $Names) {
        try {
            $property = $InputObject.PSObject.Properties[$name]
            if ($null -ne $property -and $null -ne $property.Value) {
                return $property.Value
            }
        }
        catch { }
    }

    return $null
}

function Get-ShortName {
    param([AllowNull()][object]$Name)

    $text = [string]$Name
    if ([string]::IsNullOrWhiteSpace($text)) { return '' }
    return (($text -split '\.')[0]).ToUpperInvariant()
}

function Normalize-Path {
    param([AllowNull()][object]$Path)

    $text = [string]$Path
    if ([string]::IsNullOrWhiteSpace($text)) { return '' }
    if ($text -match '^RCT\\(.+)$') { return $Matches[1] }
    return $text
}

function Get-InventoryPath {
    param([AllowNull()][object]$Datasource)

    $objectType = [string](Get-SafeValue $Datasource @('ObjectType'))

    if ($objectType -match 'Hyper-V|HyperV') {
        $value = Get-SafeValue $Datasource @(
            'DatasourcePath',
            'DisplayPath',
            'Name'
        )
    }
    else {
        $value = Get-SafeValue $Datasource @(
            'Name',
            'DisplayPath',
            'DatasourcePath'
        )
    }

    return Normalize-Path $value
}

function Get-FriendlyType {
    param([AllowNull()][object]$Datasource)

    $objectType = [string](Get-SafeValue $Datasource @('ObjectType'))
    $name = [string](Get-SafeValue $Datasource @('Name','DatasourceName'))
    $path = [string](Get-SafeValue $Datasource @('DisplayPath','DatasourcePath'))

    if ($objectType -match 'SQL.*database|SQL Server.*database') {
        return 'Database'
    }

    if (
        $objectType -match 'Hyper-V|HyperV' -or
        $name -match '^RCT\\' -or
        $path -match '^RCT\\'
    ) {
        return 'VM'
    }

    if (
        $objectType -match 'Host Component' -or
        $name -match 'Host Component' -or
        $path -match 'Host Component'
    ) {
        return 'Host Component'
    }

    return 'File Level'
}

function Get-StorageConsumedResult {
    [CmdletBinding()]
    param(
        [AllowNull()][object]$Datasource
    )

    $unavailable = [pscustomobject][ordered]@{
        GB = 'Not Available'
        TB = 'Not Available'
    }

    if ($null -eq $Datasource) { return $unavailable }

    try {
        $property = $Datasource.PSObject.Properties['ShadowCopyUsedSpace']

        if ($null -eq $property -or $null -eq $property.Value) {
            return $unavailable
        }

        [long]$usedBytes = 0
        $validNumber = [long]::TryParse(
            [string]$property.Value,
            [ref]$usedBytes
        )

        if (-not $validNumber -or $usedBytes -lt 0) {
            return $unavailable
        }

        [double]$rawGB = $usedBytes / [math]::Pow(1024,3)
        [double]$consumedGB = [math]::Floor($rawGB * 100) / 100
        [double]$consumedTB = [math]::Floor(($consumedGB / 1024) * 10000) / 10000

        return [pscustomobject][ordered]@{
            GB = $consumedGB
            TB = $consumedTB
        }
    }
    catch {
        return $unavailable
    }
}

$dpmServer = $env:COMPUTERNAME
$dpmServerShort = Get-ShortName $dpmServer

New-Item -ItemType Directory -Path $OutputDirectory -Force | Out-Null
Import-Module DataProtectionManager -ErrorAction Stop

$rows = New-Object System.Collections.Generic.List[object]
$protectionGroups = @(
    Get-DPMProtectionGroup `
        -DPMServerName $dpmServer `
        -ErrorAction Stop
)

foreach ($protectionGroup in $protectionGroups) {
    $protectionGroupName = [string](
        Get-SafeValue $protectionGroup @(
            'Name',
            'ProtectionGroupName'
        )
    )

    $datasources = @(
        Get-DPMDatasource `
            -ProtectionGroup $protectionGroup `
            -ErrorAction Stop
    )

    foreach ($datasource in $datasources) {
        $protectedValue = Get-SafeValue $datasource @('Protected')

        if ($null -ne $protectedValue -and -not [bool]$protectedValue) {
            continue
        }

        $productionServerFqdn = [string](
            Get-SafeValue $datasource @(
                'ProductionServerName',
                'Computer'
            )
        )

        $datasourcePath = Get-InventoryPath $datasource
        $datasourceType = Get-FriendlyType $datasource
        $storage = Get-StorageConsumedResult -Datasource $datasource

        $rows.Add(
            [pscustomobject][ordered]@{
                'DPM Server' = $dpmServerShort
                'Protection Group' = $protectionGroupName
                'Production Server' = Get-ShortName $productionServerFqdn
                'DPM Datasource Path' = $datasourcePath
                'Datasource Type' = $datasourceType
                'Disk Storage Consumed GB' = $storage.GB
                'Disk Storage Consumed TB' = $storage.TB
            }
        )
    }
}

$runId = Get-Date -Format 'yyyyMMdd_HHmmss_fff'
$outputPath = Join-Path $OutputDirectory (
    'DPM_ProtectedDatasource_StorageUtilization_{0}_{1}.csv' -f
    $dpmServerShort,
    $runId
)

if ($rows.Count -gt 0) {
    $rows |
        Sort-Object `
            'Protection Group',
            'Production Server',
            'DPM Datasource Path' |
        Export-Csv `
            -LiteralPath $outputPath `
            -NoTypeInformation `
            -Encoding UTF8 `
            -ErrorAction Stop
}
else {
    $template = [pscustomobject][ordered]@{
        'DPM Server' = ''
        'Protection Group' = ''
        'Production Server' = ''
        'DPM Datasource Path' = ''
        'Datasource Type' = ''
        'Disk Storage Consumed GB' = ''
        'Disk Storage Consumed TB' = ''
    }

    $header = $template |
        ConvertTo-Csv -NoTypeInformation |
        Select-Object -First 1

    Set-Content `
        -LiteralPath $outputPath `
        -Value $header `
        -Encoding UTF8 `
        -ErrorAction Stop
}

$exportedRows = @(Import-Csv -LiteralPath $outputPath -ErrorAction Stop)
if ($exportedRows.Count -ne $rows.Count) {
    throw "CSV validation failed. Expected $($rows.Count) rows, found $($exportedRows.Count)."
}

Write-Host ''
Write-Host 'DPM protected datasource storage utilization completed.' -ForegroundColor Green
Write-Host "DPM Server          : $dpmServerShort"
Write-Host "Protection Groups   : $($protectionGroups.Count)"
Write-Host "Protected Datasources: $($rows.Count)"
Write-Host "Output CSV          : $outputPath"
Write-Host 'Storage source      : ShadowCopyUsedSpace'
Write-Host 'GB conversion       : bytes / 1024^3, truncated to two decimals'
Write-Host 'TB conversion       : Disk Storage Consumed GB / 1024, truncated to four decimals'
